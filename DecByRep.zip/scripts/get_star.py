import requests


class Getstars:
    def __init__(self):
        self.voorkant = "http://", "https://"
        self.porten = ":80", ":443"
        self.timeout = 3

    def fix_star(self, star):
        try:
            star = star.strip().replace("\n", "").replace("\r", "").replace(" ", "")
            if "://" in star and ":" in star.split("://")[1] or star.endswith("/"):
                star = star
            elif "://" not in star and ":" in star:
                get_port = str(":" + star.split(":")[1].replace(" ", "").replace("\n", "").replace("\r", ""))
                if get_port == self.porten[0]:
                    star = self.voorkant[0] + star
                elif get_port == self.porten[1]:
                    star = self.voorkant[1] + star
                elif star.split(":")[1] not in self.porten:
                    try:
                        se = requests.get(f"http://{star}", allow_redirects=False, verify=False,
                                          timeout=self.timeout).status_code
                        if se == 200:
                            star = f"http://{star}"
                        else:
                            se = requests.get(f"https://{star}", allow_redirects=False, verify=False,
                                              timeout=self.timeout).status_code
                            if se == 200:
                                star = f"https://{star}"
                            else:
                                star = f"http://{star}"
                    except:
                        return "DEAD_STAR"
            elif "://" not in star and ":" not in star:
                star = self.voorkant[0] + star + self.porten[0]
            elif "://" in star and ":" not in star.split("://")[1]:
                if "http://" in star:
                    star = star + self.porten[0]
                elif "https://" in star:
                    star = star + self.porten[1]
            star = star.replace('\n', '').replace('\r', '')
            return star
        except Exception as e:
            return "DEAD_STAR"

