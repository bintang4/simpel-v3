import configparser
import vonage

config = configparser.RawConfigParser()
config.read('settings.cfg')
settings = dict(config.items('DEFAULT'))
send_to = settings['your_phonenumber']


def smser(nexmo_api, nexmo_secretkey, build):
    try:
        client = vonage.Client(key=nexmo_api, secret=nexmo_secretkey)
        sms = vonage.Sms(client)
        responseData = sms.send_message(
            {
                "from": "ApikeyTest",
                "to": send_to,
                "text": str(build), })
        if responseData["messages"][0]["status"] == "0":
            sms_status = "SMS_SEND"
            return sms_status
        else:
            sms_status = "SMS_FAILED"
            return sms_status
    except Exception:
        sms_status = "SMS_FAILED"
        return sms_status


def nexmo_checker(nexmo_api, nexmo_secretkey):
    try:
        client = vonage.Client(key=nexmo_api, secret=nexmo_secretkey).get_balance()
        balance = f"€{client['value']:0.2f} EURO"
        is_reload = client['autoReload']
        build = f"NEXMO_API: {nexmo_api}\nNEXMO_SECRET: {nexmo_secretkey}\nBALANCE: {str(balance)}\nAUTO_RELOAD: " \
                f"{is_reload}"
        test_sms = smser(nexmo_api, nexmo_secretkey, build)
        if test_sms == "SMS_FAILED":
            sms_status = "SMS_API_FAILED"
            return sms_status
        else:
            sms_status = "SMS_SEND"
            nex = open("Results/Hits_nexmo.txt", "a")
            remover = build.replace('\r', '')
            nex.write(remover + '\n\n')
            nex.close()
            return sms_status
    except Exception:
        sms_status = "SMS_API_FAILED"
        return sms_status
