import requests
import re

url = "https://drive.google.com/file/d/1rcuCw8bH4i7_QCOe1vLEkLY8P9EA77OD/view?usp=sharing"
url2 = "https://drive.google.com/file/d/1rcuCw8bH4i7_QCOe1vLEkLY8P9EA77OD/view"
url3 = "https://bin.0xfc.de/?50014878d5460bac#2HyoMyeh9bkrU7imcGc5ueLGt2t8vPkQ4aLCEtLRhhUL"
url4 = "https://bin.0xfc.de/4a486507-ec05-43a7-bdca-9c4b5b98270e"
zoeken = requests.get(url2, verify=False).text.strip()
print(zoeken)
for line in zoeken:
    if "v5" in line:
        print(line)
        se = re.findall('download="(.*?)">', zoeken)
        print(se)
