import socket
import paramiko


def check_ssh_star(star, ssh_username, ssh_password):
    star = star.replace("http://", "").replace("https://", "").replace("www.", "").replace(":443", "").replace(
        ":80", "").replace(":8080", "")
    if ":" in star:
        star = star.split(":")[0]
    try:
        ip = socket.gethostbyname(star)
        ssh_host = ip
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ssh_host, port=22, username=ssh_username, password=ssh_username, timeout=4)
        ssh_string = f"SSH_HOST= {ssh_host}\nSSH_USERNAME= {ssh_username}\nPASSWORD= {ssh_password} "
        remover = ssh_string.replace('\r', '')
        ssh = open("Results/SSH_INFO_FOUND.txt", "a")
        ssh.write(remover + '\n\n')
        ssh.close()
        ssh_status = "GOOD_SSH"
        return ssh_status
    except Exception:
        ssh_status = "BAD_SSH"
        return ssh_status


def check_ssh(star, ssh_host, ssh_username, ssh_password):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ssh_host, port=22, username=ssh_username, password=ssh_username, timeout=4)
        ssh_string = f"SSH_HOST= {ssh_host}\nSSH_USERNAME= {ssh_username}\nPASSWORD= {ssh_password} "
        remover = ssh_string.replace('\r', '')
        ssh = open("Results/SSH_INFO_FOUND.txt", "a")
        ssh.write(remover + '\n\n')
        ssh.close()
        ssh_status = "GOOD_SSH"
        return ssh_status
    except Exception as e:
        check_met_url = check_ssh_star(star, ssh_username, ssh_password)
        return check_met_url
